node --enable-source-maps --watch --env-file=./.env.dev --experimental-specifier-resolution=node --loader ts-node/esm ./src/index.ts
