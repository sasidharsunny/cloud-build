let ws;

const API_BASE_ADDRESS = 'https://devvtn1.xavlab.xyz:8001';
const ORG_ID = '123e4567-e89b-12d3-a456-426614174999';
const API_KEY = '21c05051-0312-4b49-8608-4afe89236847';

/**
 * @returns {{audioSessionId:string ,connectionToken:string, streamingUrl:string}} 
 */
async function createConnection() {
  // POST /orgs/{orgId}/join-audio-session with authorization header and asrProfileId in the body
  const rawResponse = await fetch(`${API_BASE_ADDRESS}/orgs/${ORG_ID}/join-audio-session`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': API_KEY,
    },
    body: JSON.stringify({
      'audioSessionId': document.getElementById('audioId').value,
      'streamTypes': ['raw', 'sentence'],
      'metadata': {
        'sampleRate': 16000,
        'channels': 1,
        'incomingPhoneNumber': '+1234567890',
        'customerId': 'CUST-78910'
      }
    }),
  });

  return await rawResponse.json();
}

/**
 * @param {string} url
 */
async function connectWebsocket(url) {
  return new Promise((resolve, reject) => {
    ws = new WebSocket(url);
    ws.onopen = () => {
      resolve();
      console.log('WebSocket connected');
    };
    ws.onmessage = async (event) => {
      console.log(event.type);
      console.log(event);
      const decodedEvent = MessageCoder.decodeTextChunk(await event.data.arrayBuffer());
      if (decodedEvent.messageType == 'RTXT') {
        handleText(document.getElementById('rtxt'), decodedEvent.text);
      } else if(decodedEvent.messageType == 'STXT') {
        handleText(document.getElementById('stxt'), decodedEvent.text);
      }
      console.log('WebSocket message:', event.data);
    };
    ws.onclose = () => {
      console.log('WebSocket closed');
    };
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      reject(error);
    };
  });
}

function handleText(col, text) {
  const p = document.createElement('p');
  p.innerHTML = text;
  col.appendChild(p);
}

async function startProcessing() {
  const startButton = document.getElementById('start');
  const stopButton = document.getElementById('stop');
  startButton.disabled = true;

  const producerConn = await createConnection();
  await connectWebsocket(producerConn.streamingUrl);

  // Send auth message
  const authMessage = MessageCoder.encodeAuthMessage(producerConn.connectionToken, producerConn.audioSessionId);
  console.log('Sending auth message:', authMessage.byteLength);
  ws.send(authMessage);



  stopButton.disabled = false;
}

function stopProcessing() {
  document.getElementById('start').disabled = false;
  document.getElementById('stop').disabled = true;
}



document.getElementById('start').addEventListener('click', ()=> startProcessing());
document.getElementById('stop').addEventListener('click', () => stopProcessing());
