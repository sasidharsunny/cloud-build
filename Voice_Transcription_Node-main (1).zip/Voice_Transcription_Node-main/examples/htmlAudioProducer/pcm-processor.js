/**
 * AudioWorkletProcessor that processes PCM data in 100ms intervals and sends
 * downsampled 16kHz 16-bit PCM bytes to the main thread for further processing.
 */


class PCMProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buffer = [];
    this.samplesPerInterval = sampleRate * (100 / 1000); // 100ms intervals
  }

  process(inputs, outputs, parameters) {
    const input = inputs[0];
    if (input.length > 0) {
      const inputChannel = input[0]; // Use the first channel (mono)

      this.buffer.push(...inputChannel);

      // Process PCM in 100ms intervals
      if (this.buffer.length >= this.samplesPerInterval) {
        const chunk = this.buffer.slice(0, this.samplesPerInterval);
        this.buffer = this.buffer.slice(this.samplesPerInterval);

        // Downsample to 16kHz
        const downsampled = this.convertTo16kHzPCMArrayBuffer(chunk, sampleRate);

        // Send downsampled PCM data to the main thread
        this.port.postMessage({ pcmData: downsampled });
      }
    }

    return true; // Keep processor alive
  }

  convertTo16kHzPCMArrayBuffer(buffer, inputSampleRate) {
    if (inputSampleRate === 16000) {
      // If input is already 16kHz, convert directly to 16-bit PCM
      const pcm = new Int16Array(buffer.length);
      const rawBytes = new ArrayBuffer(buffer.length * 2);
      const view = new DataView(rawBytes);

      for (let i = 0; i < buffer.length; i++) {
        const val = buffer[i] * 32767;
        pcm[i] = val < -32768 ? -32768 : val > 32767 ? 32767 : val;
        view.setInt16(i * 2, pcm[i], true);
      }

      return rawBytes;
    }

    // Downsampling required
    const ratio = inputSampleRate / 16000;
    const outputLength = Math.floor(buffer.length / ratio);
    const rawBytes = new ArrayBuffer(outputLength * 2);
    const view = new DataView(rawBytes);

    for (let i = 0; i < outputLength; i++) {
      const index = Math.floor(i * ratio);
      const val = buffer[index] * 32767;
      const pcmVal = val < -32768 ? -32768 : val > 32767 ? 32767 : val;
      view.setInt16(i * 2, pcmVal, true);
    }

    return rawBytes;
  }
}

registerProcessor('pcm-processor', PCMProcessor);
