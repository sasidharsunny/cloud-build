class MessageCoder {
  static getMessageType(buffer) {
    const view = new DataView(buffer);
    return this.readString(view, 0, 4);
  }

  static encodeAuthMessage(token, sessionId) {
    const tokenBytes = new TextEncoder().encode(token);
    const sessionIdBytes = new TextEncoder().encode(sessionId);

    const payloadLength = 4 + tokenBytes.length + 2 + sessionIdBytes.length;
    const buffer = new ArrayBuffer(8 + payloadLength);
    const view = new DataView(buffer);
    let offset = 0;

    // Message Type
    this.writeString(view, offset, "AUTH", 4);
    offset += 4;

    // Message Length
    view.setUint32(offset, payloadLength, false);
    offset += 4;

    // Token Length
    view.setUint16(offset, tokenBytes.length, false);
    offset += 2;

    // Token
    new Uint8Array(buffer, offset, tokenBytes.length).set(tokenBytes);
    offset += tokenBytes.length;

    // Session ID Length
    view.setUint16(offset, sessionIdBytes.length, false);
    offset += 2;

    // Session ID
    new Uint8Array(buffer, offset, sessionIdBytes.length).set(sessionIdBytes);

    return buffer;
  }

  static decodeAuthMessage(buffer) {
    const view = new DataView(buffer);
    let offset = 0;

    // Message Type
    const messageType = this.readString(view, offset, 4);
    offset += 4;

    // Message Length
    const payloadLength = view.getUint32(offset, false);
    offset += 4;

    // Token Length
    const tokenLength = view.getUint16(offset, false);
    offset += 2;

    // Token
    const token = this.readString(view, offset, tokenLength);
    offset += tokenLength;

    // Session ID Length
    const sessionIdLength = view.getUint16(offset, false);
    offset += 2;

    // Session ID
    const sessionId = this.readString(view, offset, sessionIdLength);

    return { messageType, payloadLength, token, sessionId };
  }

  static encodeAudioChunk(sequence, timestamp, audioData) {
    const payloadLength = 4 + 8 + audioData.byteLength;
    const buffer = new ArrayBuffer(8 + payloadLength);
    const view = new DataView(buffer);
    let offset = 0;

    // Message Type
    this.writeString(view, offset, "AUDC", 4);
    offset += 4;

    // Message Length
    view.setUint32(offset, payloadLength, false);
    offset += 4;

    // Sequence
    view.setUint32(offset, sequence, false);
    offset += 4;

    // Timestamp
    view.setBigUint64(offset, BigInt(timestamp), false);
    offset += 8;

    // Audio Data
    new Uint8Array(buffer, offset, audioData.byteLength).set(new Uint8Array(audioData));

    return buffer;
  }

  static decodeAudioChunk(buffer) {
    const view = new DataView(buffer);
    let offset = 0;

    // Message Type
    const messageType = this.readString(view, offset, 4);
    offset += 4;

    // Message Length
    const payloadLength = view.getUint32(offset, false);
    offset += 4;

    // Sequence
    const sequence = view.getUint32(offset, false);
    offset += 4;

    // Timestamp
    const timestamp = view.getBigUint64(offset, false);
    offset += 8;

    // Audio Data
    const audioData = buffer.slice(offset);

    return { messageType, payloadLength, sequence, timestamp: Number(timestamp), audioData };
  }

  static encodeEndAudioMessage() {
    const buffer = new ArrayBuffer(8);
    const view = new DataView(buffer);

    // Message Type
    this.writeString(view, 0, "ENDT", 4);

    // Message Length
    view.setUint32(4, 0, false);

    return buffer;
  }

  static decodeEndAudioMessage(buffer) {
    const view = new DataView(buffer);

    // Message Type
    const messageType = this.readString(view, 0, 4);

    // Message Length
    const payloadLength = view.getUint32(4, false);

    return { messageType, payloadLength };
  }

  static encodeTextChunk(type, sequence, timestamp, text) {
    const textBytes = new TextEncoder().encode(text);
    const payloadLength = 4 + 8 + 4 + textBytes.length;
    const buffer = new ArrayBuffer(8 + payloadLength);
    const view = new DataView(buffer);
    let offset = 0;

    // Message Type
    this.writeString(view, offset, type, 4);
    offset += 4;

    // Message Length
    view.setUint32(offset, payloadLength, false);
    offset += 4;

    // Sequence
    view.setUint32(offset, sequence, false);
    offset += 4;

    // Timestamp
    view.setBigUint64(offset, BigInt(timestamp), false);
    offset += 8;

    // Text Length
    view.setUint32(offset, textBytes.length, false);
    offset += 4;

    // Text Data
    new Uint8Array(buffer, offset, textBytes.length).set(textBytes);

    return buffer;
  }

  static decodeTextChunk(buffer) {
    const view = new DataView(buffer);
    let offset = 0;

    // Message Type
    const messageType = this.readString(view, offset, 4);
    offset += 4;

    // Message Length
    const payloadLength = view.getUint32(offset, false);
    offset += 4;

    // Sequence
    const sequence = view.getUint32(offset, false);
    offset += 4;

    // Timestamp
    const timestamp = view.getBigUint64(offset, false);
    offset += 8;

    // Text Length
    const textLength = view.getUint32(offset, false);
    offset += 4;

    // Text Data
    const text = this.readString(view, offset, textLength);

    return { messageType, payloadLength, sequence, timestamp: Number(timestamp), text };
  }

  // Helper methods
  static writeString(view, offset, str, length) {
    const bytes = new TextEncoder().encode(str.padEnd(length, "\0"));
    new Uint8Array(view.buffer, offset, length).set(bytes);
  }

  static readString(view, offset, length) {
    const bytes = new Uint8Array(view.buffer, offset, length);
    return new TextDecoder().decode(bytes).replace(/\0/g, "");
  }
}
