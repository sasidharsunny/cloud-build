let ws, audioContext, audioWorkletNode, stream, source, ordinal = 0, producerConn;

const API_BASE_ADDRESS = 'https://devvtn1.xavlab.xyz:8001';
const ORG_ID = '123e4567-e89b-12d3-a456-426614174999';
const API_KEY = '21c05051-0312-4b49-8608-4afe89236847';
const ASR_PROFILE_ID = '0973a0a7-c1f0-4c70-8c2a-3ebb3bb778ee';
const STORAGE_PROVIDER_ID = '3d1cdd5c-7f8f-4624-b0c4-12e99fd64465'; // '22578c5f-e8f1-4f52-ae3c-1e3526cad9a1';

/**
 * @returns {{audioSessionId:string ,connectionToken:string, streamingUrl:string}} 
 */
async function createConnection() {
  // POST /orgs/{orgId}/create-audio-session with authorization header and asrProfileId in the body
  const rawResponse = await fetch(`${API_BASE_ADDRESS}/orgs/${ORG_ID}/create-audio-session`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': API_KEY,
    },
    body: JSON.stringify({
      asrProfileId: ASR_PROFILE_ID,
      storageProviderId: STORAGE_PROVIDER_ID,
    }),
  });

  return await rawResponse.json();
}

/**
 * @param {string} url
 */
async function connectWebsocket(url) {
  return new Promise((resolve, reject) => {
    ws = new WebSocket(url);
    ws.onopen = () => {
      resolve();
      console.log('WebSocket connected');
    };
    ws.onmessage = async (event) => {
      const message = await event.data.arrayBuffer();
      const messageType = MessageCoder.getMessageType(message);
      if (messageType == 'SUCC') {
        console.error('Authentication success');
        await onAuthenticated();
      } else if (messageType == 'FAIL') {
        console.error('Authentication failed');
      }
      else {
        console.log('Unhandled WebSocket message:', event.data);  
      }
    };
    ws.onclose = () => {
      console.log('WebSocket closed');
    };
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      reject(error);
    };
  });
}

async function onAuthenticated() {
  // Access microphone
  stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  audioContext = new AudioContext({ sampleRate: 16000 });
  source = audioContext.createMediaStreamSource(stream);

  // Check if AudioContext sample rate is 16kHz as reqested
  if (audioContext.sampleRate !== 16000) {
    console.warn(`Current sample rate is ${audioContext.sampleRate}Hz. Downsampling to 16kHz.`);
  }

  // Load and add the audio worklet processor
  await audioContext.audioWorklet.addModule('pcm-processor.js');
  audioWorkletNode = new AudioWorkletNode(audioContext, 'pcm-processor');

  source.connect(audioWorkletNode);
  audioWorkletNode.connect(audioContext.destination);

  // Listen to processed 16kHz PCM mono audio from the AudioWorkletProcessor
  audioWorkletNode.port.onmessage = (event) => {
    if (ws.readyState == ws.OPEN) {
      const { pcmData } = event.data;
      streamToVTN(pcmData);
    }
    else if (ws.readyState == ws.CLOSING || ws.readyState == ws.CLOSED) {
      console.log('Websocket is closing or closed. Disconnecting.');
      audioWorkletNode.port.onmessage = null;
    }
  };

  const startButton = document.getElementById('start');
  startButton.disabled = true;
  const stopButton = document.getElementById('stop');
  stopButton.disabled = false;
  ordinal = 0;
}

async function startProcessing() {
  producerConn = await createConnection();
  document.getElementById('audioId').textContent = producerConn.audioSessionId;
  await connectWebsocket(producerConn.streamingUrl);

  // Send auth message
  const authMessage = MessageCoder.encodeAuthMessage(producerConn.connectionToken, producerConn.audioSessionId);
  console.log('Sending auth message:', authMessage.byteLength);
  ws.send(authMessage);
}


function stopProcessing() {
  audioWorkletNode.disconnect();
  source.disconnect();
  stream.getTracks().forEach((track) => track.stop());
  audioContext.close();

  // Build end audio message
  const endMessage = MessageCoder.encodeEndAudioMessage();
  console.log('Sending end message:', endMessage.byteLength);

  // TODO: use previously open WebSocket to send a message to VTN to end the session

  ws.send(endMessage);

  document.getElementById('start').disabled = false;
  document.getElementById('stop').disabled = true;
  document.getElementById('audioId').textContent = null;
}

// Example PCM processing
function streamToVTN(pcmData) {
  console.log('Processing PCM:', pcmData.byteLength, 'samples');

  // Build audio chunk message
  const pcmMessage = MessageCoder.encodeAudioChunk(ordinal, Date.now(), pcmData);
  ordinal++;
  console.log('Sending audio chunk message:', pcmMessage.byteLength);
  ws.send(pcmMessage);
}

async function reconnect() {
  await connectWebsocket(producerConn.streamingUrl);

  // Send auth message
  const authMessage = MessageCoder.encodeAuthMessage(producerConn.connectionToken, producerConn.audioSessionId);
  console.log('Sending auth message:', authMessage.byteLength);
  ws.send(authMessage);
}



document.getElementById('start').addEventListener('click', ()=> startProcessing());
document.getElementById('stop').addEventListener('click', () => stopProcessing());
document.getElementById('reconnect').addEventListener('click', () => reconnect());
