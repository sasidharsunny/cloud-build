create schema public;

-- to create all needed database tables run:
-- node --enable-source-maps --env-file=.env.dev --experimental-specifier-resolution=node --loader ts-node/esm src/index.ts --sync-db

INSERT INTO public.organizations (id,name,status,metadata,created_at,updated_at) VALUES
	 ('123e4567-e89b-12d3-a456-426614174999','test','active','{}','2024-11-25 14:56:00.000','2024-11-25 14:56:00.000');

-- replace the AZURE_KEY with a proper azure key
INSERT INTO public.asr_providers (id,organization_id,name,"type",metadata,created_at,updated_at,config) VALUES
	 ('02668ebe-3d55-400f-98df-72ef481d12b9','123e4567-e89b-12d3-a456-426614174999','Azure ASR','azure','{}','2024-11-29 11:53:14.188','2024-11-29 11:53:14.188','{"azureKey":"AZURE_KEY","azureRegion":"westeurope"}');

INSERT INTO api_keys ("key",organization_id,status,roles,created_at,updated_at) VALUES
	 ('21c05051-0312-4b49-8608-4afe89236847','123e4567-e89b-12d3-a456-426614174999','active','{view-api-keys,modify-api-keys,create-api-keys,revoke-api-keys,create-orgs,modify-orgs,view-orgs,create-storage-providers,modify-storage-providers,remove-storage-providers,view-storage-providers,create-asr-providers,modify-asr-providers,remove-asr-providers,view-asr-providers,create-asr-profiles,modify-asr-profiles,remove-asr-profiles,view-asr-profiles,modify-recordings,remove-recordings,view-recordings,modify-transcripts,remove-transcripts,view-transcripts,create-sessions,view-sessions}','2024-11-22 00:00:00+01','2024-11-26 16:00:21.211+01');

INSERT INTO asr_profiles (id,organization_id,provider_id,name,metadata,created_at,updated_at) VALUES
	 ('0973a0a7-c1f0-4c70-8c2a-3ebb3bb778ee','123e4567-e89b-12d3-a456-426614174999','02668ebe-3d55-400f-98df-72ef481d12b9','test','{"speechLanguage":"en-US","dictionaryPhrases":["Telus"]}','2024-11-28 00:00:00+01','2024-11-28 16:34:32+01');

-- replace KEY_ID, ACCESS_KEY and BUCKET_NAME with proper ones
INSERT INTO public.storage_providers (id,organization_id,name,"type",metadata,config,created_at,updated_at) VALUES
	 ('3d1cdd5c-7f8f-4624-b0c4-12e99fd64465','123e4567-e89b-12d3-a456-426614174999','S3 Test','s3','{}','{
  "accessKeyId": "KEY_ID",
  "secretAccessKey": "ACCESS_KEY",
  "region": "us-east-1",
  "bucket": "BUCKET_NAME",
  "rootDirectory":"./test/"
}','2024-12-12 00:00:00+01','2024-12-12 00:00:00+01');
