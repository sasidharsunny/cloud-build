import * as fs from 'fs';
import * as https from 'https';

import { WebSocketServer } from 'ws';

import { logger } from './logger';

/**
 * Creates a WebSocket server.
 * @param port The port to listen on.
 */
export function startWebSocketServer(port: number) {
  let server: WebSocketServer;
  if (process.env.WS_SSL_CERT_PATH && process.env.WS_SSL_KEY_PATH) {
    const httpServer = https.createServer({
      cert: fs.readFileSync(process.env.WS_SSL_CERT_PATH),
      key: fs.readFileSync(process.env.WS_SSL_KEY_PATH),
    });
    server = new WebSocketServer({
      server: httpServer,
      verifyClient: (info, cb) => {
        cb(true);
      }
    });
    httpServer.listen(port, () => {
      logger.info(`HTTPS server started on port ${port}`);
    });
    logger.info('Created WebSocket server with SSL enabled.');
  } else {
    server = new WebSocketServer({
      port
    });
    logger.info('Created unsecure WebSocket server.');
  }

  return server;
}