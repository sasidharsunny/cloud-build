import { Role } from '../db/models';
import { Forbidden } from '../errors';
import { RequestContext } from '../models/requestContext';

/**
 * Ensures that the requester has the required role to perform an operation.
 * @param requiredRole The role required to perform the operation.
 * @param operation The operation being performed.
 * @param ctx The request context.
 */
export function ensureRole(requiredRole: Role, operation: string, ctx: RequestContext) {
  if (!ctx.roles.includes(requiredRole)) {
    throw new Forbidden(`You do not have the required role to ${operation}`);
  }
}

/**
 * Ensures that the requester has access to the organization.
 * @param ctx The request context.
 * @param organizationId The organization ID to check access to.
 */
export function ensureOrganizationAccess(ctx: RequestContext) {
  if (ctx.requestedOrganizationId !== ctx.userOrganizationId && !ctx.fromMasterOrganization) {
    throw new Forbidden('You do not have access to this organization');
  }
}

/**
 * Ensures that the requester has the required role and access to the organization.
 * @param requiredRole The role required to perform the operation.
 * @param operation The operation being performed.
 * @param ctx The request context.
 * @param organizationId The organization ID to check access to.
 */
export function ensureRoleAndOrganizationAccess(requiredRole: Role, operation: string, ctx: RequestContext) {
  ensureRole(requiredRole, operation, ctx);
  ensureOrganizationAccess(ctx);
}
