/**
 * DecodedAudioChunk type represents the decoded audio chunk message.
 */
export type AudioChunkMessage = {
  messageType: string;
  payloadLength: number;
  sequence: number;
  timestamp: number;
  audioData: Buffer;
};

/**
 * DecodedAuth type represents the decoded authentication message.
 */
export type AuthMessage = {
  messageType: string;
  payloadLength: number;
  token: string;
  sessionId: string;
};

export type EndTransmissionMessage = {
  messageType: string;
  payloadLength: number;
};

/**
 * DecodedTextChunk type represents the decoded text chunk message.
 */
export type TextChunkMessage = {
  messageType: string;
  payloadLength: number;
  sequence: number;
  timestamp: number;
  text: string;
};

/**
 * MessageCoder class provides static methods to encode and decode messages 
 * for the audio and text communication between the client and the server
 * as specified in the protocol (see /docs/streaming-api for details).
 */
export class MessageCoder {
  static getMessageType(buffer: Buffer): string {
    return this.readString(buffer, 0, 4);
  }

  static encodeAuthMessage(token: string, sessionId: string): Buffer {
    const tokenBytes = Buffer.from(token, 'utf-8');
    const sessionIdBytes = Buffer.from(sessionId, 'utf-8');

    const payloadLength = 4 + tokenBytes.length + 2 + sessionIdBytes.length;
    const buffer = Buffer.alloc(8 + payloadLength);
    let offset = 0;

    // Message Type
    this.writeString(buffer, offset, 'AUTH', 4);
    offset += 4;

    // Message Length
    buffer.writeUInt32BE(payloadLength, offset);
    offset += 4;

    // Token Length
    buffer.writeUInt16BE(tokenBytes.length, offset);
    offset += 2;

    // Token
    tokenBytes.copy(buffer, offset);
    offset += tokenBytes.length;

    // Session ID Length
    buffer.writeUInt16BE(sessionIdBytes.length, offset);
    offset += 2;

    // Session ID
    sessionIdBytes.copy(buffer, offset);

    return buffer;
  }

  static decodeAuthMessage(buffer: Buffer): AuthMessage {
    let offset = 0;

    // Message Type
    const messageType = this.readString(buffer, offset, 4);
    offset += 4;

    if (messageType !== 'AUTH') {
      throw new Error('Invalid message type');
    }

    // Message Length
    const payloadLength = buffer.readUInt32BE(offset);
    offset += 4;

    // Token Length
    const tokenLength = buffer.readUInt16BE(offset);
    offset += 2;

    // Token
    const token = this.readString(buffer, offset, tokenLength);
    offset += tokenLength;

    // Session ID Length
    const sessionIdLength = buffer.readUInt16BE(offset);
    offset += 2;

    // Session ID
    const sessionId = this.readString(buffer, offset, sessionIdLength);

    return { messageType, payloadLength, token, sessionId };
  }

  static encodeAudioChunkMessage(sequence: number, timestamp: number, audioData: Buffer): Buffer {
    const payloadLength = 4 + 8 + audioData.length;
    const buffer = Buffer.alloc(8 + payloadLength);
    let offset = 0;

    // Message Type
    this.writeString(buffer, offset, 'AUDC', 4);
    offset += 4;

    // Message Length
    buffer.writeUInt32BE(payloadLength, offset);
    offset += 4;

    // Sequence
    buffer.writeUInt32BE(sequence, offset);
    offset += 4;

    // Timestamp
    buffer.writeBigUInt64BE(BigInt(timestamp), offset);
    offset += 8;

    // Audio Data
    audioData.copy(buffer, offset);

    return buffer;
  }

  static decodeAudioChunkMessage(buffer: Buffer): AudioChunkMessage {
    let offset = 0;

    // Message Type
    const messageType = this.readString(buffer, offset, 4);
    offset += 4;

    if (messageType !== 'AUDC') {
      throw new Error('Invalid message type');
    }

    // Message Length
    const payloadLength = buffer.readUInt32BE(offset);
    offset += 4;

    // Sequence
    const sequence = buffer.readUInt32BE(offset);
    offset += 4;

    // Timestamp
    const timestamp = Number(buffer.readBigUInt64BE(offset));
    offset += 8;

    // Audio Data
    const audioData = buffer.slice(offset);

    return { messageType, payloadLength, sequence, timestamp, audioData };
  }

  static encodeEndTransmissionMessage(): Buffer {
    const buffer = Buffer.alloc(8);

    // Message Type
    this.writeString(buffer, 0, 'ENDT', 4);

    // Message Length
    buffer.writeUInt32BE(0, 4);

    return buffer;
  }

  static decodeEndTransmissionMessage(buffer: Buffer): EndTransmissionMessage {
    const messageType = this.readString(buffer, 0, 4);
    const payloadLength = buffer.readUInt32BE(4);

    if (payloadLength !== 0) {
      throw new Error('Invalid message length');
    }
    if (messageType !== 'ENDT') {
      throw new Error('Invalid message type');
    }

    return { messageType, payloadLength };
  }

  static encodeTextChunkMessage(type: string, sequence: number, timestamp: number, text: string): Buffer {
    const textBytes = Buffer.from(text, 'utf-8');
    const payloadLength = 4 + 8 + 4 + textBytes.length;
    const buffer = Buffer.alloc(8 + payloadLength);
    let offset = 0;

    // Message Type
    this.writeString(buffer, offset, type, 4);
    offset += 4;

    // Message Length
    buffer.writeUInt32BE(payloadLength, offset);
    offset += 4;

    // Sequence
    buffer.writeUInt32BE(sequence, offset);
    offset += 4;

    // Timestamp
    buffer.writeBigUInt64BE(BigInt(timestamp), offset);
    offset += 8;

    // Text Length
    buffer.writeUInt32BE(textBytes.length, offset);
    offset += 4;

    // Text Data
    textBytes.copy(buffer, offset);

    return buffer;
  }

  static decodeTextChunkMessage(buffer: Buffer): TextChunkMessage {
    let offset = 0;

    // Message Type
    const messageType = this.readString(buffer, offset, 4);
    offset += 4;

    if (messageType !== 'RTXT' && messageType !== 'STXT') {
      throw new Error('Invalid message type');
    }

    // Message Length
    const payloadLength = buffer.readUInt32BE(offset);
    offset += 4;

    // Sequence
    const sequence = buffer.readUInt32BE(offset);
    offset += 4;

    // Timestamp
    const timestamp = Number(buffer.readBigUInt64BE(offset));
    offset += 8;

    // Text Length
    const textLength = buffer.readUInt32BE(offset);
    offset += 4;

    // Text Data
    const text = this.readString(buffer, offset, textLength);

    return { messageType, payloadLength, sequence, timestamp, text };
  }

  static encodeAuthenticationSuccessMessage(): Buffer {
    const buffer = Buffer.alloc(8);

    // Message Type
    this.writeString(buffer, 0, 'SUCC', 4);

    // Message Length
    buffer.writeUInt32BE(0, 4);

    return buffer;
  }

  static encodeAuthenticationFailedMessage(): Buffer {
    const buffer = Buffer.alloc(8);

    // Message Type
    this.writeString(buffer, 0, 'FAIL', 4);

    // Message Length
    buffer.writeUInt32BE(0, 4);

    return buffer;
  }

  // Helper methods
  private static writeString(buffer: Buffer, offset: number, str: string, length: number): void {
    const paddedStr = str.padEnd(length, '\0');
    buffer.write(paddedStr, offset, length, 'utf-8');
  }

  private static readString(buffer: Buffer, offset: number, length: number): string {
    return buffer.toString('utf-8', offset, offset + length).replace(/\0/g, '');
  }
}
