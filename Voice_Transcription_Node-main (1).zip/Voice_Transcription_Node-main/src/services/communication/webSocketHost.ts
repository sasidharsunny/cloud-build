
import { v4 } from 'uuid';
import { WebSocket, WebSocketServer } from 'ws';

import { logger } from '../../utils/logger';
import { AuthMessage, MessageCoder } from '../../utils/messaging';
import { startWebSocketServer } from '../../utils/webSockets';

export type WebSocketEx = WebSocket & {
  host: WebSocketHost;
  connectionToken: string;
  isAuthenticated: boolean;
};

/**
 * WebSocket based communication host. Used as a base for both producer and consumer hosts.
 */
export class WebSocketHost {
  private server: WebSocketServer;
  private activeConnections: Map<string, WebSocketEx> = new Map();
  private authHandler: (authMessage: AuthMessage) => Promise<boolean>;
  private connectionClosedHandlers: Array<(connectionToken: string) => void> = [];
  private connectionOpenedHandlers: Array<(connectionToken: string) => void> = [];
  private connectionFailedHandlers: Array<(connectionToken: string, error: Error) => void> = [];
  private messageHandlers: Map<string, (connectionToken: string, message: any) => Promise<void>> = new Map();

  constructor() { }

  /**
   * Adds a handler for when a connection is opened.
   * @param handler The handler to add.
   */
  addConnectionOpenedHandler(handler: (connectionToken: string) => void): void {
    this.connectionOpenedHandlers.push(handler);
  }

  /**
   * Adds a handler for when a connection is closed.
   * @param handler The handler to add.
   */
  addConnectionClosedHandler(handler: (connectionToken: string) => void): void {
    this.connectionClosedHandlers.push(handler);
  }

  /**
   * Adds a handler for when a connection fails (closed because of a fatal error).
   * @param handler The handler to add.
   */
  addConnectionFailedHandler(handler: (connectionToken: string, error: Error) => void): void {
    this.connectionFailedHandlers.push(handler);
  }

  /**
   * Adds a handler for a specific message type.
   * @param messageType The message type to handle.
   * @param handler The handler to add.
   */
  addMessageHandler(messageType: string, handler: (connectionToken: string, message: any) => Promise<void>): void {
    this.messageHandlers.set(messageType, handler);
  }

  /**
   * Sets the authentication handler.
   * @param handler The handler to set.
   */
  setAuthHandler(handler: (authMessage: AuthMessage) => Promise<boolean>) {
    this.authHandler = handler;
  }

  /**
   * Sends a message to a connection.
   * @param connectionToken The connection token to send the message to.
   * @param message The raw message to send.
   */
  async sendMessage(connectionToken: string, message: any) {
    const ws = this.activeConnections.get(connectionToken);
    if (!ws) {
      throw new Error('Connection not found');
    }

    ws.send(message);
  }

  /**
   * Starts the WebSocket server for Voice Transription Node.
   */
  public async start(config: any) {
    if (!this.authHandler) {
      throw new Error('Auth handler not set');
    }
    if (this.server) {
      throw new Error('Server already started');
    }
    if (!config.port) {
      throw new Error('Port not set');
    }

    const port = config.port;
    this.server = startWebSocketServer(port);

    this.server.on('connection', async (ws: WebSocketEx) => {
      ws.connectionToken = v4();
      ws.host = this;
      logger.info({ connectionToken: ws.connectionToken }, 'WebSocket Connected');

      ws.on('message', async (data: any) => {
        // Handle incoming messages
        if (!ws.isAuthenticated) {
          await this.handleAuth(ws, data);
          ws.isAuthenticated = true;
        } else {
          await this.handleMessage(ws, data);
        }
      });

      ws.on('close', async () => {
        logger.info({ connectionToken: ws.connectionToken }, 'WebSocket Disconnected');
        this.activeConnections.delete(ws.connectionToken);

        // Notify that the connection is closed
        for (const handler of this.connectionClosedHandlers) {
          try {
            await handler(ws.connectionToken);
          } catch (err) {
            logger.error({ connectionToken: ws.connectionToken, error: err }, 'Error in connection closed handler');
          }
        }
      });

      ws.on('error', async (err) => {
        logger.error({ connectionToken: ws.connectionToken, error: err }, 'WebSocket Error');
        this.activeConnections.delete(ws.connectionToken);

        // Notify that the connection failed
        for (const handler of this.connectionFailedHandlers) {
          try {
            await handler(ws.connectionToken, err);
          } catch (err) {
            logger.error({ connectionToken: ws.connectionToken, error: err }, 'Error in connection failed handler');
          }
        }
      });

      this.activeConnections.set(ws.connectionToken, ws);

      // Notify that the connection is opened
      for (const handler of this.connectionOpenedHandlers) {
        try {
          await handler(ws.connectionToken);
        } catch (err) {
          logger.error({ connectionToken: ws.connectionToken, error: err }, 'Error in connection opened handler');
        }
      }
    });

    logger.info('WebSocket server started.');
  }

  /**
   * Handles an incoming message for authentication.
   * @param ws The WebSocket connection.
   * @param data The incoming message data.
   */
  private async handleAuth(ws: WebSocketEx, data: any) {
    const messageType = MessageCoder.getMessageType(data);
    if (messageType !== 'AUTH') {
      logger.error({ connectionToken: ws.connectionToken }, `Invalid message type ${messageType}`);
      ws.close(4000, 'Invalid message type');
      return;
    }

    try {
      logger.info('Received authentication message');
      const authMessage = MessageCoder.decodeAuthMessage(data);

      const isAuthenticated = await this.authHandler(authMessage);
      if (!isAuthenticated) {
        logger.info({ connectionToken: ws.connectionToken }, 'Authentication failed');
        this.activeConnections.delete(ws.connectionToken);
        ws.send(MessageCoder.encodeAuthenticationFailedMessage());
        ws.close(4001, 'Authentication failed');
        return;
      }
      // replace the connection token generated within connect handler with token from database
      this.activeConnections.delete(ws.connectionToken);
      ws.connectionToken = authMessage.token;
      this.activeConnections.set(ws.connectionToken, ws);
      ws.send(MessageCoder.encodeAuthenticationSuccessMessage());
    } catch (err) {
      // TODO: fail connection
      logger.error({ connectionToken: ws.connectionToken, error: err }, 'Error authenticating');
      ws.close(4001, err.message);
    }
  }

  /**
   * Handles an incoming message.
   * @param ws The WebSocket connection.
   * @param data The incoming message data.
   */
  private async handleMessage(ws: WebSocketEx, data: any) {
    const messageType = MessageCoder.getMessageType(data);
    logger.info({ connectionToken: ws.connectionToken }, `Received message of type ${messageType}`);

    if (!this.messageHandlers.has(messageType)) {
      // TODO: fail connection
      logger.error({ connectionToken: ws.connectionToken }, 'Invalid message type');
      ws.close(4000, 'Invalid message type');
      return;
    }

    const handler = this.messageHandlers.get(messageType);
    try {
      await handler(ws.connectionToken, data);
    } catch (err) {
      logger.error(err, 'Error handling message');
      ws.close(4500, 'Error handling message');
    }
  }
}
