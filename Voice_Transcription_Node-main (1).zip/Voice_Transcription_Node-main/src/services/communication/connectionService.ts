import { injectable } from 'tsyringe';

import { CreateConnectionParams } from '../../api/contracts';
import { Connection } from '../../db/models';
import { RequestContext } from '../../models/requestContext';

@injectable()
export class ConnectionService {

  async createConnection(ctx: RequestContext, params: CreateConnectionParams) {
    const connection = await Connection.create(params);
    return {
      connection,
      streamingUrl: params.connectionType == 'producer' ?
        this.buildProducerStreamingUrl(ctx.requestedOrganizationId) :
        this.buildClientStreamingUrl(ctx.requestedOrganizationId),
    };
  }

  async getConnection(connectionToken: string) {
    const connection = await Connection.findOne({ where: { connectionToken } });
    return connection;
  }

  private buildProducerStreamingUrl(organizationId: string) {
    return `${process.env.WS_BASE_URL}:${process.env.WS_PRODUCER_PORT}/orgs/${organizationId}/audio-stream`;
  }

  private buildClientStreamingUrl(organizationId: string) {
    return `${process.env.WS_BASE_URL}:${process.env.WS_CONSUMER_PORT}/orgs/${organizationId}/text-stream`;
  }
}
