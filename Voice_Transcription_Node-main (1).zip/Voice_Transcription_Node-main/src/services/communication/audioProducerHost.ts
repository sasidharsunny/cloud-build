import { injectable } from 'tsyringe';

import { WebSocketHost } from './webSocketHost';

@injectable()
export class AudioProducerHost extends WebSocketHost { }

