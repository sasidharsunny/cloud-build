
import * as fs from 'fs';
import * as https from 'https';

import { attachControllerInstances, Container, ERROR_MIDDLEWARE } from '@decorators/express';
import cors from 'cors';
import express from 'express';
import swaggerUi from 'swagger-ui-express';
import { container, injectable } from 'tsyringe';

import { ApiDocsController } from '../../controllers/api-docs/apiDocsController';
import { HeartbeatController } from '../../controllers/heartbeat/heartbeatController';
import { ApiKeysController } from '../../controllers/organizations/api-keys/apiKeysController';
import { AsrProfilesController } from '../../controllers/organizations/asr-profiles/asrProfilesController';
import { AsrProvidersController } from '../../controllers/organizations/asr-providers/asrProvidersController';
import { AudioSessionsController } from '../../controllers/organizations/audio-sessions/audioSessionsController';
import { AudioRecordingsController } from '../../controllers/organizations/audio-sessions/recordings/audioRecordingsController';
import { TranscriptController } from '../../controllers/organizations/audio-sessions/transcripts/transcriptsController';
import { CreateAudioSessionController } from '../../controllers/organizations/create-audio-session/createAudioSessionController';
import { JoinAudioSessionController } from '../../controllers/organizations/join-audio-session/joinAudioSessionController';
import { OrganizationController } from '../../controllers/organizations/organizationsController';
import { StorageProvidersController } from '../../controllers/organizations/storage-providers/storageProvidersController';
import { NotFound } from '../../errors';
import { handleErrorMiddleware } from '../../middlewares/errorHandlerMiddleware';
import { validateApiKeyMiddleware } from '../../middlewares/validateApiKeyMiddleware';
import { logger } from '../../utils/logger';

const EXPRESS_PORT = process.env.EXPRESS_PORT || 8000;

const controllers = [
  container.resolve(ApiDocsController),
  container.resolve(HeartbeatController),
  container.resolve(ApiKeysController),
  container.resolve(OrganizationController),
  container.resolve(StorageProvidersController),
  container.resolve(AsrProvidersController),
  container.resolve(AsrProfilesController),
  container.resolve(AudioRecordingsController),
  container.resolve(TranscriptController),
  container.resolve(CreateAudioSessionController),
  container.resolve(JoinAudioSessionController),
  container.resolve(AudioSessionsController),
];

@injectable()
export class ExpressHost {
  private app: express.Application;

  constructor() { }

  async serve() {
    this.app = express();
    this.app.use(cors());
    this.app.use(express.json());
    this.app.use(validateApiKeyMiddleware);
    this.app.use('/api-docs', swaggerUi.serve);

    await attachControllerInstances(this.app, controllers);

    Container.provide([{ provide: ERROR_MIDDLEWARE, useValue: handleErrorMiddleware }]);

    this.app.use('*', function (req, res) {
      const msg = `Cannot ${req.method.toUpperCase()} ${req.baseUrl}`;
      return handleErrorMiddleware(new NotFound(msg), req, res, () => { });
    });


    const certificate = this.readCertificate();
    if (!certificate) {
      this.app.listen(EXPRESS_PORT, () => {
        logger.info(`HTTP Express host listening on port ${EXPRESS_PORT}`);
      });
    }
    else {
      const server = https.createServer({ ...certificate }, this.app);
      server.listen(EXPRESS_PORT, () => {
        logger.info(`HTTPS Express host listening on port ${EXPRESS_PORT}`);
      });
    }
  }

  private readCertificate() {
    const keyPath = process.env.HTTP_SSL_KEY_PATH;
    const crtPath = process.env.HTTP_SSL_CERT_PATH;
    if (fs.existsSync(keyPath) && fs.existsSync(crtPath)) {
      const key = fs.readFileSync(keyPath);
      const cert = fs.readFileSync(crtPath);
      return { key, cert };
    }

    return null;
  }
}
