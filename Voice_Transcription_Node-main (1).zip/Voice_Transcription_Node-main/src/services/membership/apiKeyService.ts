import { Op } from 'sequelize';
import { injectable } from 'tsyringe';

import { ApiKey, ApiKeyStatus, Role } from '../../db/models';
import { NotFound } from '../../errors';
import { RequestContext } from '../../models/requestContext';
import { logger } from '../../utils/logger';
import { ensureRoleAndOrganizationAccess } from '../../utils/securityChecks';

export type TokenValidationResult = {
  isValid: boolean;
  apiKey?: ApiKey;
};

@injectable()
export class ApiKeyService {

  /**
   * Creates new API key, by default with status = `inactive` and roles = `[]`
   *
   * @param {RequestContext} ctx
   * @param {string} organizationId
   * @param {Role[]} roles
   * @param {ApiKeyStatus} status
   * @return {*} 
   * @memberof ApiKeyService
   */
  async createAccessToken(ctx: RequestContext, roles: Role[], status: ApiKeyStatus) {
    ensureRoleAndOrganizationAccess('create-api-keys', 'create api key', ctx);
    return await ApiKey.create({ organizationId: ctx.requestedOrganizationId, roles, status });
  }

  /**
   * Modifies API key properties
   *
   * @param {RequestContext} ctx
   * @param {string} organizationId
   * @param {string} keyId
   * @param {{ roles?: Role[]}} props
   * @return {*} 
   * @memberof ApiKeyService
   */
  async modifyAccessToken(ctx: RequestContext, keyId: string, roles?: Role[]) {
    ensureRoleAndOrganizationAccess('modify-api-keys', 'modify api key', ctx);
    const [, rows] = await ApiKey.update(
      { roles },
      {
        where: { [Op.and]: [{ key: keyId }, { organizationId: ctx.requestedOrganizationId }] },
        returning: true
      }
    );

    if (!rows[0])
      throw new NotFound('API key not found');

    return rows[0];
  }

  /**
   * Changes status of an API key to `revoked`
   *
   * @param {RequestContext} ctx
   * @param {string} organizationId
   * @param {string} keyId
   * @return {*} 
   * @memberof ApiKeyService
   */
  async revokeAccessToken(ctx: RequestContext, keyId: string) {
    ensureRoleAndOrganizationAccess('revoke-api-keys', 'revoke api key', ctx);
    const [, rows] = await ApiKey.update(
      { status: 'revoked' },
      {
        where: { [Op.and]: [{ key: keyId }, { organizationId: ctx.requestedOrganizationId }] },
        returning: true
      }
    );

    if (!rows[0])
      throw new NotFound('API key not found');

    return rows[0];
  }

  /**
   * Returns API key object with given key value
   *
   * @param {RequestContext} ctx
   * @param {string} keyId
   * @return {*} 
   * @memberof ApiKeyService
   */
  async getAccessToken(ctx: RequestContext, keyId: string) {
    ensureRoleAndOrganizationAccess('view-api-keys', 'view api key', ctx);
    const key = await ApiKey.findOne(
      {
        where: {
          [Op.and]: [{ key: keyId }, { organizationId: ctx.requestedOrganizationId }]
        }
      }
    );


    if (!key)
      throw new NotFound('API key not found');

    return key;
  }

  /**
   * Returns list of all API keys
   *
   * @param {RequestContext} ctx
   * @return {*} 
   * @memberof ApiKeyService
   */
  async getAllAccessTokens(ctx: RequestContext) {
    ensureRoleAndOrganizationAccess('view-api-keys', 'view api keys', ctx);
    return await ApiKey.findAll({
      where: { organizationId: ctx.requestedOrganizationId }
    });
  }

  /**
   * Validates an API key.
   * @param token The access token to validate.
   * @returns The result of the validation.
   */
  async validateAccessToken(token: string): Promise<TokenValidationResult> {
    logger.info({ token }, 'Validating access token');

    try {
      const apiKey = await ApiKey.findByPk(token);
      if (!apiKey) {
        logger.warn({ token }, 'API Key not found');
        return { isValid: false };
      }

      logger.info({ token, status: apiKey.status }, 'API Key found');
      return {
        isValid: apiKey.status === 'active',
        apiKey
      };
    } catch (err) {
      logger.error({ token, error: err }, 'Error validating access token');
      return { isValid: false };
    }
  }
}
