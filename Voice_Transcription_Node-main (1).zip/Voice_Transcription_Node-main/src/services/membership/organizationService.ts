import { injectable } from 'tsyringe';

import { CreateOrganizationParams, UpdateOrganizationParams } from '../../api/contracts';
import { Organization } from '../../db/models';
import { Forbidden, NotFound } from '../../errors';
import { RequestContext } from '../../models/requestContext';
import { ensureRole, ensureRoleAndOrganizationAccess } from '../../utils/securityChecks';

export const MASTER_ORGANIZATION_ID = '123e4567-e89b-12d3-a456-426614174999'; // added org-id for master key

@injectable()
export class OrganizationService {

  constructor() { }

  /**
   * Creates new organization
   *
   * @param {RequestContext} ctx
   * @param {CreateOrganizationParams} params
   * @returns {*} 
   */
  async createOrganization(ctx: RequestContext, params: CreateOrganizationParams) {
    ensureRole('create-orgs', 'create organization', ctx);
    if (!ctx.fromMasterOrganization) {
      throw new Forbidden();
    }
    return await Organization.create(params);
  }

  /**
   * Updates existing organization
   *
   * @param {RequestContext} ctx
   * @param {UpdateOrganizationParams} params
   * @returns {*} 
   */
  async updateOrganization(ctx: RequestContext, params: UpdateOrganizationParams) {
    ensureRoleAndOrganizationAccess('modify-orgs', 'modify organization', ctx);
    const [, rows] = await Organization.update(params, { where: { id: ctx.requestedOrganizationId }, returning: true });
    if (!rows[0])
      throw new NotFound();

    return rows[0];
  }

  async getOrganization(ctx: RequestContext) {
    ensureRoleAndOrganizationAccess('view-orgs', 'view organization', ctx);
    const organization = await Organization.findOne({ where: { id: ctx.requestedOrganizationId } });
    if (!organization)
      return new NotFound();

    return organization;
  }

  async getOrganizations(ctx: RequestContext) {
    ensureRole('view-orgs', 'view organizations', ctx);
    if (!ctx.fromMasterOrganization) {
      throw new Forbidden();
    }
    return await Organization.findAll();
  }
}
