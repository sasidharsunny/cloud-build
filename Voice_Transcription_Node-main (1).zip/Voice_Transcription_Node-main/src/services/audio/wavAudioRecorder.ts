import * as fs from 'fs';
import path from 'path';

import { injectable } from 'tsyringe';
import { FileWriter } from 'wav';

import { IAudioRecorder } from './IAudioRecorder';
import { WavAudioRecorderConfig } from './wavAudioRecorderConfig';
import { AudioRecordingFileFormat } from '../../db/models';
import { AudioSessionContext } from '../sessions/audioSessionContext';

@injectable()
export class WavAudioRecorder implements IAudioRecorder {
  private writer: FileWriter | null = null;
  private config: WavAudioRecorderConfig = {
    bitDepth: 16,
    channels: 1,
    sampleRate: 16000,
    type: 'WavAudioRecorder',
  };
  private filename: string;
  private fullPath: string;

  constructor() { }

  public async startRecording(ctx: AudioSessionContext): Promise<void> {
    console.log(`Recording WAV audio for conversation ${ctx.sessionId}`);
    const targetDir = path.posix.join(process.env.LOCAL_AUDIO_DIR, ctx.organizationId);
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    this.filename = `${ctx.sessionId}.wav`;
    const subPath = path.posix.join(ctx.organizationId, this.filename);
    this.fullPath = path.posix.join(process.env.LOCAL_AUDIO_DIR, subPath);
    this.writer = new FileWriter(this.fullPath, {
      channels: this.config.channels,
      sampleRate: this.config.sampleRate,
      bitDepth: this.config.bitDepth,
    });

  }

  public async stopRecording(): Promise<void> {
    console.log('Recording stopped');
    if (this.writer) {
      this.writer.end();
      this.writer = null;
    }
  }

  public async write(chunk: Buffer): Promise<void> {
    this.writer.write(chunk);
  }

  public getFilename(): string {
    return this.filename;
  }

  public getFullPath(): string {
    return this.fullPath;
  }

  public getFileFormat(): AudioRecordingFileFormat {
    return 'wav';
  }
}
