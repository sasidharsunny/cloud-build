import { injectable } from 'tsyringe';

import { CreateAudioRecordingParams, UpdateAudioRecordingParams } from '../../api/contracts';
import { AudioRecording } from '../../db/models';
import { NotFound } from '../../errors';
import { RequestContext } from '../../models/requestContext';
import { ensureRoleAndOrganizationAccess } from '../../utils/securityChecks';

@injectable()
export class AudioRecordingsService {

  /**
   * Creates new recording using given `params`
   *
   * @param {RequestContext} ctx
   * @param {CreateAudioRecordingParams} params
   */
  async createRecording(ctx: RequestContext, params: CreateAudioRecordingParams) {
    return await AudioRecording.create({ ...params, organizationId: ctx.requestedOrganizationId });
  }

  /**
   * Updates audio recording with `id` using given `params`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   * @param {UpdateAudioRecordingParams} params
   */
  async updateRecording(ctx: RequestContext, audioSessionId: string, id: string, params: UpdateAudioRecordingParams) {
    ensureRoleAndOrganizationAccess('modify-recordings', 'modify audio recording', ctx);
    const [, rows] = await AudioRecording.update(params, {
      where: { id, audioSessionId, organizationId: ctx.requestedOrganizationId },
      returning: true
    });
    if (!rows[0])
      throw new NotFound();

    return rows[0];
  }

  /**
   * Deletes audio recording with `id`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   */
  async deleteRecording(ctx: RequestContext, audioSessionId: string, id: string) {
    ensureRoleAndOrganizationAccess('remove-recordings', 'remove audio recording', ctx);
    const recording = await AudioRecording.destroy({
      where: { id, audioSessionId, organizationId: ctx.requestedOrganizationId },
    });
    if (!recording)
      throw new NotFound();
  }

  /**
   * Returns audio recording with `id`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   */
  async getRecording(ctx: RequestContext, audioSessionId: string, id: string) {
    ensureRoleAndOrganizationAccess('view-recordings', 'view audio recording', ctx);
    const recording = await AudioRecording.findOne({
      where: { id, audioSessionId, organizationId: ctx.requestedOrganizationId },
    });
    if (!recording)
      throw new NotFound();

    return recording;
  }

  /**
   * Returns all audio recordings
   *
   * @param {RequestContext} ctx
   * @param {string} organizationId
   */
  async getRecordings(ctx: RequestContext, organizationId: string, audioSessionId: string) {
    ensureRoleAndOrganizationAccess('view-recordings', 'view audio recordings', ctx);
    return await AudioRecording.findAll({ where: { organizationId, audioSessionId } });
  }

  async createRecordingInternal(params: CreateAudioRecordingParams & { organizationId: string }) {
    return await AudioRecording.create({ ...params });
  }
}
