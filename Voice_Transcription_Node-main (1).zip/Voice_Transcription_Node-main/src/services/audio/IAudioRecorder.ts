import { AudioRecordingFileFormat } from '../../db/models';
import { AudioSessionContext } from '../sessions/audioSessionContext';

/**
 * Base interface for audio recorder.
 */
export interface IAudioRecorder {
  /**
   * Start recording audio.
   * @param ctx Conversation context to start recording audio for
   */
  startRecording(ctx: AudioSessionContext): Promise<void>;

  /**
   * Stop recording audio.
   */
  stopRecording(): Promise<void>;

  /**
   * Write an audio chunk.
   * @param chunk Audio chunk to write
   */
  write(chunk: Buffer): Promise<void>;

  /**
   * Get the filename of the audio file.
   */
  getFilename(): string;

  /**
   * Get the local path to the audio file.
   */
  getFullPath(): string;

  /**
   * Get file format
   */
  getFileFormat(): AudioRecordingFileFormat;
}

