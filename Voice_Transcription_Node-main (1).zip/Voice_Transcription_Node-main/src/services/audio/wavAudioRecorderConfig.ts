
export type WavAudioRecorderConfig = {
  type: 'WavAudioRecorder';

  /**
   * Expected number of channels.
   */
  channels: number;

  /**
   * Expected sample rate.
   */
  sampleRate: number;

  /**
   * Expected bit depth.
   */
  bitDepth: number;
};
