import * as azureSDK from 'microsoft-cognitiveservices-speech-sdk';
import { CancellationReason, PhraseListGrammar } from 'microsoft-cognitiveservices-speech-sdk';

import { IAsrProvider, TextChunk, TextRecognitionCallback } from './asrProvider';
import { logger } from '../../utils/logger';
import { AudioSessionContext } from '../sessions/audioSessionContext';

/**
 * Configuration for the Azure ASR provider.
 */
export type AzureAsrProviderConfig = {
  /**
   * The Azure subscription key for the speech recognition service.
   */
  azureKey: string;

  /**
   * The Azure region where the speech recognition service is hosted.
   */
  azureRegion: string;

  /**
   * The language code for the speech recognition.
   */
  speechLanguage: string;

  /**
   * The phrases to add to the speech recognition dictionary.
   */
  dictionaryPhrases: string[];
}

/**
 * This is an implementation of ASR provider using Azure Speech SDK.
 */
export class AzureAsrProvider implements IAsrProvider {
  private onPartialRecognition: TextRecognitionCallback;
  private onFinalRecognition: TextRecognitionCallback;
  private onStopped: () => void;
  private onError: (error: string) => void;
  private audioStream: azureSDK.PushAudioInputStream;
  private bufferArray: Buffer[] = [];
  private audioConfig: azureSDK.AudioConfig;
  private azureSpeechConfig: azureSDK.SpeechConfig;
  private conversationTranscriber: azureSDK.SpeechRecognizer;
  private recognising = false;
  private chunks: TextChunk[] = [];
  private totalDuration = 0;


  constructor(private config: AzureAsrProviderConfig) { }

  async start(ctx: AudioSessionContext) {
    this.chunks = [];
    this.totalDuration = 0;

    // Create a push stream for audio input
    logger.info({ ctx }, 'Azure ASR Creating Azure speech recognition instance');
    this.audioStream = azureSDK.AudioInputStream.createPushStream();
    this.audioConfig = azureSDK.AudioConfig.fromStreamInput(this.audioStream);
    this.azureSpeechConfig = azureSDK.SpeechConfig.fromSubscription(this.config.azureKey, this.config.azureRegion);
    this.azureSpeechConfig.speechRecognitionLanguage = this.config.speechLanguage;

    this.conversationTranscriber = new azureSDK.SpeechRecognizer(this.azureSpeechConfig, this.audioConfig);
    logger.info('Azure ASR Created Azure speech recognition instance');

    // add phrases to the phrase list if they are provided
    if (this.config.dictionaryPhrases) {
      const phraseList = PhraseListGrammar.fromRecognizer(this.conversationTranscriber);
      phraseList.addPhrases(this.config.dictionaryPhrases);
    }

    this.conversationTranscriber.startContinuousRecognitionAsync(
      () => {
        logger.info({ ctx }, 'Azure ASR started recognition');
        // Push all buffered audio to the stream
        for (const buffer of this.bufferArray) {
          this.audioStream.write(buffer.buffer);
        }
        // Clear the buffer array
        this.bufferArray = [];
        this.recognising = true;
      },
      (err: string) => {
        this.recognising = false;
        logger.error({ ctx, err }, 'Azure ASR error starting recognition:');
        if (this.onError) this.onError(err);
      }
    );

    this.conversationTranscriber.sessionStopped = () => {
      this.recognising = false;
      logger.info({ ctx }, 'Azure ASR session stopped event');
      this.conversationTranscriber.stopContinuousRecognitionAsync();
      if (this.onStopped) this.onStopped();
    };

    this.conversationTranscriber.canceled = (_, err) => {
      this.recognising = false;
      logger.info({ ctx, err }, 'Azure ASR canceled event');
      if (err.reason === CancellationReason.Error) {
        logger.error({ error: err.errorDetails }, 'Azure ASR Error: event cancelled');
      }
      this.conversationTranscriber.stopContinuousRecognitionAsync();
      if (this.onError) this.onError(err.errorDetails);
    };

    this.conversationTranscriber.sessionStarted = () => {
      logger.info({ ctx }, 'Azure ASR session started');
    };

    this.conversationTranscriber.recognizing = (_, e) => {
      if (!e?.result?.text) return;
      if (this.onPartialRecognition) {
        this.onPartialRecognition({
          chunkId: e.result.resultId,
          text: e.result.text
        });
      }
    };

    this.conversationTranscriber.recognized = (_, e) => {
      if (!e?.result?.text) return;
      this.totalDuration += e.result.duration;
      this.chunks.push({ chunkId: e.result.resultId, text: e.result.text, timestamp: new Date() });
      if (this.onFinalRecognition) {
        this.onFinalRecognition({
          chunkId: e.result.resultId,
          text: e.result.text,
          // convert audioPositionFrom and audioPositionTo from 1/10 000 000s to 1/1000s
          audioPositionFrom: e.result.offset / 10000,
          audioPositionTo: (e.result.offset + e.result.duration) / 10000
        });
      }
    };

  }

  async stop(ctx: AudioSessionContext) {
    this.conversationTranscriber.stopContinuousRecognitionAsync(
      () => {
        this.recognising = false;
        logger.info({ ctx }, 'Azure ASR stopped recognition');
      },
      (err: string) => {
        this.recognising = false;
        logger.error({ err }, 'Azure ASR error stopping recognition:');
        if (this.onError) this.onError(err);
      }
    );

  }

  async sendAudio(ctx: AudioSessionContext, audio: Buffer) {
    if (this.recognising) {
      // If the transcriber is started, write the buffer to the audio stream
      this.audioStream.write(audio.buffer);
    } else {
      // If the transcriber is not started, store the buffer in the array
      this.bufferArray.push(audio);
    }
  }

  setOnRecognizing(cb: TextRecognitionCallback): void {
    this.onPartialRecognition = cb;
  }

  setOnRecognized(cb: TextRecognitionCallback): void {
    this.onFinalRecognition = cb;
  }

  setOnRecognitionStopped(cb: () => void): void {
    this.onStopped = cb;
  }

  setOnError(cb: (error: string) => void): void {
    this.onError = cb;
  }

  getAllTextChunks(): TextChunk[] {
    return this.chunks;
  }

}
