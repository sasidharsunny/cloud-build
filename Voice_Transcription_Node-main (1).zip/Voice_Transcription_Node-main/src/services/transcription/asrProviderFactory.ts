import { injectable } from 'tsyringe';

import { IAsrProvider } from './asrProvider';
import { AzureAsrProvider, AzureAsrProviderConfig } from './azureAsrProvider';
import { AsrProfile, AsrProviderInfo } from '../../db/models';

@injectable()
export class AsrProviderFactory {
  /**
     * Creates an ASR provider for the given session.
      * @param providerInfo The provider information.
     * @returns The ASR provider.
     */
  public createProvider(providerInfo: AsrProviderInfo, providerProfile: AsrProfile): IAsrProvider {
    if (providerInfo.type === 'azure') {
      return new AzureAsrProvider({...providerInfo.config, ...providerProfile.metadata } as AzureAsrProviderConfig);
    } else {
      throw new Error('Invalid ASR provider type');
    }
  }
}