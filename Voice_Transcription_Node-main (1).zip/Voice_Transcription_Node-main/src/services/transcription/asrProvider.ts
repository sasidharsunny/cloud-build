import { AudioSessionContext } from '../sessions/audioSessionContext';

/**
 * Represents a callback that is called when a chunk of text is recognized.
 */
export type TextRecognitionCallback = (chunkData: {
  chunkId: string,
  text: string,
  audioPositionFrom?: number,
  audioPositionTo?: number
}) => void;

/**
 * Holds information about a single text chunk.
 */
export type TextChunk = {
  chunkId: string;
  text: string;
  timestamp: Date;
};

/**
 * Interface for an ASR provider (Google, Azure, etc.)
 * 
 * It's based on callbacks to allow for streaming recognition and error handling.
 * Before start is called, all callbacks should be set.
 */
export interface IAsrProvider {
  /**
   * Start the speech recognition for given context
   * @param ctx Audio session context
   */
  start(ctx: AudioSessionContext): Promise<void>;

  /**
   * Stop the speech recognition for given context
   * @param ctx Audio session context
   */
  stop(ctx: AudioSessionContext): Promise<void>;

  /**
   * Send audio to the speech recognition service
   * @param ctx Audio session context
   * @param audio Audio data to send
   */
  sendAudio(ctx: AudioSessionContext, audio: Buffer): Promise<void>;

  /**
   * Set the callback for when a chunk of text is recognized (partial result)
   * @param cb Callback to set
   */
  setOnRecognizing(cb: TextRecognitionCallback): void;

  /**
   * Set the callback for when a full chunk of text is recognized (final result)
   * @param cb Callback to set
   */
  setOnRecognized(cb: TextRecognitionCallback): void;

  /**
   * Set the callback for when the recognition is stopped
   * @param cb Callback to set
   */
  setOnRecognitionStopped(cb: () => void): void;

  /**
   * Set the callback for when a fatal recognition error occurs
   * @param cb Callback to set
   */
  setOnError(cb: (error: string) => void): void;

  /**
   * Get all the text chunks recognized since the last call to @see start
   * @returns Array of text chunks
   */
  getAllTextChunks(): TextChunk[];
}
