import { injectable } from 'tsyringe';

import { CreateAsrProviderParams, UpdateAsrProviderParams } from '../../api/contracts';
import { AsrProviderInfo } from '../../db/models';
import { NotFound } from '../../errors';
import { RequestContext } from '../../models/requestContext';
import { ensureRoleAndOrganizationAccess } from '../../utils/securityChecks';

@injectable()
export class AsrProvidersService {

  /**
   * Creates new ASR provider with given `props`
   *
   * @param {RequestContext} ctx
   * @param {CreateAsrProviderParams} params
   * @returns {*} 
   */
  async createAsrProvider(ctx: RequestContext, params: CreateAsrProviderParams) {
    ensureRoleAndOrganizationAccess('create-asr-providers', 'create ASR provider', ctx);
    return await AsrProviderInfo.create({ ...params, organizationId: ctx.requestedOrganizationId });
  }

  /**
   * Updates ASR provider with `id` using given `props`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   * @param {UpdateAsrProviderParams} params
   * @returns {*} 
   */
  async updateAsrProvider(ctx: RequestContext, id: string, params: UpdateAsrProviderParams) {
    ensureRoleAndOrganizationAccess('modify-asr-providers', 'modify ASR provider', ctx);
    const [, rows] = await AsrProviderInfo.update(params, {
      where: { id, organizationId: ctx.requestedOrganizationId }, returning: true
    });
    if (!rows[0])
      throw new NotFound();

    return rows[0];
  }

  /**
   * Deletes ASR provider with given `id`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   */
  async deleteAsrProvider(ctx: RequestContext, id: string) {
    ensureRoleAndOrganizationAccess('remove-asr-providers', 'remove ASR provider', ctx);
    const provider = await AsrProviderInfo.destroy({
      where: { id, organizationId: ctx.requestedOrganizationId }
    });
    if (!provider)
      throw new NotFound();
  }

  /**
   * Returns ASR provider with given `id`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   * @returns {*} 
   */
  async getAsrProvider(ctx: RequestContext, id: string) {
    ensureRoleAndOrganizationAccess('view-asr-providers', 'view ASR provider', ctx);
    const provider = await AsrProviderInfo.findOne({
      where: { id, organizationId: ctx.requestedOrganizationId }
    });
    if (!provider)
      throw new NotFound();

    return provider;
  }

  /**
   * Returns all ASR providers assigned to the organization with `organizationId`
   *
   * @param {RequestContext} ctx
   * @param {string} organizationId
   * @returns {*} 
   */
  async getAsrProviders(ctx: RequestContext, organizationId: string) {
    ensureRoleAndOrganizationAccess('view-asr-providers', 'view ASR providers', ctx);
    return await AsrProviderInfo.findAll({ where: { organizationId } });
  }
}
