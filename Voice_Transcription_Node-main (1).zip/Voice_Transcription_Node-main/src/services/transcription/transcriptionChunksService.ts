import { injectable } from 'tsyringe';

import { CreateTranscriptionChunk } from '../../api/contracts';
import { TranscriptionChunks } from '../../db/models';

@injectable()
export class TranscriptionChunksService {
  async createTranscriptionChunkInternal(params: CreateTranscriptionChunk) {
    return await TranscriptionChunks.create(params);
  }
}
