import { injectable } from 'tsyringe';

import { CreateTranscriptParams, UpdateTranscriptParams } from '../../api/contracts';
import { VoiceTranscript } from '../../db/models';
import { NotFound } from '../../errors';
import { RequestContext } from '../../models/requestContext';
import { ensureRoleAndOrganizationAccess } from '../../utils/securityChecks';

@injectable()
export class TranscriptsService {

  async createTranscript(ctx: RequestContext, params: CreateTranscriptParams) {
    return await VoiceTranscript.create({ ...params, organizationId: ctx.requestedOrganizationId });
  }

  async updateTranscript(ctx: RequestContext, audioSessionId: string, id: string, params: UpdateTranscriptParams) {
    ensureRoleAndOrganizationAccess('modify-transcripts', 'modify transcript', ctx);
    const [, rows] = await VoiceTranscript.update(params, {
      where: { id, audioSessionId, organizationId: ctx.requestedOrganizationId },
      returning: true
    });
    if (!rows[0])
      throw new NotFound();

    return rows[0];
  }

  async deleteTranscript(ctx: RequestContext, audioSessionId: string, id: string) {
    ensureRoleAndOrganizationAccess('remove-transcripts', 'remove transcript', ctx);
    const recording = await VoiceTranscript.destroy({
      where: { id, audioSessionId, organizationId: ctx.requestedOrganizationId }
    });
    if (!recording)
      throw new NotFound();
  }

  async getTranscript(ctx: RequestContext, audioSessionId: string, id: string) {
    ensureRoleAndOrganizationAccess('view-transcripts', 'view transcript', ctx);
    const recording = await VoiceTranscript.findOne({
      where: { id, audioSessionId, organizationId: ctx.requestedOrganizationId }
    });
    if (!recording)
      throw new NotFound();

    return recording;
  }

  async getTranscripts(ctx: RequestContext, audioSessionId: string) {
    ensureRoleAndOrganizationAccess('view-transcripts', 'view transcripts', ctx);
    return await VoiceTranscript.findAll({ where: { audioSessionId, organizationId: ctx.requestedOrganizationId } });
  }


  async createTranscriptInternal(params: CreateTranscriptParams) {
    return await VoiceTranscript.create(params);
  }
}
