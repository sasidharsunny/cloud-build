import { injectable } from 'tsyringe';

import { CreateAsrProfileParams, UpdateAsrProfileParams } from '../../api/contracts';
import { AsrProfile } from '../../db/models';
import { NotFound } from '../../errors';
import { RequestContext } from '../../models/requestContext';
import { ensureRoleAndOrganizationAccess } from '../../utils/securityChecks';

@injectable()
export class AsrProfilesService {

  /**
   * Creates new ASR profile with given `props`
   *
   * @param {RequestContext} ctx
   * @param {CreateAsrProfileParams} params
   * @returns {*} 
   */
  async createAsrProfile(ctx: RequestContext, params: CreateAsrProfileParams) {
    ensureRoleAndOrganizationAccess('create-asr-profiles', 'create ASR profile', ctx);
    return await AsrProfile.create({ ...params, organizationId: ctx.requestedOrganizationId });
  }

  /**
   * Updates ASR profile with `id` using given `props` 
   *
   * @param {RequestContext} ctx
   * @param {string} id
   * @param {UpdateAsrProfileParams} params
   * @returns {*} 
   */
  async updateAsrProfile(ctx: RequestContext, id: string, params: UpdateAsrProfileParams) {
    ensureRoleAndOrganizationAccess('modify-asr-profiles', 'modify ASR profile', ctx);
    const [, rows] = await AsrProfile.update(params, {
      where: { id, organizationId: ctx.requestedOrganizationId },
      returning: true
    });
    if (!rows[0])
      throw new NotFound();

    return rows[0];
  }

  /**
   * Deletes ASR profile with given `id`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   */
  async deleteAsrProfile(ctx: RequestContext, id: string) {
    ensureRoleAndOrganizationAccess('remove-asr-profiles', 'remove ASR profile', ctx);
    const profile = await AsrProfile.destroy({
      where: { id, organizationId: ctx.requestedOrganizationId }
    });
    if (!profile)
      throw new NotFound();
  }

  /**
   * Returns ASR profile with given `id`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   * @returns {*} 
   */
  async getAsrProfile(ctx: RequestContext, id: string) {
    ensureRoleAndOrganizationAccess('view-asr-profiles', 'view ASR profile', ctx);
    const profile = await AsrProfile.findOne({
      where: { id, organizationId: ctx.requestedOrganizationId }
    });
    if (!profile)
      throw new NotFound();

    return profile;
  }

  /**
   * Returns all ASR profile assigned to the organization with `organizationId`
   *
   * @param {RequestContext} ctx
   * @param {string} organizationId
   * @returns {*} 
   */
  async getAsrProfiles(ctx: RequestContext, organizationId: string) {
    ensureRoleAndOrganizationAccess('view-asr-profiles', 'view ASR profiles', ctx);
    return await AsrProfile.findAll({ where: { organizationId } });
  }

  async getAsrProfileInternal(id: string) {
    const profile = await AsrProfile.findOne({ where: { id } });
    if (!profile)
      throw new NotFound();

    return profile;
  }
}
