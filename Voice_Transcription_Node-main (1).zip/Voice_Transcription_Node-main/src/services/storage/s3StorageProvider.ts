import * as fs from 'fs';
import { Readable } from 'stream';

import { S3Client, DeleteObjectCommand, ListObjectsV2Command, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

import { StorageItemDesc, StorageItemType, IStorageProvider } from './storageProvider';
import { RequestContext } from '../../models/requestContext';
import { logger } from '../../utils/logger';

export type S3StorageProviderConfig = {
  accessKeyId: string;
  secretAccessKey: string;
  region: string;
  bucket: string;
  rootDirectory?: string;
};

/**
 * Storage provider for AWS S3.
 */
export class S3StorageProvider implements IStorageProvider {

  get rootDirectory(): string {
    return this.config.rootDirectory ?? './';
  }

  constructor(private config: S3StorageProviderConfig) { }

  private async getS3Client(): Promise<S3Client> {
    return new S3Client({
      region: this.config.region,
      credentials: {
        accessKeyId: this.config.accessKeyId,
        secretAccessKey: this.config.secretAccessKey,
      }
    });
  }

  async uploadFile(ctx: RequestContext, localFilepath: string, remoteFilepath: string): Promise<void> {
    logger.info(`Uploading file from ${localFilepath} to S3 ${remoteFilepath}`);
    const s3Client = await this.getS3Client();

    // Upload the file here
    const bucket = this.config.bucket;
    await s3Client.send(new PutObjectCommand({
      Bucket: bucket,
      Key: remoteFilepath,
      Body: fs.readFileSync(localFilepath),
    }));
    logger.info('Uploading finished.');
  }

  async downloadFile(ctx: RequestContext, remoteFilepath: string, localFilepath: string): Promise<void> {
    logger.info(`Downloading file from S3 ${remoteFilepath} to ${localFilepath}`);
    const s3Client = await this.getS3Client();

    // Download the file here
    const result = await s3Client.send(new GetObjectCommand({
      Bucket: this.config.bucket,
      Key: remoteFilepath,
    }));

    if (!result.Body) {
      throw new Error('Failed to download file from S3');
    }

    if (result.Body instanceof Readable) {
      const inputStream = result.Body as Readable;
      await new Promise<void>((resolve, reject) => {
        inputStream.pipe(fs.createWriteStream(localFilepath))
          .on('error', err => reject(err))
          .on('close', () => resolve());
      });
    } else {
      throw new Error('Failed to download file from S3');
    }
  }

  async deleteFile(ctx: RequestContext, remoteFilepath: string): Promise<void> {
    logger.info(`Deleting file from S3 ${remoteFilepath}`);
    const s3Client = await this.getS3Client();

    // Delete the file here
    await s3Client.send(new DeleteObjectCommand({
      Bucket: this.config.bucket,
      Key: remoteFilepath,
    }));
  }

  async deleteFiles(ctx: RequestContext, remoteDirpaths: string[]): Promise<void> {
    logger.info(`Deleting files from S3 ${remoteDirpaths}`);
    const s3Client = await this.getS3Client();

    // Delete the files here
    for (const remoteDirpath of remoteDirpaths) {
      await s3Client.send(new DeleteObjectCommand({
        Bucket: this.config.bucket,
        Key: remoteDirpath,
      }));
    }
  }

  async listItems(ctx: RequestContext, remoteDirpath: string): Promise<StorageItemDesc[]> {
    logger.info(`Listing items in directory from S3 ${remoteDirpath}`);
    const s3Client = await this.getS3Client();
    const items: StorageItemDesc[] = [];

    // List the items here
    let token = undefined;
    do {
      const result = await s3Client.send(new ListObjectsV2Command({
        Bucket: this.config.bucket,
        Prefix: remoteDirpath,
        ContinuationToken: token,
      }));

      if (result.Contents) {
        items.push(...result.Contents.map(item => {
          return {
            type: 'file' as StorageItemType,
            name: item.Key || '',
            size: item.Size,
            modifiedAt: item.LastModified,
          };
        }));
      }

      token = result.NextContinuationToken;
    } while (token);

    return items;
  }

  async generateUrl(ctx: RequestContext, remoteFilepath: string, expiresInSeconds?: number): Promise<string> {
    logger.info(`Generating URL for file in S3 ${remoteFilepath}`);
    const s3Client = await this.getS3Client();

    // Generate the URL here
    const bucket = this.config.bucket;
    return await getSignedUrl(s3Client, new GetObjectCommand({
      Bucket: bucket,
      Key: remoteFilepath,
    }), { expiresIn: expiresInSeconds });
  }
}
