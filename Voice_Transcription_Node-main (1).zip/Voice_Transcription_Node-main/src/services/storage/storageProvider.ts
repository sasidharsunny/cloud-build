import { RequestContext } from '../../models/requestContext';

/**
 * Type of a storage item (file or directory).
 */
export type StorageItemType = 'file' | 'dir';

/**
 * Description of a storage item.
 */
export type StorageItemDesc = {
  type: StorageItemType;
  name: string;
  size?: number;
  modifiedAt?: Date;
  createdAt?: Date;
};

/**
 * Interface for a storage (AWS S3, etc.)
 */
export interface IStorageProvider {

  get rootDirectory(): string;

  /**
   * Upload a file to the remote storage.
   * @param ctx Request context
   * @param localFilepath Local file path to upload
   * @param remoteFilepath Remote file path to upload to
   */
  uploadFile(ctx: RequestContext, localFilepath: string, remoteFilepath: string): Promise<void>;

  /**
   * Download a file from the remote storage.
   * @param ctx Request context
   * @param remoteFilepath Remote file path to download
   * @param localFilepath Local file path to download to
   */
  downloadFile(ctx: RequestContext, remoteFilepath: string, localFilepath: string): Promise<void>;

  /**
   * Delete a file from the remote storage.
   * @param ctx Request context
   * @param remoteFilepath Remote file path to delete
   */
  deleteFile(ctx: RequestContext, remoteFilepath: string): Promise<void>;

  /**
   * Delete a directory from the remote storage with all its contents.
   * @param ctx Request context
   * @param remoteDirpaths Remote directory paths to delete
   */
  deleteFiles(ctx: RequestContext, remoteDirpaths: string[]): Promise<void>;

  /**
   * List items in a remote directory.
   * @param ctx Request context
   * @param remoteDirpath Remote directory path to list items in
   */
  listItems(ctx: RequestContext, remoteDirpath: string): Promise<StorageItemDesc[]>;

  /**
   * Generate a URL for a file in the remote storage. Specify expiration time for ephemeral URLs.
   * @param ctx Request context
   * @param remoteFilepath Remote file path to generate URL for
   * @param expiresInSeconds Expiration time for the URL in seconds (optional)
   */
  generateUrl(ctx: RequestContext, remoteFilepath: string, expiresInSeconds?: number): Promise<string>;
}
