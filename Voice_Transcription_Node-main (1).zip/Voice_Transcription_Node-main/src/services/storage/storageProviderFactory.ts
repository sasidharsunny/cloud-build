import { injectable } from 'tsyringe';

import { S3StorageProvider, S3StorageProviderConfig } from './s3StorageProvider';
import { IStorageProvider } from './storageProvider';
import { StorageProviderInfo } from '../../db/models';

@injectable()
export class StorageProviderFactory {
  /**
     * Get a storage provider by its name.
     * @param type Name of the storage provider
     */
  getProvider(storageProviderInfo: StorageProviderInfo): IStorageProvider {
    if (storageProviderInfo.type === 's3') {
      return new S3StorageProvider(storageProviderInfo.config as S3StorageProviderConfig);
    }
    // TODO: add support for additional storage providers here
    else {
      throw new Error(`Unknown storage provider: ${storageProviderInfo.type}`);
    }
  }
}
