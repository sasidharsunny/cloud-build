import { injectable } from 'tsyringe';

import { CreateStorageProviderParams, UpdateStorageProviderParams } from '../../api/contracts';
import { StorageProviderInfo } from '../../db/models';
import { NotFound } from '../../errors';
import { RequestContext } from '../../models/requestContext';
import { ensureRoleAndOrganizationAccess } from '../../utils/securityChecks';

@injectable()
export class StorageProvidersService {

  /**
   * Creates new storage provider using `params`
   *
   * @param {RequestContext} ctx
   * @param {CreateStorageProviderParams} params
   */
  async createStorageProvider(ctx: RequestContext, params: CreateStorageProviderParams) {
    ensureRoleAndOrganizationAccess('create-storage-providers', 'create storage provider', ctx);
    return await StorageProviderInfo.create({ ...params, organizationId: ctx.requestedOrganizationId });
  }

  /**
   * Updated storage provider with `id` using `params`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   * @param {UpdateStorageProviderParams} params
   */
  async updateStorageProvider(ctx: RequestContext, id: string, params: UpdateStorageProviderParams) {
    ensureRoleAndOrganizationAccess('modify-storage-providers', 'modify storage provider', ctx);
    const [, rows] = await StorageProviderInfo.update(params, {
      where: { id, organizationId: ctx.requestedOrganizationId }, returning: true
    });
    if (!rows[0])
      throw new NotFound();

    return rows[0];
  }

  /**
   * Removes storage provider with `id`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   */
  async deleteStorageProvider(ctx: RequestContext, id: string) {
    ensureRoleAndOrganizationAccess('remove-storage-providers', 'remove storage provider', ctx);
    const storage = await StorageProviderInfo.destroy({
      where: { id, organizationId: ctx.requestedOrganizationId }
    });
    if (!storage)
      throw new NotFound();
  }

  /**
   * Returns storage provider with `id`
   *
   * @param {RequestContext} ctx
   * @param {string} id
   */
  async getStorageProvider(ctx: RequestContext, id: string) {
    ensureRoleAndOrganizationAccess('view-storage-providers', 'view storage provider', ctx);
    const storage = await StorageProviderInfo.findOne({
      where: { id, organizationId: ctx.requestedOrganizationId }
    });
    if (!storage)
      throw new NotFound();

    return storage;
  }

  /**
   * Returns all storage providers assigned to organization with `organizationId`
   *
   * @param {RequestContext} ctx
   * @param {string} organizationId
   */
  async getStorageProviders(ctx: RequestContext, organizationId: string) {
    ensureRoleAndOrganizationAccess('view-storage-providers', 'view storage providers', ctx);
    return await StorageProviderInfo.findAll({ where: { organizationId } });
  }

  async getStorageProviderInternal(id: string) {
    const storage = await StorageProviderInfo.findOne({ where: { id } });
    if (!storage)
      throw new NotFound();

    return storage;
  }
}
