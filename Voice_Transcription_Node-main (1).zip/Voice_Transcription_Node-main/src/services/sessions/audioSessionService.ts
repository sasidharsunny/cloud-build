import { inject, injectable } from 'tsyringe';
import { v4 } from 'uuid';

import { CreateAudioSessionParams, UpdateAudioSessionParams } from '../../api/contracts';
import { AudioSession } from '../../db/models';
import { NotFound } from '../../errors';
import { RequestContext } from '../../models/requestContext';
import { logger } from '../../utils/logger';
import { ensureRoleAndOrganizationAccess } from '../../utils/securityChecks';
import { StorageProvidersService } from '../storage/storageProvidersService';
import { AsrProfilesService } from '../transcription/asrProfilesService';

@injectable()
export class AudioSessionsService {

  constructor(
    @inject(StorageProvidersService) private storageProvidersService: StorageProvidersService,
    @inject(AsrProfilesService) private asrProfilesService: AsrProfilesService,
  ) { }

  /**
   * Creates a new audio session.
   * @param ctx The request context.
   * @param createParams The parameters to create the session with.
   * @returns The created session.
   */
  public async createSession(ctx: RequestContext, createParams: CreateAudioSessionParams): Promise<AudioSession> {
    logger.info({ ctx, createParams }, 'Creating a new audio session');

    // Check for the required role
    ensureRoleAndOrganizationAccess('create-sessions', 'create a session', ctx);

    // Retrieve ASR profile and store it in the session
    const asrProfile = await this.asrProfilesService.getAsrProfileInternal(createParams.asrProfileId);
    if (asrProfile.organizationId != ctx.userOrganizationId && !ctx.fromMasterOrganization) {
      throw new NotFound('ASR profile not found');
    }

    const storageProvider = await this.storageProvidersService.getStorageProviderInternal(createParams.storageProviderId);
    if (storageProvider.organizationId != ctx.userOrganizationId && !ctx.fromMasterOrganization) {
      throw new NotFound('Storage provider not found');
    }

    // Create a new session
    const newSession = await AudioSession.create({
      id: v4(),
      organizationId: ctx.requestedOrganizationId,
      metadata: createParams.metadata,
      status: 'active',
      usedAsrProfile: asrProfile,
      storageProvider,
    });

    // Return a new session
    return newSession;
  }

  /**
   * Retrieves an audio session by ID.
   * @param ctx The request context.
   * @param organizationId The organization ID.
   * @param sessionId The session ID.
   * @returns The session.
   */
  public async getSession(ctx: RequestContext, sessionId: string): Promise<AudioSession> {
    // Check for the required role
    ensureRoleAndOrganizationAccess('view-sessions', 'view sessions', ctx);

    // Retrieve the session
    const session = await AudioSession.findOne({
      where: { id: sessionId, organizationId: ctx.requestedOrganizationId }
    });
    if (!session) {
      throw new NotFound('Session not found');
    }

    return session;
  }

  /**
   * Retrieves an audio session by ID, for user to join.
   * @param ctx The request context.
   * @param organizationId The organization ID.
   * @param sessionId The session ID.
   * @returns The session.
   */
  public async joinSession(ctx: RequestContext, organizationId: string, sessionId: string): Promise<AudioSession> {
    // Check for the required role
    ensureRoleAndOrganizationAccess('join-sessions', 'join sessions', ctx);

    // Retrieve the session
    const session = await AudioSession.findOne({
      where: { id: sessionId, organizationId }
    });
    if (!session) {
      throw new NotFound('Session not found');
    }

    return session;
  }

  /**
   * Retrieves all audio sessions for an organization.
   * @param ctx The request context.
   * @param organizationId The organization ID.
   * @returns The sessions.
   */
  public async getAllSessions(ctx: RequestContext): Promise<AudioSession[]> {
    // Check for the required role
    ensureRoleAndOrganizationAccess('view-sessions', 'view sessions', ctx);

    // Retrieve all sessions
    return AudioSession.findAll({
      where: { organizationId: ctx.requestedOrganizationId }
    });
  }

  /**
   * Updates an audio session.
   * @param ctx The request context.
   * @param organizationId The organization ID.
   * @param sessionId The session ID.
   * @param params The parameters to update the session with.
   * @returns The updated session.
   */
  public async updateSession(ctx: RequestContext, sessionId: string, params: UpdateAudioSessionParams): Promise<AudioSession> {
    // Check for the required role
    ensureRoleAndOrganizationAccess('modify-sessions', 'update sessions', ctx);

    const [, rows] = await AudioSession.update(params, {
      where: { id: sessionId, organizationId: ctx.requestedOrganizationId },
      returning: true
    });
    if (!rows[0])
      throw new NotFound('Session not found');

    return rows[0];
  }

  /**
   * Deletes an audio session. This operation is irreversible.
   * @param ctx The request context.
   * @param organizationId The organization ID.
   * @param sessionId The session ID.
   */
  public async deleteSession(ctx: RequestContext, organizationId: string, sessionId: string): Promise<void> {
    // Check for the required role
    ensureRoleAndOrganizationAccess('remove-sessions', 'delete sessions', ctx);

    // Retrieve the session
    const session = await AudioSession.destroy({
      where: { id: sessionId, organizationId }
    });
    if (!session)
      throw new NotFound('Session not found');

    // TODO: add deletion logic for any associated resources
  }

  /**
   * Checks whether a session exists and is not closed/failed.
   * This call does not require any permissions.
   * @param sessionId The session ID.
   * @returns Whether the session exists and is active.
   */
  public async checkSession(sessionId: string) {
    const session = await AudioSession.findByPk(sessionId);

    return (session && session.status !== 'closed' && session.status !== 'failed');
  }

  /**
   * Retrieves a live audio session by its ID.
   * This method is internal and does not perform any security checks.
   * @param sessionId The session ID.
   * @returns The session.
   */
  public async getLiveSessionInternal(sessionId: string) {
    const session = await AudioSession.findByPk(sessionId);
    if (!session || session.status === 'closed' || session.status === 'failed') {
      return null;
    }
    return session;
  }

  /**
   * Fails an audio session.
   * This method is internal and does not perform any security checks.
   * @param sessionId The session ID.
   */
  public async failSessionInternal(sessionId: string, failureReason?: string) {
    const session = await AudioSession.findByPk(sessionId);
    if (!session) {
      logger.warn({ sessionId }, 'Can\'t fail non-existent session');
      return;
    }

    session.status = 'failed';
    session.statusDetails = failureReason || 'Session failed';

    await session.save();
  }
}
