import { rmSync } from 'fs';
import * as path from 'path';

import { inject, injectable, singleton } from 'tsyringe';

import { AudioSessionContext } from './audioSessionContext';
import { AudioSessionsService } from './audioSessionService';
import { AsrProviderInfo } from '../../db/models';
import { logger } from '../../utils/logger';
import { AudioChunkMessage, MessageCoder } from '../../utils/messaging';
import { AudioRecordingsService } from '../audio/audioRecordingsService';
import { WavAudioRecorder } from '../audio/wavAudioRecorder';
import { AudioProducerHost } from '../communication/audioProducerHost';
import { ConnectionService } from '../communication/connectionService';
import { TextConsumerHost } from '../communication/textConsumerHost';
import { StorageProviderFactory } from '../storage/storageProviderFactory';
import { AsrProviderFactory } from '../transcription/asrProviderFactory';
import { TranscriptionChunksService } from '../transcription/transcriptionChunksService';
import { TranscriptsService } from '../transcription/transcriptsService';


/**
 * Manages a live audio sessions for the whole node.
 */
@singleton()
@injectable()
export class AudioSessionCoordinator {
  // map sessionIds to producer connectionTokens
  private producerConnections: Map<string, string> = new Map();
  // map producer connectionTokens to sessionIds
  private producerSessions: Map<string, string> = new Map();
  // consumer sessionIds to multiple connectionTokens
  private consumerConnections: Map<string, string[]> = new Map;
  // consumer connectionTokens to sessionIds
  private consumerSessions: Map<string, string> = new Map();
  // live sessions
  private liveSessions: Map<string, AudioSessionContext> = new Map();

  // hosts
  private audioProducerHost: AudioProducerHost;
  private textConsumerHost: TextConsumerHost;

  constructor(
    @inject(AudioRecordingsService) private audioRecordingsService: AudioRecordingsService,
    @inject(AudioSessionsService) private audioSessionService: AudioSessionsService,
    @inject(ConnectionService) private connectionService: ConnectionService,
    @inject(AsrProviderFactory) private asrProviderFactory: AsrProviderFactory,
    @inject(StorageProviderFactory) private storageProviderFactory: StorageProviderFactory,
    @inject(TranscriptionChunksService) private transcriptionChunksService: TranscriptionChunksService,
    @inject(TranscriptsService) private transcriptsService: TranscriptsService,
  ) { }

  attachToHosts(audioProducerHost: AudioProducerHost, textConsumerHost: TextConsumerHost) {
    this.audioProducerHost = audioProducerHost;
    this.textConsumerHost = textConsumerHost;

    // Attach to audio producer host
    audioProducerHost.addConnectionOpenedHandler((connectionToken) => {
      logger.info({ connectionToken }, 'Producer connected (not authenticated yet)');
    });

    audioProducerHost.addConnectionClosedHandler((connectionToken) => {
      logger.info({ connectionToken }, 'Producer disconnected');
      this.disconnectProducer(connectionToken);
    });

    audioProducerHost.addConnectionFailedHandler((connectionToken, error) => {
      logger.error({ connectionToken, error }, 'Producer connection failed');
      this.disconnectProducer(connectionToken);
    });

    // Handle audio data from producer
    audioProducerHost.addMessageHandler('AUDC', async (connectionToken, message) => {
      const sessionId = this.producerSessions.get(connectionToken);
      const audioChunk = MessageCoder.decodeAudioChunkMessage(message);
      logger.info({ connectionToken, sessionId, length: audioChunk.payloadLength }, 'Received audio data');
      await this.streamAudio(connectionToken, audioChunk);
    });

    // Handle end of transmission from producer
    audioProducerHost.addMessageHandler('ENDT', async (connectionToken, message) => {
      const sessionId = this.producerSessions.get(connectionToken);
      logger.info({ connectionToken, sessionId }, 'End of transmission');
      MessageCoder.decodeEndTransmissionMessage(message);
      await this.stopSession(sessionId);
    });

    // Handle authentication of producer
    audioProducerHost.setAuthHandler(async (authMessage) => {
      // Connect producer if it created the session
      const connection = await this.connectionService.getConnection(authMessage.token);
      if (connection && connection.connectionType === 'producer') {
        await this.connectProducer(connection.connectionToken, authMessage.sessionId);
        return true;
      } else {
        logger.warn({ connectionToken: authMessage.token }, 'Producer authentication failed');
        return false;
      }
    });

    // Attach to text consumer host
    textConsumerHost.addConnectionOpenedHandler(async (connectionToken) => {
      logger.info({ connectionToken }, 'Consumer connected (not authenticated yet)');
      const sessionId = this.consumerSessions.get(connectionToken);
      await this.connectConsumer(connectionToken, sessionId);
    });

    textConsumerHost.addConnectionClosedHandler((connectionToken) => {
      logger.info({ connectionToken }, 'Consumer disconnected');
      this.disconnectConsumer(connectionToken);
    });

    textConsumerHost.addConnectionFailedHandler((connectionToken, error) => {
      logger.error({ connectionToken, error }, 'Consumer connection failed');
      this.disconnectConsumer(connectionToken);
    });

    // Handle authentication of consumer
    textConsumerHost.setAuthHandler(async (authMessage) => {
      // Connect consumer if it joined the session
      const connection = await this.connectionService.getConnection(authMessage.token);
      if (connection && connection.connectionType === 'consumer') {
        await this.connectConsumer(connection.connectionToken, authMessage.sessionId);
        return true;
      } else {
        logger.warn({ connectionToken: authMessage.token }, 'Consumer authentication failed');
        return false;
      }
    });
  }

  /**
   * Connects a producer to a session. Only one producer can be connected to a session at a time.
   * @param connectionToken The connection token of the producer.
   * @param sessionId The session ID to connect to.
   */
  async connectProducer(connectionToken: string, sessionId: string) {
    if (this.producerSessions.has(connectionToken)) {
      throw new Error('Producer is already connected');
    }
    if (!this.audioSessionService.checkSession(sessionId)) {
      throw new Error('Session does not exist or is closed');
    }

    this.producerSessions.set(connectionToken, sessionId);
    this.producerConnections.set(sessionId, connectionToken);

    try {
      await this.wireupSession(connectionToken, sessionId);
      const session = this.liveSessions.get(sessionId);
      await session.audioRecorder.startRecording(session);
    } catch (err) {
      logger.error({ connectionToken: connectionToken, sessionId, err }, 'Error during session setup');
      await this.audioSessionService.failSessionInternal(sessionId, 'Error during session setup');
      this.disconnectProducer(connectionToken);
    }
  }

  /**
   * Disconnects a producer from a session. This won't stop the session.
   * @param connectionToken The connection ID of the producer.
   */
  disconnectProducer(connectionToken: string) {
    if (!this.producerSessions.has(connectionToken)) {
      logger.warn({ connectionToken }, 'Producer is already disconnected');
      return;
    }

    // Remove connection registration
    const sessionId = this.producerSessions.get(connectionToken);
    this.producerSessions.delete(connectionToken);
    this.producerConnections.delete(sessionId);

    // Remove producer connection from live session
    const liveSession = this.liveSessions.get(sessionId);
    if (liveSession) {
      liveSession.producerConnectionToken = undefined;
    }
  }

  async stopSession(sessionId: string) {
    if (!this.producerConnections.has(sessionId)) {
      throw new Error('Session is already stopped');
    }

    // disconnect producer
    const producerconnectionToken = this.producerConnections.get(sessionId);
    this.producerConnections.delete(sessionId);
    this.producerSessions.delete(producerconnectionToken);

    // disconnect consumers
    const consumerconnectionTokens = this.consumerConnections.get(sessionId);
    if (consumerconnectionTokens) {
      consumerconnectionTokens.forEach((connectionToken) => {
        this.consumerSessions.delete(connectionToken);
      });
      this.consumerConnections.delete(sessionId);
    }

    // Stop provider and remove session from live sessions
    const liveSession = this.liveSessions.get(sessionId);
    if (liveSession) {
      await liveSession.audioRecorder.stopRecording();
      await liveSession.asrProvider.stop(liveSession);
      this.liveSessions.delete(sessionId);

      const localFilePath = liveSession.audioRecorder.getFullPath();
      const remoteFilePath = path.posix.join(
        liveSession.storageProvider.rootDirectory,
        liveSession.organizationId,
        liveSession.audioRecorder.getFilename());
      await liveSession.storageProvider.uploadFile(null, localFilePath, remoteFilePath);
      rmSync(liveSession.audioRecorder.getFullPath());

      const session = await this.audioSessionService.getLiveSessionInternal(sessionId);
      await this.audioRecordingsService.createRecordingInternal({
        organizationId: liveSession.organizationId,
        audioSessionId: liveSession.sessionId,
        storageId: session.storageProvider.id,
        storageUrl: await liveSession.storageProvider.generateUrl(null, remoteFilePath),
        fileName: liveSession.audioRecorder.getFilename(),
        fileFormat: liveSession.audioRecorder.getFileFormat(),
      });
    }
  }

  async streamAudio(connectionToken: string, audioChunk: AudioChunkMessage) {
    const sessionId = this.producerSessions.get(connectionToken);
    logger.info({ connectionToken, sessionId, length: audioChunk.audioData.length }, 'Received audio data');
    const liveSession = this.liveSessions.get(sessionId);
    if (!liveSession) {
      throw new Error('Session not found');
    }

    /* TODO: handle disconnected providers here
    if (!liveSession.asrProvider.isStarted()) {
      liveSession.asrProvider.start(liveSession);
    }
    */
    await liveSession.audioRecorder.write(audioChunk.audioData);

    // TODO: handle other parts of the audio chunk
    await liveSession.asrProvider.sendAudio(liveSession, audioChunk.audioData);
  }

  /**
   * Connects a consumer to a session. Multiple consumers can be connected to a session at a time.
   * @param connectionToken The connection token of the consumer.
   * @param sessionId The session ID to connect to.
   */
  async connectConsumer(connectionToken: string, sessionId: string) {
    // Check if not already connected
    if (this.consumerSessions.has(connectionToken)) {
      throw new Error('Consumer is already connected');
    }

    // Register consumer connection to session
    const existingConnections = this.consumerConnections.get(sessionId) ?? [];
    existingConnections.push(connectionToken);
    this.consumerConnections.set(sessionId, existingConnections);
    this.consumerSessions.set(connectionToken, sessionId);

    // Add connection to live session
    const liveSession = this.liveSessions.get(sessionId);
    if (liveSession) {
      liveSession.consumerConnectionTokens.push(connectionToken);
    }
  }

  /**
   * Disconnects a consumer from a session.
   * @param connectionToken The connection ID of the consumer.
   */
  disconnectConsumer(connectionToken: string) {
    if (!this.consumerSessions.has(connectionToken)) {
      logger.warn({ connectionToken }, 'Consumer is already disconnected');
      return;
    }

    // Remove connection registration from session
    const sessionId = this.consumerSessions.get(connectionToken);
    const existingConnections = this.consumerConnections.get(sessionId);
    if (existingConnections) {
      const newConnections = existingConnections.filter((connectionToken) => connectionToken !== connectionToken);
      this.consumerConnections.set(sessionId, newConnections);
    }
    this.consumerSessions.delete(connectionToken);

    // Remove connection registration from live session
    const liveSession = this.liveSessions.get(sessionId);
    if (liveSession) {
      liveSession.consumerConnectionTokens = liveSession.consumerConnectionTokens.filter((token) => token !== connectionToken);
    }
  }

  getInfoAboutSession(sessionId: string) {
    return {
      producerconnectionToken: this.producerConnections.get(sessionId),
      consumerconnectionTokens: this.consumerConnections.get(sessionId)
    };
  }

  private async wireupSession(connectionToken: string, sessionId: string) {
    logger.info({ connectionToken, sessionId }, 'Setting up session');
    // Get session
    const session = await this.audioSessionService.getLiveSessionInternal(sessionId);
    if (!session) {
      throw new Error('Session does not exist or is closed');
    }

    // Get ASR provider profile and info
    logger.debug({ sessionId, asrProfileId: session.usedAsrProfile.id }, 'Getting ASR provider info');
    const asrProfile = session.usedAsrProfile;
    const asrProviderInfo = await AsrProviderInfo.findByPk(asrProfile.providerId);
    if (!asrProviderInfo) {
      throw new Error('Provider info not found');
    }

    // Create voice transcript for session
    const transcript = await this.transcriptsService.createTranscriptInternal({
      audioSessionId: session.id,
      organizationId: session.organizationId,
      type: 'raw',
      text: '',
      typeDetails: ''
    });

    // Create ASR provider and wire up events
    logger.debug({ sessionId, providerId: asrProviderInfo.id }, 'Creating instance of ASR provider for given ASR profile');
    const asrProvider = this.asrProviderFactory.createProvider(asrProviderInfo, asrProfile);

    asrProvider.setOnRecognizing(async ({ chunkId, text }) => {
      logger.info({ chunkId, text }, 'Recognizing text');
      // Send raw text to consumers
      const liveSession = this.liveSessions.get(sessionId);
      if (liveSession) {
        const message = MessageCoder.encodeTextChunkMessage('RTXT', liveSession.recognizingSequence++, 0, text);
        for (const connectionToken of liveSession.consumerConnectionTokens) {
          await this.textConsumerHost.sendMessage(connectionToken, message);
        }
      } else {
        logger.warn({ sessionId }, 'Live session not found');
      }
    });

    asrProvider.setOnRecognized(async ({ chunkId, text, audioPositionFrom, audioPositionTo }) => {
      logger.info({ chunkId, text }, 'Recognized text');
      // Send final text to consumers
      const liveSession = this.liveSessions.get(sessionId);
      if (liveSession) {
        liveSession.recognizedSequence++;
        await this.transcriptionChunksService.createTranscriptionChunkInternal({
          voiceTranscriptId: transcript.id,
          ordinal: liveSession.recognizedSequence,
          sessionId: liveSession.sessionId,
          transcribedText: text,
          audioPositionFrom: audioPositionFrom,
          audioPositionTo: audioPositionTo,
        });
        const message = MessageCoder.encodeTextChunkMessage('STXT', liveSession.recognizedSequence, 0, text);
        for (const connectionToken of liveSession.consumerConnectionTokens) {
          await this.textConsumerHost.sendMessage(connectionToken, message);
        }
      } else {
        logger.warn({ sessionId }, 'Live session not found');
      }
    });

    asrProvider.setOnRecognitionStopped(async () => {
      logger.info('Recognition stopped');
      const text = asrProvider.getAllTextChunks()
        .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
        .map(c => c.text)
        .join('\n');
      await transcript.update({ text });
    });

    asrProvider.setOnError((err) => {
      logger.error({ err }, 'Error during recognition');
      // TODO: handle error (TBD how)
    });

    // Get storage provider
    logger.debug({ sessionId, storageProviderId: session.storageProvider.id }, 'Getting storage provider info');
    const storageProviderInfo = session.storageProvider;
    const storageProvider = this.storageProviderFactory.getProvider(storageProviderInfo);

    // Create session context
    const audioSessionCtx: AudioSessionContext = {
      sessionId: session.id,
      organizationId: session.organizationId,
      asrProfile,
      asrProvider,
      storageProvider,
      producerConnectionToken: connectionToken,
      consumerConnectionTokens: [],
      audioRecorder: new WavAudioRecorder(),
      recognizedSequence: 0,
      recognizingSequence: 0,
    };
    this.liveSessions.set(sessionId, audioSessionCtx);

    // Start ASR provider
    logger.debug({ sessionId }, 'Starting ASR provider');
    await asrProvider.start(audioSessionCtx);
  }
}
