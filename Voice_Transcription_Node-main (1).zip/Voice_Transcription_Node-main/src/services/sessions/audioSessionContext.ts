import { AsrProfile } from '../../db/models';
import { IAudioRecorder } from '../audio/IAudioRecorder';
import { IStorageProvider } from '../storage/storageProvider';
import { IAsrProvider } from '../transcription/asrProvider';

export type AudioSessionContext = {
  /**
   * The ID of the session.
   */
  sessionId: string;

  /**
   * The ID of the organization.
   */
  organizationId: string;

  /**
   * The ASR profile used in the session.
   */
  asrProfile: AsrProfile;

  /**
   * The ASR provider component used in the session.
   */
  asrProvider: IAsrProvider;

  /**
   * Storage provider used in the session
   */
  storageProvider: IStorageProvider;

  /**
   * The ID of the producer connection
   */
  producerConnectionToken?: string;

  /**
   * The IDs of the consumer connections
   */
  consumerConnectionTokens: string[];

  /**
   * Audio recorder component used in the session.
   */
  audioRecorder: IAudioRecorder,

  /**
   * Sequence number for recognizing handler
   */
  recognizingSequence: number;

  /**
   * Sequence number for recognized handler
   */
  recognizedSequence: number;
}
