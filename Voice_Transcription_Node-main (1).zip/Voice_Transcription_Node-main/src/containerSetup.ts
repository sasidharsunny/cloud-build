import 'reflect-metadata';
import { container } from 'tsyringe';

import { logger } from './utils/logger';

/**
 * Setup the container with all the necessary bindings to services.
 */
export function containerSetup() {
  logger.debug('Setting up dependency container bindings');

  container.register('Dummy', { useClass: class Dummy { } });
}
