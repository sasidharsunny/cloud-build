import { Sequelize, DataTypes } from 'sequelize';

import { ApiKey, AsrProfile, AsrProviderInfo, AudioRecording, AudioSession, Connection, Organization, StorageProviderInfo, TranscriptionChunks, User, VoiceTranscript } from './models';
import { logger } from '../utils/logger';

const sequelize = new Sequelize(process.env.POSTGRES_CONNECTION_STRING, {
  logging: false,
  dialect: 'postgres',
});

// Define models
Organization.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  name: {
    type: DataTypes.TEXT,
    allowNull: false,
    unique: true,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    allowNull: false,
    defaultValue: 'inactive',
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
}, {
  sequelize,
  modelName: 'Organization',
  tableName: 'organizations',
  timestamps: true,
  underscored: true,
});

User.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  organizationId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  name: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    allowNull: false,
    defaultValue: 'inactive',
  },
  roles: {
    type: DataTypes.ARRAY(DataTypes.TEXT),
    allowNull: false,
    defaultValue: [],
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
}, {
  sequelize,
  modelName: 'User',
  tableName: 'users',
  timestamps: true,
  underscored: true,
});

ApiKey.init({
  key: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  organizationId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive', 'revoked'),
    allowNull: false,
    defaultValue: 'inactive',
  },
  roles: {
    type: DataTypes.ARRAY(DataTypes.TEXT),
    allowNull: false,
    defaultValue: [],
  },
}, {
  sequelize,
  modelName: 'ApiKey',
  tableName: 'api_keys',
  timestamps: true,
  underscored: true,
});

AudioSession.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  organizationId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive', 'closed', 'failed'),
    allowNull: false,
    defaultValue: 'inactive',
  },
  statusDetails: {
    type: DataTypes.TEXT,
    allowNull: false,
    defaultValue: '',
  },
  usedAsrProfile: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
  storageProvider: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: true,
    defaultValue: {},
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: new Date(),
  },
  endedAt: {
    type: DataTypes.DATE,
    allowNull: true,
  },
}, {
  sequelize,
  modelName: 'AudioSession',
  tableName: 'audio_sessions',
  timestamps: false,
  underscored: true,
});

AudioRecording.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  organizationId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  audioSessionId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  storageId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  storageUrl: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  fileName: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  fileFormat: {
    type: DataTypes.ENUM('mp3', 'wav'),
    allowNull: false,
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: new Date(),
  },
}, {
  sequelize,
  modelName: 'AudioRecording',
  tableName: 'audio_recordings',
  timestamps: false,
  underscored: true,
});

VoiceTranscript.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  organizationId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  audioSessionId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  type: {
    type: DataTypes.ENUM('raw', 'redacted'),
    allowNull: false,
  },
  typeDetails: {
    type: DataTypes.TEXT,
    allowNull: false,
    defaultValue: '',
  },
  text: {
    type: DataTypes.TEXT,
    allowNull: false,
    defaultValue: '',
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: new Date(),
  },
}, {
  sequelize,
  modelName: 'VoiceTranscript',
  tableName: 'voice_transcript',
  timestamps: false,
  underscored: true,
});

StorageProviderInfo.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  organizationId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  name: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  type: {
    type: DataTypes.ENUM('s3', 'local'),
    allowNull: false,
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
  config: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
}, {
  sequelize,
  modelName: 'StorageProviderInfo',
  tableName: 'storage_providers',
  timestamps: true,
  underscored: true,
});

AsrProviderInfo.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  organizationId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  name: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  type: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
  config: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
}, {
  sequelize,
  modelName: 'AsrProviderInfo',
  tableName: 'asr_providers',
  timestamps: true,
  underscored: true,
});

AsrProfile.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  organizationId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  providerId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  name: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
}, {
  sequelize,
  modelName: 'AsrProfile',
  tableName: 'asr_profiles',
  timestamps: true,
  underscored: true,
});

Connection.init({
  connectionToken: {
    type: DataTypes.TEXT,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  audioSessionId: {
    type: DataTypes.UUID,
    allowNull: false,
  },
  connectionType: {
    type: DataTypes.ENUM('producer', 'consumer'),
    allowNull: false,
  },
  streamTypes: {
    type: DataTypes.ARRAY(DataTypes.TEXT),
    allowNull: true,
  },
}, {
  sequelize,
  modelName: 'Connection',
  tableName: 'connections',
  timestamps: true,
  underscored: true,
});

TranscriptionChunks.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
  },
  voiceTranscriptId: {
    type: DataTypes.UUID,
  },
  ordinal: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  sessionId: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  transcribedText: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  audioPositionFrom: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  audioPositionTo: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  metadata: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: {},
  },
}, {
  sequelize,
  modelName: 'TranscriptionChunks',
  tableName: 'transcription_chunks',
  timestamps: true,
  underscored: true,
});

// Define relationships (both directions)

Organization.hasMany(User, { foreignKey: 'organizationId' });
User.belongsTo(Organization);

Organization.hasMany(ApiKey, { foreignKey: 'organizationId' });
ApiKey.belongsTo(Organization, { foreignKey: 'organizationId' });

Organization.hasMany(AudioSession, { foreignKey: 'organizationId' });
AudioSession.belongsTo(Organization, { foreignKey: 'organizationId' });

Organization.hasMany(AudioRecording, { foreignKey: 'organizationId' });
AudioRecording.belongsTo(Organization, { foreignKey: 'organizationId' });

Organization.hasMany(VoiceTranscript, { foreignKey: 'organizationId' });
VoiceTranscript.belongsTo(Organization, { foreignKey: 'organizationId' });

Organization.hasMany(StorageProviderInfo, { foreignKey: 'organizationId' });
StorageProviderInfo.belongsTo(Organization, { foreignKey: 'organizationId' });

Organization.hasMany(AsrProviderInfo, { foreignKey: 'organizationId' });
AsrProviderInfo.belongsTo(Organization, { foreignKey: 'organizationId' });

Organization.hasMany(AsrProfile, { foreignKey: 'organizationId' });
AsrProfile.belongsTo(Organization, { foreignKey: 'organizationId' });


AudioSession.hasMany(AudioRecording, { foreignKey: 'audioSessionId' });
AudioRecording.belongsTo(AudioSession, { foreignKey: 'audioSessionId' });

AudioSession.hasMany(VoiceTranscript, { foreignKey: 'audioSessionId' });
VoiceTranscript.belongsTo(AudioSession, { foreignKey: 'audioSessionId' });

AudioSession.hasMany(Connection, { foreignKey: 'audioSessionId' });
Connection.belongsTo(AudioSession, { foreignKey: 'audioSessionId' });


StorageProviderInfo.hasMany(AudioRecording, { foreignKey: 'storageId' });
AudioRecording.belongsTo(StorageProviderInfo, { foreignKey: 'storageId' });


VoiceTranscript.hasMany(TranscriptionChunks, { foreignKey: 'voiceTranscriptId' });
TranscriptionChunks.belongsTo(VoiceTranscript, { foreignKey: 'voiceTranscriptId' });


export async function initDatabase() {
  logger.debug('Initializing database bindings (no schema changes)');
  return await sequelize.sync();
}

/**
 * Synchronize the database schema.
 */
export async function syncDatabase() {
  logger.debug('Synchronizing database schema (with potential schema changes)');
  return await sequelize.sync({ alter: true });
}

/**
 * Reset the database schema and remove all the data from DB.
 * Warning: This will delete all the data from the database!
 */
export async function resetDatabase() {
  logger.debug('Resetting database schema and removing all data');
  return await sequelize.sync({ force: true });
}
