import { Model } from 'sequelize';

export type Metadata = Record<string, unknown>;

// Type alias for roles
export type Role =
  // Organizations
  | 'create-orgs'
  | 'modify-orgs'
  | 'view-orgs'

  // API Keys
  | 'create-api-keys'
  | 'modify-api-keys'
  | 'view-api-keys'
  | 'revoke-api-keys'

  // Users
  | 'create-users'
  | 'modify-users'
  | 'view-users'
  | 'remove-users'

  // Audio Sessions
  | 'create-sessions'
  | 'join-sessions'
  | 'modify-sessions'
  | 'view-sessions'
  | 'remove-sessions'

  // Audio Recordings
  | 'modify-recordings'
  | 'view-recordings'
  | 'remove-recordings'

  // Voice Transcripts
  | 'modify-transcripts'
  | 'view-transcripts'
  | 'remove-transcripts'

  // ASR Providers
  | 'create-asr-providers'
  | 'modify-asr-providers'
  | 'view-asr-providers'
  | 'remove-asr-providers'

  // ASR Profiles
  | 'create-asr-profiles'
  | 'modify-asr-profiles'
  | 'view-asr-profiles'
  | 'remove-asr-profiles'

  // Storage Providers
  | 'create-storage-providers'
  | 'modify-storage-providers'
  | 'view-storage-providers'
  | 'remove-storage-providers';

export type OrganizationStatus = 'active' | 'inactive';

export class Organization extends Model {
  declare public id: string;
  declare public name: string;
  declare public status: OrganizationStatus;
  declare public metadata: Metadata;
  declare public createdAt: Date;
  declare public updatedAt: Date;
}

export type UserStatus = 'active' | 'inactive';

export class User extends Model {
  declare public id: string;
  declare public organizationId: string;
  declare public name: string;
  declare public status: UserStatus;
  declare public roles: Role[];
  declare public metadata: Metadata;
  declare public createdAt: Date;
  declare public updatedAt: Date;
}

export type ApiKeyStatus = 'active' | 'inactive' | 'revoked';

export class ApiKey extends Model {
  declare public key: string;
  declare public organizationId: string;
  declare public status: ApiKeyStatus;
  declare public roles: Role[];
  declare public createdAt: Date;
  declare public updatedAt: Date;
}

export type AudioSessionStatus = 'active' | 'inactive' | 'closed' | 'failed';

export class AudioSession extends Model {
  declare public id: string;
  declare public organizationId: string;
  declare public status: AudioSessionStatus;
  declare public statusDetails: string;
  declare public usedAsrProfile: AsrProfile;
  declare public storageProvider: StorageProviderInfo;
  declare public metadata: Metadata;
  declare public endedAt: Date;
  declare public createdAt: Date;
  declare public updatedAt: Date;
}

export type AudioRecordingFileFormat = 'mp3' | 'wav';

export class AudioRecording extends Model {
  declare public id: string;
  declare public organizationId: string;
  declare public audioSessionId: string;
  declare public storageId: string;
  declare public storageUrl: string;
  declare public fileName: string;
  declare public fileFormat: AudioRecordingFileFormat;
  declare public metadata: Metadata;
  declare public createdAt: Date;
}

export type VoiceTranscriptType = 'raw' | 'redacted';

export class VoiceTranscript extends Model {
  declare public id: string;
  declare public organizationId: string;
  declare public audioSessionId: string;
  declare public type: VoiceTranscriptType;
  declare public typeDetails: string;
  declare public text: string;
  declare public metadata: Metadata;
  declare public createdAt: Date;
}

export type StorageType = 's3' | 'local';

export class StorageProviderInfo extends Model {
  declare public id: string;
  declare public organizationId: string;
  declare public name: string;
  declare public type: StorageType;
  declare public config: Metadata;
  declare public metadata: Metadata;
  declare public createdAt: Date;
  declare public updatedAt: Date;
}

export class AsrProviderInfo extends Model {
  declare public id: string;
  declare public organizationId: string;
  declare public name: string;
  declare public type: string;
  declare public config: Metadata;
  declare public metadata: Metadata;
}

export class AsrProfile extends Model {
  declare public id: string;
  declare public organizationId: string;
  declare public providerId: string;
  declare public name: string;
  declare public metadata: Metadata;
}

export type ConnectionType = 'producer' | 'consumer';
export type StreamType = 'raw' | 'sentence';

export class Connection extends Model {
  declare public connectionToken: string;
  declare public audioSessionId: string;
  declare public connectionType: ConnectionType;
  declare public streamTypes?: StreamType[];
}

export class TranscriptionChunks extends Model {
  declare public id: string;
  declare public voiceTranscriptId: string;
  declare public ordinal: number;
  declare public sessionId: string;
  declare public transcribedText: string;
  declare public audioPositionFrom: number;
  declare public audioPositionTo: number;
  declare public metadata: Metadata;
}
