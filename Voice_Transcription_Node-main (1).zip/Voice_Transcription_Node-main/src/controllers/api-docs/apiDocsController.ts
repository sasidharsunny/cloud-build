import { Controller, Get, Req, Res } from '@decorators/express';
import { NextFunction, Request, Response, RequestHandler } from 'express';
import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import { injectable } from 'tsyringe';

import { logger } from '../../utils/logger';

@injectable()
@Controller('/api-docs')
export class ApiDocsController {
  private swaggerUiHandler: RequestHandler;

  constructor() {
    const options = {
      failOnErrors: true,
      definition: {
        openapi: '3.0.1',
        info: {
          title: 'Telus-VP',
          version: '0.0.1',
        },
        components: {
          securitySchemes: {
            Authorization: {
              type: 'apiKey',
              in: 'header',
              name: 'Authorization',
            },
          },
        },
      },
      apis: [
        './src/controllers/**/*Controller.ts'
      ],
      security: [
        {
          Authorization: []
        }
      ]
    };

    const openApiSpecification = swaggerJsdoc(options);
    this.swaggerUiHandler = swaggerUi.setup(openApiSpecification);
  }


  /**
   * @openapi
   * /api-docs:
   *    get:
   *      summary: Returns HTML with Swagger UI for API
   *      description: Returns HTML with Swagger UI for API
   *      tags:
   *        - API docs
   *      responses:
   *        200:
   *          description: Success
   *        
   */
  @Get('/')
  apiDocs(@Req() req: Request, @Res() res: Response, next: NextFunction) {
    logger.info('GET api-docs');
    return this.swaggerUiHandler(req, res, next);
  }
}
