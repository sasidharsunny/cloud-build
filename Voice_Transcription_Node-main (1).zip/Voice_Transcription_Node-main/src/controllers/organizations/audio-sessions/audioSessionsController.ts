import { Controller, Delete, Get, Put, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { UpdateAudioSessionParams } from '../../../api/contracts';
import { AudioSessionsService } from '../../../services/sessions/audioSessionService';


@injectable()
@Controller('/orgs/:organizationId/audio-sessions', { mergeParams: true })
export class AudioSessionsController {
  constructor(
    @inject(AudioSessionsService) private audioSessionService: AudioSessionsService,
  ) { }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{sessionId}:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get audio session
   *      description: Get audios session
   *      tags:
   *        - Audio sessions
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: sessionId
   *          in: path
   *          required: true
   *          description: Id of an audio session
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  status:
   *                    type: string
   *                    example: active
   *                  status_details:
   *                    type: string
   *                    example: test
   *                  usedAsrProfile:
   *                    type: object
   *                    example: {"id":"0973a0a7-c1f0-4c70-8c2a-3ebb3bb778ee","organizationId":"123e4567-e89b-12d3-a456-426614174999","providerId":"02668ebe-3d55-400f-98df-72ef481d12b9","name":"test","metadata":{"speechLanguage":"en-US","dictionaryPhrases":["Telus"]},"createdAt":"2024-11-27T23:00:00.000Z","updatedAt":"2024-11-28T15:34:32.000Z","OrganizationId":"123e4567-e89b-12d3-a456-426614174999"}
   *                  storageProvider:
   *                    type: object
   *                    example: {"id":"3d1cdd5c-7f8f-4624-b0c4-12e99fd64465","organizationId":"123e4567-e89b-12d3-a456-426614174999","name":"S3 Test","type":"s3","metadata":{},"config":{"accessKeyId":"AKIATSJGIMAHUD5PR47S","secretAccessKey":"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","region":"us-east-1","bucket":"telus-dev-storage","rootDirectory":"./test/"},"createdAt":"2024-12-11T23:00:00.000Z","updatedAt":"2024-12-11T23:00:00.000Z","OrganizationId":"123e4567-e89b-12d3-a456-426614174999"}
   *                  metadata:
   *                    type: object
   *                    example: {"title":"The story"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  endedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/:sessionId')
  async getAudioSession(@Req() req: Request, @Res() res: Response) {
    const { sessionId } = req.params;
    const session = await this.audioSessionService.getSession(req.ctx, sessionId);
    return res.status(200).send(session);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get all audio sessions
   *      description: Get all audios sessions
   *      tags:
   *        - Audio sessions
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: array
   *                items:
   *                  type: object
   *                  properties:
   *                    id:
   *                      type: string
   *                      example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                    organizationId:
   *                      type: string
   *                      example: 123e4567-e89b-12d3-a456-426614174999
   *                    status:
   *                      type: string
   *                      example: active
   *                    status_details:
   *                      type: string
   *                      example: test
   *                    usedAsrProfile:
   *                      type: object
   *                      example: {"id":"0973a0a7-c1f0-4c70-8c2a-3ebb3bb778ee","organizationId":"123e4567-e89b-12d3-a456-426614174999","providerId":"02668ebe-3d55-400f-98df-72ef481d12b9","name":"test","metadata":{"speechLanguage":"en-US","dictionaryPhrases":["Telus"]},"createdAt":"2024-11-27T23:00:00.000Z","updatedAt":"2024-11-28T15:34:32.000Z","OrganizationId":"123e4567-e89b-12d3-a456-426614174999"}
   *                    storageProvider:
   *                      type: object
   *                      example: {"id":"3d1cdd5c-7f8f-4624-b0c4-12e99fd64465","organizationId":"123e4567-e89b-12d3-a456-426614174999","name":"S3 Test","type":"s3","metadata":{},"config":{"accessKeyId":"AKIATSJGIMAHUD5PR47S","secretAccessKey":"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","region":"us-east-1","bucket":"telus-dev-storage","rootDirectory":"./test/"},"createdAt":"2024-12-11T23:00:00.000Z","updatedAt":"2024-12-11T23:00:00.000Z","OrganizationId":"123e4567-e89b-12d3-a456-426614174999"}
   *                    metadata:
   *                      type: object
   *                      example: {"title":"The story"}
   *                    createdAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *                    endedAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/')
  async getAllAudioSessions(@Req() req: Request, @Res() res: Response) {
    const sessions = await this.audioSessionService.getAllSessions(req.ctx);
    return res.status(200).send(sessions);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{sessionId}:
   *    put:
   *      security:
   *        - Authorization: []
   *      summary: Update audio session
   *      description: Update audios session
   *      tags:
   *        - Audio sessions
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: sessionId
   *          in: path
   *          required: true
   *          description: Id of an audio session
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                status:
   *                  type: string
   *                  example: inactive
   *                statusDetails:
   *                  type: string
   *                  example: success
   *                metadata:
   *                  type: object
   *                  example: {"speechLanguage":"en-US"}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  status:
   *                    type: string
   *                    example: inactive
   *                  status_details:
   *                    type: string
   *                    example: success
   *                  usedAsrProfile:
   *                    type: object
   *                    example: {"id":"0973a0a7-c1f0-4c70-8c2a-3ebb3bb778ee","organizationId":"123e4567-e89b-12d3-a456-426614174999","providerId":"02668ebe-3d55-400f-98df-72ef481d12b9","name":"test","metadata":{"speechLanguage":"en-US","dictionaryPhrases":["Telus"]},"createdAt":"2024-11-27T23:00:00.000Z","updatedAt":"2024-11-28T15:34:32.000Z","OrganizationId":"123e4567-e89b-12d3-a456-426614174999"}
   *                  storageProvider:
   *                    type: object
   *                    example: {"id":"3d1cdd5c-7f8f-4624-b0c4-12e99fd64465","organizationId":"123e4567-e89b-12d3-a456-426614174999","name":"S3 Test","type":"s3","metadata":{},"config":{"accessKeyId":"AKIATSJGIMAHUD5PR47S","secretAccessKey":"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","region":"us-east-1","bucket":"telus-dev-storage","rootDirectory":"./test/"},"createdAt":"2024-12-11T23:00:00.000Z","updatedAt":"2024-12-11T23:00:00.000Z","OrganizationId":"123e4567-e89b-12d3-a456-426614174999"}
   *                  metadata:
   *                    type: object
   *                    example: {"speechLanguage":"en-US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  endedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Put('/:sessionId')
  async updateAudioSession(@Req() req: Request, @Res() res: Response) {
    const { sessionId } = req.params;
    const { metadata, status, statusDetails } = req.body as UpdateAudioSessionParams;

    const session = await this.audioSessionService.updateSession(req.ctx, sessionId, { metadata, status, statusDetails });
    return res.status(200).send(session);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{sessionId}:
   *    delete:
   *      security:
   *        - Authorization: []
   *      summary: Delete audio session
   *      description: Delete audio session
   *      tags:
   *        - Audio sessions
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: sessionId
   *          in: path
   *          required: true
   *          description: Audio session id
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *      responses:
   *        204:
   *          description: No content
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   *        404:
   *          description: Not found
   */
  @Delete('/:sessionId')
  async deleteAudioSession(@Req() req: Request, @Res() res: Response) {
    const { organizationId, sessionId } = req.params;

    await this.audioSessionService.deleteSession(req.ctx, organizationId, sessionId);
    return res.status(204).send();
  }
}
