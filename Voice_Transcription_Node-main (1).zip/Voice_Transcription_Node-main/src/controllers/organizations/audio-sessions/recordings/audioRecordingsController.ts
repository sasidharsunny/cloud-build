import { Controller, Delete, Get, Put, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { UpdateAudioRecordingParams } from '../../../../api/contracts';
import { AudioRecordingsService } from '../../../../services/audio/audioRecordingsService';

@injectable()
@Controller('/orgs/:organizationId/audio-sessions/:audioSessionId/recordings', { mergeParams: true })
export class AudioRecordingsController {
  constructor(
    @inject(AudioRecordingsService) private audioRecordingsService: AudioRecordingsService,
  ) { }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{sessionId}/recordings/{audioRecordingId}:
   *    put:
   *      security:
   *        - Authorization: []
   *      summary: Update audio recording
   *      description: Update audio recording
   *      tags:
   *        - Audio recordings
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: sessionId
   *          in: path
   *          required: true
   *          description: Id of an audio session
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *        - name: audioRecordingId
   *          in: path
   *          required: true
   *          description: Id of an audio recording
   *          schema:
   *            type: string
   *            example: 30ca7109-1a37-47f4-b210-8dfb6484c25c
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                metadata:
   *                  type: object
   *                  example: {"speechLanguage":"en-US"}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 30ca7109-1a37-47f4-b210-8dfb6484c25c
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  audioSessionId:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                  storageId:
   *                    type: string
   *                    example: 3d1cdd5c-7f8f-4624-b0c4-12e99fd64465
   *                  storageUrl:
   *                    type: string
   *                    example: https://example.com/url/to/uploaded/file
   *                  fileName:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5.wav
   *                  fileFormat:
   *                    type: string
   *                    example: wav
   *                  metadata:
   *                    type: object
   *                    example: {"speechLanguage":"en-US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Put('/:audioRecordingId')
  async updateAudioRecording(@Req() req: Request, @Res() res: Response) {
    const { audioSessionId, audioRecordingId } = req.params;
    const { metadata } = req.body as UpdateAudioRecordingParams;
    const storage = await this.audioRecordingsService.updateRecording(req.ctx, audioSessionId, audioRecordingId, { metadata });
    return res.status(200).send(storage);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{audioSessionId}/recordings/{audioRecordingId}:
   *    delete:
   *      security:
   *        - Authorization: []
   *      summary: Delete audio recording
   *      description: Delete audio recording
   *      tags:
   *        - Audio recordings
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: audioSessionId
   *          in: path
   *          required: true
   *          description: Audio session id
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *        - name: audioRecordingId
   *          in: path
   *          required: true
   *          description: Id of an audio recording
   *          schema:
   *            type: string
   *            example: 30ca7109-1a37-47f4-b210-8dfb6484c25c
   *      responses:
   *        204:
   *          description: No content
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   *        404:
   *          description: Not found
   */
  @Delete('/:audioRecordingId')
  async deleteAudioRecording(@Req() req: Request, @Res() res: Response) {
    const { audioSessionId, audioRecordingId } = req.params;
    await this.audioRecordingsService.deleteRecording(req.ctx, audioSessionId, audioRecordingId);
    return res.status(204).send();
  }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{audioSessionId}/recordings/{audioRecordingId}:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get audio recording
   *      description: Get audios recording
   *      tags:
   *        - Audio recordings
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: audioSessionId
   *          in: path
   *          required: true
   *          description: Audio session id
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *        - name: audioRecordingId
   *          in: path
   *          required: true
   *          description: Audio recording id
   *          schema:
   *            type: string
   *            example: 30ca7109-1a37-47f4-b210-8dfb6484c25c
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 30ca7109-1a37-47f4-b210-8dfb6484c25c
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  audioSessionId:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                  storageId:
   *                    type: string
   *                    example: 3d1cdd5c-7f8f-4624-b0c4-12e99fd64465
   *                  storageUrl:
   *                    type: string
   *                    example: https://example.com/url/to/uploaded/file
   *                  fileName:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5.wav
   *                  fileFormat:
   *                    type: string
   *                    example: wav
   *                  metadata:
   *                    type: object
   *                    example: {"title":"The story"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/:audioRecordingId')
  async getAudioRecording(@Req() req: Request, @Res() res: Response) {
    const { audioSessionId, audioRecordingId } = req.params;
    const audioRecording = await this.audioRecordingsService.getRecording(req.ctx, audioSessionId, audioRecordingId);
    return res.status(200).send(audioRecording);
  }


  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{audioSessionId}/recordings:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get all audio recordings
   *      description: Get all audios recordings
   *      tags:
   *        - Audio recordings
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: audioSessionId
   *          in: path
   *          required: true
   *          description: Audio session id
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: array
   *                items:
   *                  type: object
   *                  properties:
   *                    id:
   *                      type: string
   *                      example: 30ca7109-1a37-47f4-b210-8dfb6484c25c
   *                    organizationId:
   *                      type: string
   *                      example: 123e4567-e89b-12d3-a456-426614174999
   *                    audioSessionId:
   *                      type: string
   *                      example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                    storageId:
   *                      type: string
   *                      example: 3d1cdd5c-7f8f-4624-b0c4-12e99fd64465
   *                    storageUrl:
   *                      type: string
   *                      example: https://example.com/url/to/uploaded/file
   *                    fileName:
   *                      type: string
   *                      example: 2c4906ca-706e-4d88-b67e-c76610623ba5.wav
   *                    fileFormat:
   *                      type: string
   *                      example: wav
   *                    metadata:
   *                      type: object
   *                      example: {"title":"The story"}
   *                    createdAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/')
  async getAllAudioRecordings(@Req() req: Request, @Res() res: Response) {
    const { audioSessionId, organizationId } = req.params;
    const audioRecordings = await this.audioRecordingsService.getRecordings(req.ctx, organizationId, audioSessionId);
    return res.status(200).send(audioRecordings);
  }
}
