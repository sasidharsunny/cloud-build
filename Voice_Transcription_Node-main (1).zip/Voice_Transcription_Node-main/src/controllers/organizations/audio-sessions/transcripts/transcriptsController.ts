import { Controller, Delete, Get, Put, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { UpdateTranscriptParams } from '../../../../api/contracts';
import { TranscriptsService } from '../../../../services/transcription/transcriptsService';

@injectable()
@Controller('/orgs/:organizationId/audio-sessions/:audioSessionId/transcripts', { mergeParams: true })
export class TranscriptController {
  constructor(
    @inject(TranscriptsService) private transcriptsService: TranscriptsService,
  ) { }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{sessionId}/transcripts/{voiceTranscriptId}:
   *    put:
   *      security:
   *        - Authorization: []
   *      summary: Update audio transcript
   *      description: Update audio transcript
   *      tags:
   *        - Audio transcripts
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: sessionId
   *          in: path
   *          required: true
   *          description: Id of an audio session
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *        - name: voiceTranscriptId
   *          in: path
   *          required: true
   *          description: Id of an audio transcript
   *          schema:
   *            type: string
   *            example: 26a84edf-b4e2-451c-9f9b-173754541827
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                metadata:
   *                  type: object
   *                  example: {"speechLanguage":"en-US"}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 26a84edf-b4e2-451c-9f9b-173754541827
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  audioSessionId:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                  type:
   *                    type: string
   *                    example: raw
   *                  typeDetails:
   *                    type: string
   *                    example: test
   *                  text:
   *                    type: string
   *                    example: Pizza is great
   *                  metadata:
   *                    type: object
   *                    example: {"speechLanguage":"en-US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Put('/:voiceTranscriptId')
  async updateTranscript(@Req() req: Request, @Res() res: Response) {
    const { audioSessionId, voiceTranscriptId } = req.params;
    const { metadata } = req.body as UpdateTranscriptParams;
    const transcript = await this.transcriptsService.updateTranscript(req.ctx, audioSessionId, voiceTranscriptId, { metadata });
    return res.status(200).send(transcript);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{sessionId}/transcripts/{voiceTranscriptId}:
   *    delete:
   *      security:
   *        - Authorization: []
   *      summary: Delete audio transcript
   *      description: Delete audio transcript
   *      tags:
   *        - Audio transcripts
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: sessionId
   *          in: path
   *          required: true
   *          description: Audio recording id
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *        - name: voiceTranscriptId
   *          in: path
   *          required: true
   *          description: Id of an audio transcript
   *          schema:
   *            type: string
   *            example: 30ca7109-1a37-47f4-b210-8dfb6484c25c
   *      responses:
   *        204:
   *          description: No content
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   *        404:
   *          description: Not found
   */
  @Delete('/:voiceTranscriptId')
  async deleteTranscript(@Req() req: Request, @Res() res: Response) {
    const { audioSessionId, voiceTranscriptId } = req.params;
    await this.transcriptsService.deleteTranscript(req.ctx, audioSessionId, voiceTranscriptId);
    return res.status(204).send();
  }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{sessionId}/transcripts/{voiceTranscriptId}:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get audio transcript
   *      description: Get audio transcript
   *      tags:
   *        - Audio transcripts
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: sessionId
   *          in: path
   *          required: true
   *          description: Id of an audio session
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *        - name: voiceTranscriptId
   *          in: path
   *          required: true
   *          description: Id of an audio transcript
   *          schema:
   *            type: string
   *            example: 26a84edf-b4e2-451c-9f9b-173754541827
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 26a84edf-b4e2-451c-9f9b-173754541827
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  audioSessionId:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                  type:
   *                    type: string
   *                    example: raw
   *                  typeDetails:
   *                    type: string
   *                    example: test
   *                  text:
   *                    type: string
   *                    example: Pizza is great
   *                  metadata:
   *                    type: object
   *                    example: {"speechLanguage":"en-US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/:voiceTranscriptId')
  async getTranscript(@Req() req: Request, @Res() res: Response) {
    const { audioSessionId, voiceTranscriptId } = req.params;
    const transcript = await this.transcriptsService.getTranscript(req.ctx, audioSessionId, voiceTranscriptId);
    return res.status(200).send(transcript);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/audio-sessions/{sessionId}/transcripts:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get all audio transcripts
   *      description: Get all audio transcripts
   *      tags:
   *        - Audio transcripts
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: sessionId
   *          in: path
   *          required: true
   *          description: Id of an audio session
   *          schema:
   *            type: string
   *            example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: array
   *                items:
   *                  type: object
   *                  properties:
   *                    id:
   *                      type: string
   *                      example: 26a84edf-b4e2-451c-9f9b-173754541827
   *                    organizationId:
   *                      type: string
   *                      example: 123e4567-e89b-12d3-a456-426614174999
   *                    audioSessionId:
   *                      type: string
   *                      example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                    type:
   *                      type: string
   *                      example: raw
   *                    typeDetails:
   *                      type: string
   *                      example: test
   *                    text:
   *                      type: string
   *                      example: Pizza is great
   *                    metadata:
   *                      type: object
   *                      example: {"speechLanguage":"en-US"}
   *                    createdAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/')
  async getAllTranscripts(@Req() req: Request, @Res() res: Response) {
    const { audioSessionId } = req.params;
    const transcript = await this.transcriptsService.getTranscripts(req.ctx, audioSessionId);
    return res.status(200).send(transcript);
  }
}
