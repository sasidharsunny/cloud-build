import { Controller, Get, Post, Put, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { CreateOrganizationParams, UpdateOrganizationParams } from '../../api/contracts';
import { InvalidParameter } from '../../errors';
import { OrganizationService } from '../../services/membership/organizationService';

@injectable()
@Controller('/orgs')
export class OrganizationController {
  constructor(
    @inject(OrganizationService) private organizationService: OrganizationService,
  ) { }

  /**
   * @openapi
   * /orgs:
   *    post:
   *      security:
   *        - Authorization: []
   *      summary: Create organization
   *      description: Create organization
   *      tags:
   *        - Organizations
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                name:
   *                  type: string
   *                  example: Organization A
   *                status:
   *                  type: string
   *                  example: active
   *                metadata:
   *                  type: object
   *                  example: {"location":"US"}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  name:
   *                    type: string
   *                    example: Organization A
   *                  status:
   *                    type: string
   *                    example: active
   *                  metadata:
   *                    type: object
   *                    example: {"location":"US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Post('/')
  async createOrganization(@Req() req: Request, @Res() res: Response) {
    const { name, metadata, status } = req.body as CreateOrganizationParams;
    if (!name)
      throw new InvalidParameter('missing name');

    const organization = await this.organizationService.createOrganization(req.ctx, { name, metadata, status: status ?? 'active' });
    return res.status(200).send(organization);
  }

  /**
   * @openapi
   * /orgs/{organizationId}:
   *    put:
   *      security:
   *        - Authorization: []
   *      summary: Update organization
   *      description: Update organization
   *      tags:
   *        - Organizations
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                name:
   *                  type: string
   *                  example: Organization A
   *                status:
   *                  type: string
   *                  example: inactive
   *                metadata:
   *                  type: object
   *                  example: {"location":"US"}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  name:
   *                    type: string
   *                    example: Organization A
   *                  status:
   *                    type: string
   *                    example: inactive
   *                  metadata:
   *                    type: object
   *                    example: {"location":"US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Put('/:organizationId')
  async updateOrganization(@Req() req: Request, @Res() res: Response) {
    const { metadata, name, status } = req.body as UpdateOrganizationParams;
    const organization = await this.organizationService.updateOrganization(req.ctx, { metadata, name, status });
    return res.status(200).send(organization);
  }

  /**
   * @openapi
   * /orgs/{organizationId}:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get organization
   *      description: Get organization
   *      tags:
   *        - Organizations
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  name:
   *                    type: string
   *                    example: Organization A
   *                  status:
   *                    type: string
   *                    example: active
   *                  metadata:
   *                    type: object
   *                    example: {"location":"US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/:organizationId')
  async getOrganization(@Req() req: Request, @Res() res: Response) {
    const organization = await this.organizationService.getOrganization(req.ctx);
    return res.status(200).send(organization);
  }

  /**
   * @openapi
   * /orgs:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get all organizations
   *      description: Get all organizations
   *      tags:
   *        - Organizations
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: array
   *                items:
   *                  type: object
   *                  properties:
   *                    id:
   *                      type: string
   *                      example: 123e4567-e89b-12d3-a456-426614174999
   *                    name:
   *                      type: string
   *                      example: Organization A
   *                    status:
   *                      type: string
   *                      example: active
   *                    metadata:
   *                      type: object
   *                      example: {"location":"US"}
   *                    createdAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *                    updatedAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/')
  async getAllOrganizations(@Req() req: Request, @Res() res: Response) {
    const organizations = await this.organizationService.getOrganizations(req.ctx);
    return res.status(200).send(organizations);
  }
}

