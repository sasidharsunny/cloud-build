import { Controller, Delete, Get, Post, Put, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { Role } from '../../../db/models';
import { InvalidParameter } from '../../../errors';
import { ApiKeyService } from '../../../services/membership/apiKeyService';

type CreateApiKeyBody = {
  roles: Role[],
}

@injectable()
@Controller('/orgs/:organizationId/api-keys', { mergeParams: true })
export class ApiKeysController {

  constructor(
    @inject(ApiKeyService) private apiKeyService: ApiKeyService,
  ) { }

  /**
   * @openapi
   * /orgs/{organizationId}/api-keys:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get all API keys 
   *      description: Get all API keys that belong to organization
   *      tags:
   *        - API keys
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: array
   *                items:
   *                  type: object
   *                  properties:
   *                    key:
   *                      type: string
   *                      example: 21c05051-0312-4b49-8608-4afe89236847
   *                    organizationId:
   *                      type: string
   *                      example: 123e4567-e89b-12d3-a456-426614174999
   *                    status:
   *                      type: string
   *                      example: active
   *                    roles:
   *                      type: array
   *                      items:
   *                        type: string
   *                        example: view-api-keys
   *                    createdAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *                    updatedAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   *        
   */
  @Get('/')
  async getAllApiKeys(@Req() req: Request, @Res() res: Response) {
    const tokens = await this.apiKeyService.getAllAccessTokens(req.ctx);
    return res.status(200).send(tokens);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/api-keys:
   *    post:
   *      security:
   *        - Authorization: []
   *      summary: Create new API key 
   *      description: Create new API key using provided data
   *      tags:
   *        - API keys
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                roles:
   *                  type: array
   *                  items:
   *                    type: string
   *                    example: view-api-keys
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  key:
   *                    type: string
   *                    example: 21c05051-0312-4b49-8608-4afe89236847
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  status:
   *                    type: string
   *                    example: active
   *                  roles:
   *                    type: array
   *                    items:
   *                      type: string
   *                      example: view-api-keys
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Post('/')
  async createApiKey(@Req() req: Request, @Res() res: Response) {
    const { roles } = req.body as CreateApiKeyBody;
    if (!roles || roles.length === 0)
      throw new InvalidParameter('roles is null or empty');

    const token = await this.apiKeyService.createAccessToken(req.ctx, roles, 'active');
    return res.status(201).send(token);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/api-keys/{key}:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get API key by id
   *      description: Get API key that belongs to organization
   *      tags:
   *        - API keys
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: key
   *          in: path
   *          required: true
   *          description: UUID of a key
   *          schema:
   *            type: string
   *            example: 21c05051-0312-4b49-8608-4afe89236847
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  key:
   *                    type: string
   *                    example: 21c05051-0312-4b49-8608-4afe89236847
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  status:
   *                    type: string
   *                    example: active
   *                  roles:
   *                    type: array
   *                    items:
   *                      type: string
   *                      example: view-api-keys
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   *        
   */
  @Get('/:key')
  async getApiKey(@Req() req: Request, @Res() res: Response) {
    const { key } = req.params;
    const token = await this.apiKeyService.getAccessToken(req.ctx, key);
    return res.status(200).send(token);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/api-keys/{key}:
   *    put:
   *      security:
   *        - Authorization: []
   *      summary: Update API key 
   *      description: Update API key 
   *      tags:
   *        - API keys
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: key
   *          in: path
   *          required: true
   *          description: UUID of a key
   *          schema:
   *            type: string
   *            example: 21c05051-0312-4b49-8608-4afe89236847
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                roles:
   *                  type: array
   *                  items:
   *                    type: string
   *                  example: [view-api-keys, modify-api-keys]
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  key:
   *                    type: string
   *                    example: 21c05051-0312-4b49-8608-4afe89236847
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  status:
   *                    type: string
   *                    example: active
   *                  roles:
   *                    type: array
   *                    items:
   *                      type: string
   *                    example: [view-api-keys, modify-api-keys]
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Put('/:key')
  async updateApiKey(@Req() req: Request, @Res() res: Response) {
    const { key } = req.params;

    const { roles } = req.body as CreateApiKeyBody;
    if (!roles || roles.length === 0)
      throw new InvalidParameter('roles is null or empty');

    const token = await this.apiKeyService.modifyAccessToken(req.ctx, key, roles);
    return res.status(200).send(token);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/api-keys/{key}:
   *    delete:
   *      security:
   *        - Authorization: []
   *      summary: Revoke API key
   *      description: Sets API key status to revoked
   *      tags:
   *        - API keys
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: Id of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: key
   *          in: path
   *          required: true
   *          description: Id of a key
   *          schema:
   *            type: string
   *            example: 21c05051-0312-4b49-8608-4afe89236847
   *      responses:
   *        200:
   *          description: Success
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Delete('/:key')
  async revokeApiKey(@Req() req: Request, @Res() res: Response) {
    const { key } = req.params;
    await this.apiKeyService.revokeAccessToken(req.ctx, key);
    return res.status(204).send();
  }
}
