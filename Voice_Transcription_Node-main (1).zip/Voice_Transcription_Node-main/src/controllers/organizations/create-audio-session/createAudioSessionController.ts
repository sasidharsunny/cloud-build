import { Controller, Post, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { CreateAudioSessionParams, CreateConnectionParams } from '../../../api/contracts';
import { ConnectionService } from '../../../services/communication/connectionService';
import { AudioSessionsService } from '../../../services/sessions/audioSessionService';

@injectable()
@Controller('/orgs/:organizationId/create-audio-session', { mergeParams: true })
export class CreateAudioSessionController {
  constructor(
    @inject(AudioSessionsService) private audioSessionService: AudioSessionsService,
    @inject(ConnectionService) private connectionService: ConnectionService,
  ) { }

  /**
   * @openapi
   * /orgs/{organizationId}/create-audio-session:
   *    post:
   *      security:
   *        - Authorization: []
   *      summary: Create new audio session
   *      description: Create new audio session and retrieve connection details
   *      tags:
   *        - Audio sessions
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                asrProfileId:
   *                  type: string
   *                  example: 0973a0a7-c1f0-4c70-8c2a-3ebb3bb778ee
   *                storageProviderId:
   *                  type: string
   *                  example: 3d1cdd5c-7f8f-4624-b0c4-12e99fd64465
   *                metadata:
   *                  type: object
   *                  example: {"test":"test","qwerty":[1]}
   *      responses:
   *        201:
   *          description: Created
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  audioSessionId:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                  connectionToken:
   *                    type: string
   *                    example: e5a16f27-6cf3-404f-bab0-dcaf986d7905
   *                  streamingUrl:
   *                    type: string
   *                    example: ws://localhost:8081/orgs/123e4567-e89b-12d3-a456-426614174999/audio-stream
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Post('/')
  async createAudioSession(@Req() req: Request, @Res() res: Response) {
    const { asrProfileId, storageProviderId, metadata } = req.body as CreateAudioSessionParams;

    const audioSession = await this.audioSessionService.createSession(req.ctx, { asrProfileId, storageProviderId, metadata });
    const createParams: CreateConnectionParams = {
      audioSessionId: audioSession.id,
      connectionType: 'producer',
    };
    const { connection, streamingUrl } = await this.connectionService.createConnection(req.ctx, createParams);
    const { connectionToken } = connection;

    return res.status(201).send({
      audioSessionId: audioSession.id,
      connectionToken,
      streamingUrl,
    });
  }
}
