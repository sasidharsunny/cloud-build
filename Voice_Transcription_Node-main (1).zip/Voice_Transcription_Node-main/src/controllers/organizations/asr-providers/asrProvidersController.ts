import { Controller, Delete, Get, Post, Put, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { CreateAsrProviderParams, UpdateAsrProviderParams } from '../../../api/contracts';
import { InvalidParameter } from '../../../errors';
import { AsrProvidersService } from '../../../services/transcription/asrProvidersService';


@injectable()
@Controller('/orgs/:organizationId/asr-providers', { mergeParams: true })
export class AsrProvidersController {
  constructor(
    @inject(AsrProvidersService) private asrProvidersService: AsrProvidersService,
  ) { }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-providers:
   *    post:
   *      security:
   *        - Authorization: []
   *      summary: Create ASR provider
   *      description: Create ASR provider
   *      tags:
   *        - ASR providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                name:
   *                  type: string
   *                  example: test2
   *                type:
   *                  type: string
   *                  example: Azure ASR
   *                config:
   *                  type: string
   *                  example: {"azureKey":"SECRET_API_KEY","azureRegion":"westeurope"}
   *                metadata:
   *                  type: object
   *                  example: {"test":"test","qwerty":[1]}
   *      responses:
   *        201:
   *          description: Created
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 02668ebe-3d55-400f-98df-72ef481d12b9
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  name:
   *                    type: string
   *                    example: Azure ASR
   *                  type:
   *                    type: string
   *                    example: azure
   *                  metadata:
   *                    type: string
   *                    example: {"test":"test","qwerty":[1]}
   *                  config:
   *                    type: string
   *                    example: {"azureKey":"SECRET_API_KEY","azureRegion":"westeurope"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Post('/')
  async createAsrProvider(@Req() req: Request, @Res() res: Response) {
    const { config, name, type, metadata } = req.body as CreateAsrProviderParams;
    if (!name) throw new InvalidParameter('missing name');
    if (!type) throw new InvalidParameter('missing type');
    if (!config) throw new InvalidParameter('missing config');
    const provider = await this.asrProvidersService.createAsrProvider(req.ctx, { config, name, type, metadata });
    return res.status(201).send(provider);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-providers/{asrProviderId}:
   *    put:
   *      security:
   *        - Authorization: []
   *      summary: Update ASR provider
   *      description: Update ASR provider
   *      tags:
   *        - ASR providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: Id of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: asrProviderId
   *          in: path
   *          required: true
   *          description: Id of and ASR provider
   *          schema:
   *            type: string
   *            example: e30f2be1-f0cd-4291-92ca-81162bf45df2
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                name:
   *                  type: string
   *                  example: Azure ASR 2nd
   *                metadata:
   *                  type: object
   *                  example: {"test":"test","qwerty":[1]}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 02668ebe-3d55-400f-98df-72ef481d12b9
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  name:
   *                    type: string
   *                    example: Azure ASR 2nd
   *                  type:
   *                    type: string
   *                    example: azure
   *                  metadata:
   *                    type: string
   *                    example: {"test":"test","qwerty":[1]}
   *                  config:
   *                    type: string
   *                    example: {"azureKey":"SECRET_API_KEY","azureRegion":"westeurope"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Put('/:asrProviderId')
  async updateAsrProvider(@Req() req: Request, @Res() res: Response) {
    const { asrProviderId } = req.params;
    const { metadata, name } = req.body as UpdateAsrProviderParams;
    const provider = await this.asrProvidersService.updateAsrProvider(req.ctx, asrProviderId, { metadata, name });
    return res.status(200).send(provider);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-providers/{asrProviderId}:
   *    delete:
   *      security:
   *        - Authorization: []
   *      summary: Delete ASR provider
   *      description: Delete ASR provider
   *      tags:
   *        - ASR providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: asrProviderId
   *          in: path
   *          required: true
   *          description: ASR provider id
   *          schema:
   *            type: string
   *            example: 02668ebe-3d55-400f-98df-72ef481d12b9
   *      responses:
   *        204:
   *          description: No content
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   *        404:
   *          description: Not found
   */
  @Delete('/:asrProviderId')
  async deleteAsrProvider(@Req() req: Request, @Res() res: Response) {
    const { asrProviderId } = req.params;
    await this.asrProvidersService.deleteAsrProvider(req.ctx, asrProviderId);
    return res.status(204).send();
  }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-providers/{asrProviderId}:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get ASR provider
   *      description: Get ASR provider
   *      tags:
   *        - ASR providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: Id of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: asrProviderId
   *          in: path
   *          required: true
   *          description: Id of ASR provider
   *          schema:
   *            type: string
   *            example: e30f2be1-f0cd-4291-92ca-81162bf45df2
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 02668ebe-3d55-400f-98df-72ef481d12b9
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  name:
   *                    type: string
   *                    example: Azure ASR
   *                  type:
   *                    type: string
   *                    example: azure
   *                  metadata:
   *                    type: string
   *                    example: {"speechLanguage":"en-US"}
   *                  config:
   *                    type: string
   *                    example: {"azureKey":"SECRET_API_KEY","azureRegion":"westeurope"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/:asrProviderId')
  async getAsrProvider(@Req() req: Request, @Res() res: Response) {
    const { asrProviderId } = req.params;
    const provider = await this.asrProvidersService.getAsrProvider(req.ctx, asrProviderId);
    return res.status(200).send(provider);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-providers:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get all ASR providers
   *      description: Get all ASR provider
   *      tags:
   *        - ASR providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: array
   *                items:
   *                  type: object
   *                  properties:
   *                    id:
   *                      type: string
   *                      example: 02668ebe-3d55-400f-98df-72ef481d12b9
   *                    organizationId:
   *                      type: string
   *                      example: 123e4567-e89b-12d3-a456-426614174999
   *                    name:
   *                      type: string
   *                      example: Azure ASR
   *                    type:
   *                      type: string
   *                      example: azure
   *                    metadata:
   *                      type: string
   *                      example: {"speechLanguage":"en-US"}
   *                    config:
   *                      type: string
   *                      example: {"azureKey":"SECRET_API_KEY","azureRegion":"westeurope"}
   *                    createdAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *                    updatedAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/')
  async getAllAsrProviders(@Req() req: Request, @Res() res: Response) {
    const { organizationId } = req.params;
    const providers = await this.asrProvidersService.getAsrProviders(req.ctx, organizationId);
    return res.status(200).send(providers);
  }
}
