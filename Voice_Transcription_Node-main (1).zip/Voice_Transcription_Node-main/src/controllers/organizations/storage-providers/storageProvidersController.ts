import { Controller, Delete, Get, Post, Put, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { CreateStorageProviderParams, UpdateStorageProviderParams } from '../../../api/contracts';
import { StorageType } from '../../../db/models';
import { InvalidParameter } from '../../../errors';
import { StorageProvidersService } from '../../../services/storage/storageProvidersService';

const AVAILABLE_STORAGE_TYPES: StorageType[] = ['s3', 'local'];

@injectable()
@Controller('/orgs/:organizationId/storage-providers', { mergeParams: true })
export class StorageProvidersController {
  constructor(
    @inject(StorageProvidersService) private storageProvidersService: StorageProvidersService,
  ) { }

  /**
   * @openapi
   * /orgs/{organizationId}/storage-providers:
   *    post:
   *      security:
   *        - Authorization: []
   *      summary: Create storage provider
   *      description: Create storage provider
   *      tags:
   *        - Storage providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                name:
   *                  type: string
   *                  example: S3 storage US East
   *                type:
   *                  type: string
   *                  example: s3
   *                config:
   *                  type: object
   *                  example: {"accessKeyId":"KEY","secretAccessKey":"SECRET","region":"us-east-1","bucket":"BUCKET_NAME","rootDirectory":"./test/"}
   *                metadata:
   *                  type: object
   *                  example: {"location":"US"}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 3d1cdd5c-7f8f-4624-b0c4-12e99fd64465
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  name:
   *                    type: string
   *                    example: S3 storage US East
   *                  type:
   *                    type: string
   *                    example: s3
   *                  config:
   *                    type: object
   *                    example: {"accessKeyId":"KEY","secretAccessKey":"SECRET","region":"us-east-1","bucket":"BUCKET_NAME","rootDirectory":"./test/"}
   *                  metadata:
   *                    type: object
   *                    example: {"location":"US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Post('/')
  async createStorageProvider(@Req() req: Request, @Res() res: Response) {
    const { config, metadata, name, type } = req.body as CreateStorageProviderParams;
    if (!name) throw new InvalidParameter('missing name');
    if (!type) throw new InvalidParameter('missing type');
    if (!config) throw new InvalidParameter('missing config');
    if (!AVAILABLE_STORAGE_TYPES.includes(type)) throw new InvalidParameter('invalid type');

    const storage = await this.storageProvidersService.createStorageProvider(req.ctx, { config, metadata, name, type });
    return res.status(200).send(storage);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/storage-providers/{storageId}:
   *    put:
   *      security:
   *        - Authorization: []
   *      summary: Update storage provider
   *      description: Update storage provider
   *      tags:
   *        - Storage providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: storageId
   *          in: path
   *          required: true
   *          description: Storage provider id
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                name:
   *                  type: string
   *                  example: S3 storage US West
   *                type:
   *                  type: string
   *                  example: s3
   *                config:
   *                  type: object
   *                  example: {"accessKeyId":"KEY","secretAccessKey":"SECRET","region":"us-west-1","bucket":"BUCKET_NAME","rootDirectory":"./test/"}
   *                metadata:
   *                  type: object
   *                  example: {"location":"US"}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 3d1cdd5c-7f8f-4624-b0c4-12e99fd64465
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  name:
   *                    type: string
   *                    example: S3 storage US West
   *                  type:
   *                    type: string
   *                    example: s3
   *                  config:
   *                    type: object
   *                    example: {"accessKeyId":"KEY","secretAccessKey":"SECRET","region":"us-west-1","bucket":"BUCKET_NAME","rootDirectory":"./test/"}
   *                  metadata:
   *                    type: object
   *                    example: {"location":"US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Put('/:storageId')
  async updateStorageProvider(@Req() req: Request, @Res() res: Response) {
    const { storageId } = req.params;
    const { config, metadata, name, type } = req.body as UpdateStorageProviderParams;
    if (!!type && !AVAILABLE_STORAGE_TYPES.includes(type)) throw new InvalidParameter('invalid type');
    const storage = await this.storageProvidersService.updateStorageProvider(req.ctx, storageId, { config, metadata, name, type });
    return res.status(200).send(storage);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/storage-providers/{storageId}:
   *    delete:
   *      security:
   *        - Authorization: []
   *      summary: Delete storage provider
   *      description: Delete storage provider
   *      tags:
   *        - Storage providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: storageId
   *          in: path
   *          required: true
   *          description: Storage provider id
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      responses:
   *        204:
   *          description: No content
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Delete('/:storageId')
  async deleteStorageProvider(@Req() req: Request, @Res() res: Response) {
    const { storageId } = req.params;
    await this.storageProvidersService.deleteStorageProvider(req.ctx, storageId);
    return res.status(204).send();
  }

  /**
   * @openapi
   * /orgs/{organizationId}/storage-providers/{storageId}:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get storage provider
   *      description: Get storage provider
   *      tags:
   *        - Storage providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: storageId
   *          in: path
   *          required: true
   *          description: Storage provider id
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 3d1cdd5c-7f8f-4624-b0c4-12e99fd64465
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  name:
   *                    type: string
   *                    example: S3 storage US West
   *                  type:
   *                    type: string
   *                    example: s3
   *                  config:
   *                    type: object
   *                    example: {"accessKeyId":"KEY","secretAccessKey":"SECRET","region":"us-west-1","bucket":"BUCKET_NAME","rootDirectory":"./test/"}
   *                  metadata:
   *                    type: object
   *                    example: {"location":"US"}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/:storageId')
  async getStorageProvider(@Req() req: Request, @Res() res: Response) {
    const { storageId } = req.params;
    const storage = await this.storageProvidersService.getStorageProvider(req.ctx, storageId);
    return res.status(200).send(storage);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/storage-providers:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get all storage providers
   *      description: Get all storage providers
   *      tags:
   *        - Storage providers
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: array
   *                items:
   *                  type: object
   *                  properties:
   *                    id:
   *                      type: string
   *                      example: 3d1cdd5c-7f8f-4624-b0c4-12e99fd64465
   *                    organizationId:
   *                      type: string
   *                      example: 123e4567-e89b-12d3-a456-426614174999
   *                    name:
   *                      type: string
   *                      example: S3 storage US West
   *                    type:
   *                      type: string
   *                      example: s3
   *                    config:
   *                      type: object
   *                      example: {"accessKeyId":"KEY","secretAccessKey":"SECRET","region":"us-west-1","bucket":"BUCKET_NAME","rootDirectory":"./test/"}
   *                    metadata:
   *                      type: object
   *                      example: {"location":"US"}
   *                    createdAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *                    updatedAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/')
  async getAllStorageProviders(@Req() req: Request, @Res() res: Response) {
    const { organizationId } = req.params;
    const storages = await this.storageProvidersService.getStorageProviders(req.ctx, organizationId);
    return res.status(200).send(storages);
  }
}

