import { Controller, Delete, Get, Post, Put, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { CreateAsrProfileParams, UpdateAsrProfileParams } from '../../../api/contracts';
import { InvalidParameter } from '../../../errors';
import { AsrProfilesService } from '../../../services/transcription/asrProfilesService';

@injectable()
@Controller('/orgs/:organizationId/asr-profiles', { mergeParams: true })
export class AsrProfilesController {
  constructor(
    @inject(AsrProfilesService) private asrProfilesService: AsrProfilesService
  ) { }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-profiles:
   *    post:
   *      security:
   *        - Authorization: []
   *      summary: Create ASR profile
   *      description: Create ASR profile using provided data
   *      tags:
   *        - ASR profiles
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                name:
   *                  type: string
   *                  example: test
   *                providerId:
   *                  type: string
   *                  example: 02668ebe-3d55-400f-98df-72ef481d12b9
   *                metadata:
   *                  type: object
   *                  example: {"speechLanguage":"en-US","dictionaryPhrases":["Telus"]}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 21c05051-0312-4b49-8608-4afe89236847
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  providerId:
   *                    type: string
   *                    example: 02668ebe-3d55-400f-98df-72ef481d12b9
   *                  name:
   *                    type: string
   *                    example: test
   *                  metadata:
   *                    type: object
   *                    example: {"speechLanguage":"en-US","dictionaryPhrases":["Telus"]}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Post('/')
  async createAsrProfile(@Req() req: Request, @Res() res: Response) {
    const { name, providerId, metadata } = req.body as CreateAsrProfileParams;
    if (!name) throw new InvalidParameter('missing name');
    if (!providerId) throw new InvalidParameter('missing providerId');
    const profile = await this.asrProfilesService.createAsrProfile(req.ctx, { name, providerId, metadata });
    return res.status(200).send(profile);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-profiles/{asrProfileId}:
   *    put:
   *      security:
   *        - Authorization: []
   *      summary: Update ASR profile
   *      description: Update ASR profile using provided data
   *      tags:
   *        - ASR profiles
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: asrProfileId
   *          in: path
   *          required: true
   *          description: ASR profile id
   *          schema:
   *            type: string
   *            example: 0973a0a7-c1f0-4c70-8c2a-3ebb3bb778ee
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                name:
   *                  type: string
   *                  example: test2
   *                providerId:
   *                  type: string
   *                  example: 02668ebe-1337-400f-98df-72ef481d12b9
   *                metadata:
   *                  type: object
   *                  example: {"speechLanguage":"en-US","dictionaryPhrases":["Telus"]}
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 21c05051-0312-4b49-8608-4afe89236847
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  providerId:
   *                    type: string
   *                    example: 02668ebe-1337-400f-98df-72ef481d12b9
   *                  name:
   *                    type: string
   *                    example: test2
   *                  metadata:
   *                    type: object
   *                    example: {"speechLanguage":"pl-PL","dictionaryPhrases":["Telus"]}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Put('/:asrProfileId')
  async updateAsrProfile(@Req() req: Request, @Res() res: Response) {
    const { asrProfileId } = req.params;
    const { metadata, name, providerId } = req.body as UpdateAsrProfileParams;
    const profile = await this.asrProfilesService.updateAsrProfile(req.ctx, asrProfileId, { metadata, name, providerId });
    return res.status(200).send(profile);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-profiles/{asrProfileId}:
   *    delete:
   *      security:
   *        - Authorization: []
   *      summary: Delete ASR profile
   *      description: Delete ASR profile
   *      tags:
   *        - ASR profiles
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: asrProfileId
   *          in: path
   *          required: true
   *          description: ASR profile id
   *          schema:
   *            type: string
   *            example: 0973a0a7-c1f0-4c70-8c2a-3ebb3bb778ee
   *      responses:
   *        204:
   *          description: No content
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   *        404:
   *          description: Not found
   */
  @Delete('/:asrProfileId')
  async deleteAsrProfile(@Req() req: Request, @Res() res: Response) {
    const { asrProfileId } = req.params;
    await this.asrProfilesService.deleteAsrProfile(req.ctx, asrProfileId);
    return res.status(204).send();
  }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-profiles/{asrProfileId}:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get ASR profile
   *      description: Get ASR profile
   *      tags:
   *        - ASR profiles
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *        - name: asrProfileId
   *          in: path
   *          required: true
   *          description: ASR profile id
   *          schema:
   *            type: string
   *            example: 0973a0a7-c1f0-4c70-8c2a-3ebb3bb778ee
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  id:
   *                    type: string
   *                    example: 21c05051-0312-4b49-8608-4afe89236847
   *                  organizationId:
   *                    type: string
   *                    example: 123e4567-e89b-12d3-a456-426614174999
   *                  providerId:
   *                    type: string
   *                    example: 02668ebe-3d55-400f-98df-72ef481d12b9
   *                  name:
   *                    type: string
   *                    example: test
   *                  metadata:
   *                    type: object
   *                    example: {"speechLanguage":"en-US","dictionaryPhrases":["Telus"]}
   *                  createdAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *                  updatedAt:
   *                    type: string
   *                    example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/:asrProfileId')
  async getAsrProfile(@Req() req: Request, @Res() res: Response) {
    const { asrProfileId } = req.params;
    const profile = await this.asrProfilesService.getAsrProfile(req.ctx, asrProfileId);
    return res.status(200).send(profile);
  }

  /**
   * @openapi
   * /orgs/{organizationId}/asr-profiles:
   *    get:
   *      security:
   *        - Authorization: []
   *      summary: Get all ASR profiles
   *      description: Get all ASR profiles
   *      tags:
   *        - ASR profiles
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      responses:
   *        200:
   *          description: Success
   *          content:
   *            application/json:
   *              schema:
   *                type: array
   *                items:
   *                  type: object
   *                  properties:
   *                    id:
   *                      type: string
   *                      example: 21c05051-0312-4b49-8608-4afe89236847
   *                    organizationId:
   *                      type: string
   *                      example: 123e4567-e89b-12d3-a456-426614174999
   *                    providerId:
   *                      type: string
   *                      example: 02668ebe-3d55-400f-98df-72ef481d12b9
   *                    name:
   *                      type: string
   *                      example: test
   *                    metadata:
   *                      type: object
   *                      example: {"speechLanguage":"en-US","dictionaryPhrases":["Telus"]}
   *                    createdAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *                    updatedAt:
   *                      type: string
   *                      example: 2024-11-22 00:00:00.000
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Get('/')
  async getAllAsrProfiles(@Req() req: Request, @Res() res: Response) {
    const { organizationId } = req.params;
    const profiles = await this.asrProfilesService.getAsrProfiles(req.ctx, organizationId);
    return res.status(200).send(profiles);
  }
}
