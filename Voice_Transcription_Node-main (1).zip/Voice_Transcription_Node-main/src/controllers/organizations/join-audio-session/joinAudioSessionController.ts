import { Controller, Post, Req, Res } from '@decorators/express';
import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';

import { CreateConnectionParams, JoinAudioSessionParams } from '../../../api/contracts';
import { InvalidOperation } from '../../../errors';
import { ConnectionService } from '../../../services/communication/connectionService';
import { AudioSessionsService } from '../../../services/sessions/audioSessionService';

@injectable()
@Controller('/orgs/:organizationId/join-audio-session', { mergeParams: true })
export class JoinAudioSessionController {
  constructor(
    @inject(AudioSessionsService) private audioSessionService: AudioSessionsService,
    @inject(ConnectionService) private connectionService: ConnectionService,
  ) { }

  /**
   * @openapi
   * /orgs/{organizationId}/join-audio-session:
   *    post:
   *      security:
   *        - Authorization: []
   *      summary: Join audio session
   *      description: Create connecton to an active session and retrieve connection details
   *      tags:
   *        - Audio sessions
   *      parameters:
   *        - name: organizationId
   *          in: path
   *          required: true
   *          description: UUID of organization
   *          schema:
   *            type: string
   *            example: 123e4567-e89b-12d3-a456-426614174999
   *      requestBody:
   *        required: true
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                audioSessionId:
   *                  type: string
   *                  example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                streamTypes:
   *                  type: array
   *                  items:
   *                    type: string
   *                    example: raw
   *                metadata:
   *                  type: object
   *                  example: {"test":"test","qwerty":[1]}
   *      responses:
   *        201:
   *          description: Created
   *          content:
   *            application/json:
   *              schema:
   *                type: object
   *                properties:
   *                  audioSessionId:
   *                    type: string
   *                    example: 2c4906ca-706e-4d88-b67e-c76610623ba5
   *                  connectionToken:
   *                    type: string
   *                    example: 1bcef26f-33a2-4144-bdf0-b10c6aafd854
   *                  streamingUrl:
   *                    type: string
   *                    example: ws://localhost:8082/orgs/123e4567-e89b-12d3-a456-426614174999/audio-stream
   *        400:
   *          description: InvalidParameter
   *        401:
   *          description: Unauthorized
   *        403:
   *          description: Forbidden
   */
  @Post('/')
  async joinAudioSession(@Req() req: Request, @Res() res: Response) {
    const { audioSessionId, streamTypes, metadata } = req.body as JoinAudioSessionParams;

    const audioSession = await this.audioSessionService.getSession(req.ctx, audioSessionId);
    if (audioSession.status != 'active') {
      throw new InvalidOperation('Session is not active');
    }

    const createParams: CreateConnectionParams = {
      audioSessionId,
      connectionType: 'consumer',
      streamTypes,
    };
    const { connection, streamingUrl } = await this.connectionService.createConnection(req.ctx, createParams);
    const { connectionToken } = connection;

    return res.status(200).send({
      audioSessionId,
      connectionToken,
      streamingUrl,
    });
  }
}
