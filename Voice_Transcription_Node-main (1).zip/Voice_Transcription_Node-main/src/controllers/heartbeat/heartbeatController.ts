import { Controller, Get, Res } from '@decorators/express';
import { Response } from 'express';
import { injectable } from 'tsyringe';

import { logger } from '../../utils/logger';

@injectable()
@Controller('/heartbeat')
export class HeartbeatController {
  constructor() { }

  /**
   * @openapi
   * /heartbeat:
   *    get:
   *      summary: Checks server heartbeat
   *      description: Checks if the server is running
   *      tags:
   *        - Heartbeat
   *      responses:
   *        200:
   *          description: Server is running
   *        
   */
  @Get('/')
  heartbeat(@Res() res: Response) {
    logger.info('Heartbeat');
    res.status(200).send();
  }
}
