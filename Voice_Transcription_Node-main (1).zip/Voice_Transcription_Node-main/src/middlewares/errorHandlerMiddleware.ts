import { NextFunction, Request, Response } from 'express';

import { Forbidden, InvalidOperation, InvalidParameter, NotFound, Unauthorized } from '../errors';
import { logger } from '../utils/logger';

export function handleErrorMiddleware(err: Error, req: Request, res: Response, next: NextFunction) {
  logger.error(err);
  if (err instanceof Unauthorized)
    return res.status(401).send(err.message);

  if (err instanceof Forbidden)
    return res.status(403).send(err.message);

  if (err instanceof NotFound)
    return res.status(404).send(err.message);

  if (err instanceof InvalidParameter)
    return res.status(400).send(err.message);

  if (err instanceof InvalidOperation)
    return res.status(400).send(err.message);

  return res.status(500).send(err.message);
}

