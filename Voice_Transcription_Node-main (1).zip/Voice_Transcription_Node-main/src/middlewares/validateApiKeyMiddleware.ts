import { NextFunction, Request, Response } from 'express';
import { container } from 'tsyringe';

import { Forbidden, Unauthorized } from '../errors';
import { handleErrorMiddleware } from './errorHandlerMiddleware';
import { ApiKeyService } from '../services/membership/apiKeyService';
import { MASTER_ORGANIZATION_ID } from '../services/membership/organizationService';

export async function validateApiKeyMiddleware(req: Request, res: Response, next: NextFunction) {
  try {
    const apiKeyService = container.resolve(ApiKeyService);
    const authKey = req.headers.authorization;
    if (!authKey) {
      req.ctx = { roles: [], hasValidApiKey: false, fromMasterOrganization: false };
      return next();
    }

    const validationResult = await apiKeyService.validateAccessToken(authKey);
    if (!validationResult.isValid) {
      throw new Unauthorized();
    }

    const userOrganizationId = validationResult.apiKey.organizationId;
    const requestedOrganizationId = req.url.substring(6, 42);
    if (userOrganizationId !== MASTER_ORGANIZATION_ID
      && requestedOrganizationId.length === 32
      && userOrganizationId !== requestedOrganizationId)
      throw new Forbidden();

    req.ctx = {
      userOrganizationId,
      requestedOrganizationId,
      roles: validationResult.apiKey.roles,
      hasValidApiKey: true,
      fromMasterOrganization: validationResult.apiKey.organizationId === MASTER_ORGANIZATION_ID,
    };
    return next();
  } catch (error) {
    return handleErrorMiddleware(error, req, res, next);
  }
}
