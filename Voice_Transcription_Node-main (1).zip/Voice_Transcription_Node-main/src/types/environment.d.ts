declare global {
  namespace NodeJS {
    interface ProcessEnv {
      POSTGRES_CONNECTION_STRING: string,
      EXPRESS_PORT: number;
      HTTP_SSL_CERT_PATH: string;
      HTTP_SSL_KEY_PATH: string;
      WS_BASE_URL: string,
      WS_PRODUCER_PORT: number,
      WS_CONSUMER_PORT: number,
      WS_SSL_CERT_PATH: string,
      WS_SSL_KEY_PATH: string,
      LOCAL_AUDIO_DIR: string,
    }
  }
}

export { };
