import { RequestContext } from '../models/requestContext';

declare global {
  namespace Express {
    interface Request {
      ctx: RequestContext,
    }
  }
}
