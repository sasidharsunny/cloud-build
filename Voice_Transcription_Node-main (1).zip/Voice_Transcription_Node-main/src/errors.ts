/**
 * Exception thrown for unauthorized requests.
 */
export class Unauthorized extends Error {
  constructor(message: string = null) {
    super(message);
    this.name = 'Unauthorized';
  }
}

/**
 * Exception thrown when user doesn't have required permissions.
 */
export class Forbidden extends Error {
  constructor(message: string = null) {
    super(message);
    this.name = 'Forbidden';
  }
}

/**
 * Exception thrown for not found requests.
 * This exception is used when trying to operate on a resource that does not exist.
 */
export class NotFound extends Error {
  constructor(message: string = null) {
    super(message);
    this.name = 'NotFound';
  }
}

/**
 * Exception thrown for invalid requests.
 * This is used when the request is invalid (bad or missing params).
 */
export class InvalidParameter extends Error {
  constructor(message: string = null) {
    super(message);
    this.name = 'InvalidParameter';
  }
}

/**
 * Exception thrown for invalid operations.
 * This is used when the operation is invalid (e.g. entity is in invalid state).
 */
export class InvalidOperation extends Error {
  constructor(message: string = null) {
    super(message);
    this.name = 'InvalidOperation';
  }
}
