import { Role } from '../db/models';

export type RequestContext = {
  hasValidApiKey: boolean,
  userOrganizationId?: string,
  requestedOrganizationId?: string,
  fromMasterOrganization: boolean,
  roles: Role[],
}
