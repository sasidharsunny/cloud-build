import 'reflect-metadata';
import { container } from 'tsyringe';

import { containerSetup } from './containerSetup';
import { initDatabase, syncDatabase } from './db/bindings';
import { AudioProducerHost } from './services/communication/audioProducerHost';
import { ExpressHost } from './services/communication/expressHost';
import { TextConsumerHost } from './services/communication/textConsumerHost';
import { AudioSessionCoordinator } from './services/sessions/audioSessionCoordinator';
import { logger } from './utils/logger';

async function main(): Promise<void> {
  logger.info('Starting application.');
  containerSetup();

  try {
    // Setup DB
    if (process.argv.includes('--sync-db')) {
      // Synchronize database schema when requested
      await syncDatabase();
    } else {
      // Otherwise just initialize the database access
      await initDatabase();
    }
  }
  catch (err) {
    // Log the error and exit
    logger.fatal(`Fatal problem with database :(\n${err}`);
    return;
  }

  // Start the streaming API if not disabled
  if (!process.argv.includes('--no-streaming-api')) {
    const audioSessionCoordinator = container.resolve(AudioSessionCoordinator);
    const audioProducerHost = container.resolve(AudioProducerHost);
    const textConsumerHost = container.resolve(TextConsumerHost);

    audioSessionCoordinator.attachToHosts(audioProducerHost, textConsumerHost);
    audioProducerHost.start({ port: process.env.WS_PRODUCER_PORT ?? 8081 });
    textConsumerHost.start({ port: process.env.WS_CONSUMER_PORT ?? 8082 });
  }

  // Start the REST API if not disabled
  if (!process.argv.includes('--no-rest-api')) {
    const expressHost = container.resolve(ExpressHost);
    await expressHost.serve();
  }
}

main();
