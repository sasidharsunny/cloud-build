import { Metadata, AudioSessionStatus, StorageType, OrganizationStatus, AudioRecordingFileFormat, VoiceTranscriptType, StreamType, ConnectionType } from '../db/models';

export type CreateAudioSessionParams = {
  asrProfileId: string;
  storageProviderId: string;
  metadata?: Metadata;
}

export type UpdateAudioSessionParams = {
  metadata?: Metadata;
  status?: AudioSessionStatus;
  statusDetails?: string;
}

export type AudioSessionStreamType = 'raw' | 'sentence';

export type JoinAudioSessionParams = {
  audioSessionId: string;
  streamTypes: AudioSessionStreamType[];
  metadata?: Metadata;
}


export type CreateStorageProviderParams = {
  name: string;
  type: StorageType;
  config: Metadata;
  metadata: Metadata;
}

export type UpdateStorageProviderParams = {
  name?: string;
  type?: StorageType;
  config?: Metadata;
  metadata?: Metadata;
}


export type CreateOrganizationParams = {
  name: string;
  metadata?: Metadata;
  status?: OrganizationStatus; // inactive by default
}

export type UpdateOrganizationParams = {
  name?: string;
  metadata?: Metadata;
  status?: OrganizationStatus;
}


export type CreateAsrProviderParams = {
  name: string;
  type: string;
  config: Metadata;
  metadata?: Metadata;
}

export type UpdateAsrProviderParams = {
  name?: string;
  metadata?: Metadata;
}


export type CreateAsrProfileParams = {
  name: string;
  providerId: string;
  metadata?: Metadata;
}

export type UpdateAsrProfileParams = {
  name?: string;
  providerId?: string;
  metadata?: Metadata;
}


export type CreateAudioRecordingParams = {
  audioSessionId: string;
  storageId: string;
  storageUrl: string;
  fileName: string;
  fileFormat: AudioRecordingFileFormat;
  metadata?: Metadata;
}

export type UpdateAudioRecordingParams = {
  metadata?: Metadata;
}


export type CreateTranscriptParams = {
  audioSessionId: string;
  organizationId: string;
  type: VoiceTranscriptType;
  typeDetails: string;
  text: string;
  metadata?: Metadata;
}

export type UpdateTranscriptParams = {
  metadata: Metadata;
}


export type CreateConnectionParams = {
  audioSessionId: string;
  connectionType: ConnectionType;
  streamTypes?: StreamType[];
}


export type CreateTranscriptionChunk = {
  voiceTranscriptId: string;
  ordinal: number;
  sessionId: string;
  transcribedText: string;
  audioPositionFrom?: number;
  audioPositionTo?: number;
  metadata?: Metadata;
}
