## **Connection API Endpoints**

The Connection API endpoints manage real-time connections related to transcription sessions.

### **Base Path:**

All endpoints for managing connections are prefixed with `/orgs/{organizationId}` to include tenant identifier.

---

### **1. Create Audio Session**

**Endpoint:** `POST /orgs/{organizationId}/create-audio-session`

**Description:** Allows an audio producer client to create a new connection and initialize a live transcription session.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Request Body:**

- **asrProfileId** (UUID, required): Identifier of the ASR profile to be used for the session.
- **audioFormat** (string, required): Specifies the audio format for the session (e.g., `PCM`, `MP3`).
- **metadata** (JSON, optional): Additional session-specific metadata (e.g., sample rate, channels, incoming phone number, customer ID).

**Request Example:**

```json
{
  "asrProfileId": "123e4567-e89b-12d3-a456-426614174888",
  "audioFormat": "PCM",
  "metadata": {
    "sampleRate": 16000,
    "channels": 1,
    "incomingPhoneNumber": "+1234567890",
    "customerId": "CUST-78910",
  }
}
```

**Response:**

- **201 Created** Returns the connection details, including the session ID and connection parameters.

**Response Example:**

```json
{
  "audioSessionId": "123e4567-e89b-12d3-a456-426614174111",
  "streamingUrl": "wss://node12-vtn.example.com/orgs/{organizationId}/audio-stream",
  "connectionToken": "abcd1234efgh5678ijkl9012mnop3456",
}
```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to create audio sessions or access the organization.

---

### **2. Join Audio Session**

**Endpoint:**  
`POST /orgs/{organizationId}/connect/join-audio-session`

**Description:**  
Allows a text consumer client to join an existing live transcription session.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Request Body:**

- **audioSessionId** (UUID, required): Identifier of the existing audio session to join.
- **streamTypes** (string[], required): List of stream types to subscribe to (e.g., `raw`, `sentence`).
- **metadata** (JSON, optional): Additional information about the consumer (e.g., user ID, role).

**Request Example:**

```json
{
  "audioSessionId": "123e4567-e89b-12d3-a456-426614174111",
  "streamTypes": ["raw", "sentence"],
  "metadata": {
    "serviceInstance": "summarizator-5678",
    "purpose": "summarization"
  }
}
```

**Response:**

- **200 OK** Returns the connection details for the consumer.

**Response Example:**

```json
{
  "audioSessionId": "123e4567-e89b-12d3-a456-426614174111",
  "connectionToken": "abcd1234efgh5678ijkl9012mnop3456",
  "streamingUrl": "wss://node12-vtn.example.com/orgs/{organizationId}/text-stream",
}
```

---
