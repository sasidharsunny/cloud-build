# Overview

This binary format is a compact, efficient protocol for streaming audio and text
over WebSockets, supporting authentication, ordered, timestamped data chunks,
and extensibility for real-time applications.

# General Message Format

Each message begins with a fixed header:

- **Message Type** (4 bytes): A four-letter mnemonic (ASCII encoded).
- **Message Length** (4 bytes, unsigned, big-endian): Indicates the length of
  the message payload in bytes (excluding the header).

---

# Definition of Message Types

## Audio Providing Client Messages

These are the message types used in communication between audio providing client
and streaming endpoint over WebSocket.

### Client-to-Server Message Types

#### 1. Authentication Message

The client sends this as the first message after establishing the connection.

| Field                   | Size     | Description                       |
| ----------------------- | -------- | --------------------------------- |
| Message Type            | 4 bytes  | `"AUTH"` (Authentication message) |
| Message Length          | 4 bytes  | Total length of the payload       |
| Connection Token Length | 2 bytes  | Length of the connection token    |
| Connection Token        | Variable | UTF-8 encoded token string        |
| Session ID Length       | 2 bytes  | Length of the session ID          |
| Session ID              | Variable | UTF-8 encoded session ID string   |

**Example Binary Layout**:

```
["AUTH"][Payload Length: 4 bytes][Token Length: 2 bytes][Token: N bytes][Session ID Length: 2 bytes][Session ID: M bytes]
```

---

#### 2. Audio Data Chunk

The client sends this message repeatedly to provide audio data.

| Field          | Size     | Description                                |
| -------------- | -------- | ------------------------------------------ |
| Message Type   | 4 bytes  | `"AUDC"` (Audio Data Chunk)                |
| Message Length | 4 bytes  | Total length of the payload                |
| Chunk Sequence | 4 bytes  | Sequential number for ordering             |
| Timestamp      | 8 bytes  | UTC timestamp in milliseconds (big-endian) |
| Audio Data     | Variable | Binary audio data                          |

**Example Binary Layout**:

```
["AUDC"][Payload Length: 4 bytes][Chunk Sequence: 4 bytes][Timestamp: 8 bytes][Audio Data: N bytes]
```

---

#### 3. End Audio Message

The client sends this as the last message in the session.

| Field          | Size    | Description                        |
| -------------- | ------- | ---------------------------------- |
| Message Type   | 4 bytes | `"ENDT"` (End audio message)       |
| Message Length | 4 bytes | Always `0` (no additional payload) |

**Example Binary Layout**:

```
["ENDT"][Payload Length: 4 bytes (always 0)]
```

---

### Server-to-Client Message Types

#### 1. Acknowledgement Message

The server sends this message to acknowledge receipt of an audio chunk.

| Field          | Size    | Description                                                            |
| -------------- | ------- | ---------------------------------------------------------------------- |
| Message Type   | 4 bytes | `"ACKN"` (Acknowledgement message)                                     |
| Message Length | 4 bytes | Always `12` (fixed payload size)                                       |
| Chunk Sequence | 4 bytes | Sequence number of the acknowledged chunk                              |
| Timestamp      | 8 bytes | Timestamp of the acknowledged chunk (copied from the received message) |

**Example Binary Layout**:

```
["ACKN"][Payload Length: 4 bytes (always 12)][Chunk Sequence: 4 bytes][Timestamp: 8 bytes]
```

---

#### 2. Authentication success

The server sends this message to confirm that authentication was successfull.

| Field          | Size    | Description                        |
| -------------- | ------- | ---------------------------------- |
| Message Type   | 4 bytes | `"SUCC"` (Authentication success)  |
| Message Length | 4 bytes | Always `0` (no additional payload) |

**Example Binary Layout**:

```
["SUCC"][Payload Length: 4 bytes (always 0)]
```

---

#### 3. Authentication fail

The server sends this message to reject the authentication attempt.

| Field          | Size    | Description                        |
| -------------- | ------- | ---------------------------------- |
| Message Type   | 4 bytes | `"FAIL"` (Authentication failed)   |
| Message Length | 4 bytes | Always `0` (no additional payload) |

**Example Binary Layout**:

```
["FAIL"][Payload Length: 4 bytes (always 0)]
```

---

### Example Communication Flow

#### Client Side

1. Send an **Authentication Message**:
   - Token: `"abcd1234"`
   - Session ID: `"session-01"`

   ```plaintext
   ["AUTH"][00 00 00 14][00 08][abcd1234][00 0A][session-01]
   ```

---

#### Server Side

2. Send an **Authentication success Message**:

   ```plaintext
   ["SUCC"][00 00 00 00]
   ```

---

#### Client Side

3. Send an **Audio Data Chunk**:
   - Sequence: `1`
   - Timestamp: `1699991234567`
   - Audio Data: Binary content `[0xAA, 0xBB, 0xCC]`

   ```plaintext
   ["AUDC"][00 00 00 0F][00 00 00 01][00 00 01 89 45 5B 23 67][AA BB CC]
   ```

---

#### Server Side

4. Send an **Acknowledgement Message**:
   - Sequence: `1`
   - Timestamp: `1699991234567`

   ```plaintext
   ["ACKN"][00 00 00 0C][00 00 00 01][00 00 01 89 45 5B 23 67]
   ```

---

5. Send an **End Audio Message**:

   ```plaintext
   ["ENDT"][00 00 00 00]
   ```

## Text Consuming Client Messages

### Client-to-Server Message Types

#### 1. Authentication Message

The client sends this as the first message after establishing the connection.

| Field                   | Size     | Description                       |
| ----------------------- | -------- | --------------------------------- |
| Message Type            | 4 bytes  | `"AUTH"` (Authentication message) |
| Message Length          | 4 bytes  | Total length of the payload       |
| Connection Token Length | 2 bytes  | Length of the connection token    |
| Connection Token        | Variable | UTF-8 encoded token string        |
| Session ID Length       | 2 bytes  | Length of the session ID          |
| Session ID              | Variable | UTF-8 encoded session ID string   |

**Example Binary Layout**:

```
["AUTH"][Payload Length: 4 bytes][Token Length: 2 bytes][Token: N bytes][Session ID Length: 2 bytes][Session ID: M bytes]
```

---

### Server-to-Client Message Types

#### 1. Text Data Chunk

The server sends this message continuously to deliver text data to the client.

| Field          | Size     | Description                                           |
| -------------- | -------- | ----------------------------------------------------- |
| Message Type   | 4 bytes  | `RTXT` for raw text chunk or `STXT` for full sentence |
| Message Length | 4 bytes  | Total length of the payload                           |
| Chunk Sequence | 4 bytes  | Sequential number for ordering                        |
| Timestamp      | 8 bytes  | UTC timestamp in milliseconds (big-endian)            |
| Text Length    | 4 bytes  | Length of the UTF-8 encoded text                      |
| Text Data      | Variable | UTF-8 encoded text                                    |

**Example Binary Layout**

```javascript
["RTXT"][Payload Length: 4 bytes][Chunk Sequence: 4 bytes][Timestamp: 8 bytes][Text Length: 4 bytes][Text Data: N bytes]
```

---

#### 2. Authentication success

The server sends this message to confirm that authentication was successfull.

| Field          | Size    | Description                        |
| -------------- | ------- | ---------------------------------- |
| Message Type   | 4 bytes | `"SUCC"` (Authentication success)  |
| Message Length | 4 bytes | Always `0` (no additional payload) |

**Example Binary Layout**:

```
["SUCC"][Payload Length: 4 bytes (always 0)]
```

---

#### 3. Authentication fail

The server sends this message to reject the authentication attempt.

| Field          | Size    | Description                        |
| -------------- | ------- | ---------------------------------- |
| Message Type   | 4 bytes | `"FAIL"` (Authentication failed)   |
| Message Length | 4 bytes | Always `0` (no additional payload) |

**Example Binary Layout**:

```
["FAIL"][Payload Length: 4 bytes (always 0)]
```

---

### Example Communication Flow

#### Client Side

1. Send an **Authentication Message**:
   - Token: `"my-secure-token"`
   - Session ID: `"text-session-001"`

   ```javascript
   ["AUTH"][00 00 00 24][00 10]["my-secure-token"][00 0F]["text-session-001"]
   ```

---

#### Server Side

2. Send an **Authentication success Message**:

   ```plaintext
   ["SUCC"][00 00 00 00]
   ```

---

3. Send a **Text Data Chunk**:
   - Type: Sentence text (`STXT`)
   - Chunk Sequence: `1`
   - Timestamp: `1699991234567`
   - Text: `"Hello, world!"`

   ```plaintext
   ["STXT"][00 00 00 19][00 00 00 01][00 00 01 89 45 5B 23 67][00 00 00 0D]["Hello, world!"]
   ```

---
