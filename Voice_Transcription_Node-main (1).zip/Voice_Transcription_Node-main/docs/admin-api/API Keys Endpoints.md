## **API Key Endpoints**

The API Key endpoints handle the creation, retrieval, updating, and revoking of API keys for organizations. API keys facilitate secure access control and permissions for various system functionalities for external services.

### **Base URL**

All endpoints for managing API keys are prefixed with `/orgs/{organizationId}/api-keys`.

### **Required Roles**

- **create-api-keys**: Required to create a new API key.
- **modify-api-keys**: Required to update an existing API key.
- **view-api-keys**: Required to retrieve API key details.
- **revoke-api-keys**: Required to revoke an API key.

---

### **1. Get All API Keys**

**Endpoint:** `GET /orgs/{organizationId}/api-keys`

**Required Role:** `view-api-keys`

**Description:** Fetches a list of all API keys associated with the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Response:**

- **200 OK** Returns a list of API keys.

  ```json
  [
    {
      "key": "abcd1234efgh5678ijkl9012mnop3456",
      "organizationId": "123e4567-e89b-12d3-a456-426614174999",
      "status": "active",
      "roles": ["create-sessions", "join-sessions"],
      "createdAt": "2024-01-10T09:00:00Z",
      "updatedAt": "2024-01-15T10:00:00Z"
    },
    ...
  ]
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to view API keys or access to the organization.

---

### **2. Create a New API Key**

**Endpoint:** `POST /orgs/{organizationId}/api-keys`

**Required Role:** `create-api-keys`

**Description:** Creates a new API key for the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Request Body:**

- **roles** (string[], required): List of roles or permissions associated with the API key (e.g., `create-sessions`).

**Example Request:**

```json
{
  "roles": ["create-sessions"],
}
```

**Response:**

- **201 Created** Returns the newly created API key object.

  ```json
  {
    "key": "abcd1234efgh5678ijkl9012mnop3456",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "status": "active",
    "roles": ["create-sessions"],
    "createdAt": "2024-01-15T10:00:00Z",
    "updatedAt": "2024-01-15T10:00:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to create API keys or access to the organization.

---

### **3. Get an API Key by Key**

**Endpoint:** `GET /orgs/{organizationId}/api-keys/{apiKey}`

**Required Role:** `view-api-keys`

**Description:** Fetches details of a specific API key by its key value.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **apiKey** (string, required): Unique value of the API key.

**Response:**

- **200 OK** Returns the API key details.

  ```json
  {
    "key": "abcd1234efgh5678ijkl9012mnop3456",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "status": "active",
    "roles": ["create-sessions", "join-sessions"],
    "createdAt": "2024-01-15T10:00:00Z",
    "updatedAt": "2024-01-15T10:00:00Z"
  }
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to view API keys or access to the organization.
- **404 Not Found** API key with the specified key value does not exist.

---

### **4. Update an API Key**

**Endpoint:** `PUT /orgs/{organizationId}/api-keys/{apiKey}`

**Required Role:** `modify-api-keys`

**Description:** Updates roles assigned to an existing API key.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **apiKey** (string, required): Unique value of the API key.

**Request Body:**

- **roles** (string[], optional): Updated list of roles for the API key.

**Example Request:**

```json
{
  "roles": ["create-sessions", "join-sessions", "view-sessions"],
}
```

**Response:**

- **200 OK** Returns the updated API key details.

  ```json
  {
    "key": "abcd1234efgh5678ijkl9012mnop3456",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "status": "revoked",
    "roles": ["create-sessions", "join-sessions", "view-sessions"],
    "createdAt": "2024-01-15T10:00:00Z",
    "updatedAt": "2024-02-01T12:00:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to modify API keys or access to the organization.
- **404 Not Found** API key with the specified key value does not exist.

---

### **5. Revoke an API Key**

**Endpoint:** `DELETE /orgs/{organizationId}/api-keys/{apiKey}`

**Required Role:** `remove-api-keys`

**Description:** Revokes an API key associated with the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **apiKey** (string, required): Unique value of the API key.

**Response:**

- **204 No Content** API key successfully revoked. No response body.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to revoke API keys or access to the organization.
- **404 Not Found** API key with the specified key value does not exist.

---
