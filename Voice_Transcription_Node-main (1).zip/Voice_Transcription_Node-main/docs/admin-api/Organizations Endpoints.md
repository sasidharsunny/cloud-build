## Organization Endpoints

The Organization endpoints handle basic operations for managing organizations (tenants) in the system. These operations allow creating, retrieving and updating organization data.

### **Master Organization**

There's a special organization with the ID `00000000-0000-0000-0000-000000000000` that represents the master organization. This organization cannot be deleted. Only users of the master organization can create or modify other organizations. Users of the master organization have also access to all resources of other organizations in the system, but only within the scope of their assigned roles.

### **Base URL**

All endpoints for organizations are prefixed with `/orgs`.

### **Required Roles**

- **create-orgs**: Required to create a new organization.
- **modify-orgs**: Required to update an existing organization.
- **view-orgs**: Required to retrieve organization details.

---

### **1. Get All Organizations**

**Endpoint:** `GET /orgs`

**Required role**: `view-orgs`

**Description:** Fetches a list of all organizations in the system.

**Response:**

- **200 OK** Returns a list of organizations.

  ```json
  [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "name": "Organization A",
      "status": "active",
      "createdAt": "2023-01-15T10:00:00Z",
      "updatedAt": "2023-02-20T12:30:00Z",
      "metadata": {
        "customField1": "value"
      }
    },
    ...
  ]
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to view organizations or is not part of the master organization.

---

### **2. Create a New Organization**

**Endpoint:** `POST /orgs`

**Required role**: `create-orgs`

**Description:** Creates a new organization.

**Request Body:**

- **name** (string, required): Name of the organization.
- **metadata** (JSON, optional): Additional metadata or configuration settings.

**Example Request:**

```json
{
  "name": "New Organization",
  "metadata": {
    "industry": "Technology",
    "region": "North America"
  }
}
```

**Response:**

- **201 Created** Returns the newly created organization object.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174001",
    "name": "New Organization",
    "status": "active",
    "createdAt": "2024-01-15T10:00:00Z",
    "updatedAt": "2024-01-15T10:00:00Z",
    "metadata": {
      "industry": "Technology",
      "region": "North America"
    }
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to create organizations or is not part of the master organization.

---

### **3. Get an Organization by ID**

**Endpoint:** `GET /orgs/{organizationId}`

**Required role**: `view-orgs`

**Description:** Fetches details of a specific organization by its unique ID.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Response:**

- **200 OK** Returns the organization details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "name": "Organization A",
    "status": "active",
    "createdAt": "2023-01-15T10:00:00Z",
    "updatedAt": "2023-02-20T12:30:00Z",
    "metadata": {
      "customField1": "value"
    }
  }
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to view organizations or is not part of the master organization.
- **404 Not Found** Organization with the given ID not found.

---

### **4. Update an Organization**

**Endpoint:** `PUT /orgs/{organizationId}`

**Required role**: `modify-orgs`

**Description:** Updates the details of an existing organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Request Body:**

- **name** (string, optional): Updated name of the organization.
- **status** (enum, optional): Updated status (`active` or `inactive`).
- **metadata** (JSON, optional): Updated metadata.

**Example Request:**

```json
{
  "name": "Updated Organization Name",
  "status": "inactive",
  "metadata": {
    "customField1": "newValue"
  }
}
```

**Response:**

- **200 OK** Returns the updated organization details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "name": "Updated Organization Name",
    "status": "inactive",
    "createdAt": "2023-01-15T10:00:00Z",
    "updatedAt": "2024-01-20T08:00:00Z",
    "metadata": {
      "customField1": "newValue"
    }
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to modify organizations or is not part of the master organization.
- **404 Not Found** Organization with the given ID not found.

---
