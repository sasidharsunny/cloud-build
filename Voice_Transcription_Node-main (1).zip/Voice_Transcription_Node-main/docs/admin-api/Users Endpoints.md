## **Users Endpoints**

The Users endpoints handle basic operations for managing users within a specific organization. Access to these endpoints requires specific roles for authorization to ensure proper user-level access control.

### **Base URL**

All endpoints for managing users are prefixed with `/orgs/{organizationId}/users`.

### **Required Roles**

- **create-users**: Required to create a new user.
- **modify-users**: Required to update an existing user.
- **view-users**: Required to retrieve user details.
- **remove-users**: Required to delete a user.

---

### **1. Get All Users**

**Endpoint:** `GET /orgs/{organizationId}/users`

**Required Role:** `view-users`

**Description:** Fetches a list of all users within a specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Response:**

- **200 OK** Returns a list of users.

  ```json
  [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "organizationId": "123e4567-e89b-12d3-a456-426614174999",
      "name": "John Doe",
      "roles": ["admin"],
      "status": "active",
      "createdAt": "2023-01-15T10:00:00Z",
      "updatedAt": "2023-02-20T12:30:00Z",
      "metadata": {
        "department": "Sales"
      }
    },
    ...
  ]
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to view users or access to the organization.
- **4xx/5xx** Error response with a relevant status code and message.

---

### **2. Create a New User**

**Endpoint:** `POST /orgs/{organizationId}/users`

**Required Role:** `create-users`

**Description:** Creates a new user within the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Request Body:**

- **name** (string, required): Name of the user.
- **roles** (string[], required): List of roles assigned to the user (e.g., `admin`, `viewer`).
- **status** (enum, optional): Status of the user (e.g., `active`, `inactive`).
- **metadata** (JSON, optional): Additional metadata or settings specific to the user.

**Example Request:**

```json
{
  "name": "Jane Smith",
  "roles": ["viewer"],
  "status": "active",
  "metadata": {
    "location": "NYC Office"
  }
}
```

**Response:**

- **201 Created** Returns the newly created user object.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174001",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Jane Smith",
    "roles": ["viewer"],
    "status": "active",
    "createdAt": "2024-01-15T10:00:00Z",
    "updatedAt": "2024-01-15T10:00:00Z",
    "metadata": {
      "location": "NYC Office"
    }
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to create users or access to the organization.

---

### **3. Get a User by ID**

**Endpoint:** `GET /orgs/{organizationId}/users/{userId}`

**Required Role:** `view-users`

**Description:** Fetches details of a specific user by their unique ID.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **userId** (UUID, required): Unique identifier of the user.

**Response:**

- **200 OK** Returns the user details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "John Doe",
    "roles": ["admin"],
    "status": "active",
    "createdAt": "2023-01-15T10:00:00Z",
    "updatedAt": "2023-02-20T12:30:00Z",
    "metadata": {
      "department": "Sales"
    }
  }
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to view users or access to the organization.
- **404 Not Found** User with the given ID not found.

---

### **4. Update a User**

**Endpoint:** `PUT /orgs/{organizationId}/users/{userId}`

**Required Role:** `modify-users`

**Description:** Updates details of an existing user within the organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **userId** (UUID, required): Unique identifier of the user.

**Request Body:**

- **name** (string, optional): Updated name of the user.
- **roles** (string[], optional): Updated roles assigned to the user.
- **status** (enum, optional): Updated status (e.g., `active`, `inactive`).
- **metadata** (JSON, optional): Updated metadata for the user.

**Example Request:**

```json
{
  "name": "John Doe Updated",
  "roles": ["admin", "editor"],
  "status": "active",
  "metadata": {
    "department": "Marketing"
  }
}
```

**Response:**

- **200 OK** Returns the updated user details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "John Doe Updated",
    "roles": ["admin", "editor"],
    "status": "active",
    "createdAt": "2023-01-15T10:00:00Z",
    "updatedAt": "2024-01-20T08:00:00Z",
    "metadata": {
      "department": "Marketing"
    }
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to modify users or access to the organization.
- **404 Not Found** User with the given ID not found.

---

### **5. Delete a User**

**Endpoint:** `DELETE /orgs/{organizationId}/users/{userId}`

**Required Role:** `remove-users`

**Description:** Deletes a user from the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **userId** (UUID, required): Unique identifier of the user.

**Response:**

- **204 No Content** User successfully deleted. No response body.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to remove users or access to the organization.
- **404 Not Found** User with the given ID not found.

---
