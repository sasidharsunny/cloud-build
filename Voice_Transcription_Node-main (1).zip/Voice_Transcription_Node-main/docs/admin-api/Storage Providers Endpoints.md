## **Storage Providers Endpoints**

The Storage Providers endpoints allow for basic operations on storage resources
associated with organizations. Storage configurations are used to manage where
audio recordings are stored (e.g., S3 buckets).

### **Base URL**

All endpoints for managing storage are prefixed with
`/orgs/{organizationId}/storage-providers`.

### **Required Roles**

- **create-storage-providers**: Required to create a new storage resource.
- **modify-storage-providers**: Required to update an existing storage resource.
- **view-storage-providers**: Required to retrieve storage details.
- **remove-storage-providers**: Required to delete a storage resource.

---

### **1. Get All Storage Providers**

**Endpoint:** `GET /orgs/{organizationId}/storage-providers`

**Required Role:** `view-storage-providers`

**Description:** Fetches a list of all storage resources associated with the
specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Response:**

- **200 OK** Returns a list of storage resources.

  ```json
  [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "organizationId": "123e4567-e89b-12d3-a456-426614174999",
      "name": "Primary Storage",
      "type": "S3",
      "config":{
        "accessKeyId": "ACCESS_KEY_ID",
        "secretAccessKey": "SECRET_ACCESS_KEY",
        "region": "us-east-1",
        "bucket": "BUCKET_NAME",
        "rootDirectory":"./test/"
      },
      "metadata": {
        "customValue": "value"
      },
      "createdAt": "2024-01-10T09:00:00Z",
      "updatedAt": "2024-01-15T10:00:00Z"
    },
    ...
  ]
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view storage
  providers or access to the organization.

---

### **2. Create a New Storage Provider**

**Endpoint:** `POST /orgs/{organizationId}/storage-providers`

**Required Role:** `create-storage-providers`

**Description:** Creates a new storage resource for the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Request Body:**

- **name** (string, required): Name of the storage resource.
- **type** (string, required): Type of storage (e.g., `S3`, `local disk`).
- **metadata** (JSON, optional): Additional metadata for configuring the storage
  resource (e.g., bucket name, region, access keys).

**Example Request:**

```json
{
  "name": "Backup Storage",
  "type": "S3",
  "config": {
    "accessKeyId": "ACCESS_KEY_ID",
    "secretAccessKey": "SECRET_ACCESS_KEY",
    "region": "us-east-1",
    "bucket": "BACKUP_BUCKET_NAME",
    "rootDirectory": "./test/"
  },
  "metadata": {
    "bucketName": "backup-audio-bucket",
    "region": "us-east-1",
    "accessKey": "ABCD1234EFGH5678"
  }
}
```

**Response:**

- **201 Created** Returns the newly created storage resource object.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Primary Storage",
    "type": "S3",
    "config": {
      "accessKeyId": "ACCESS_KEY_ID",
      "secretAccessKey": "SECRET_ACCESS_KEY",
      "region": "us-east-1",
      "bucket": "BUCKET_NAME",
      "rootDirectory": "./test/"
    },
    "metadata": {
      "customValue": "value"
    },
    "createdAt": "2024-01-10T09:00:00Z",
    "updatedAt": "2024-01-15T10:00:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to create storage
  providers or access to the organization.
- **4xx/5xx** Error response with a relevant status code and message.

---

### **3. Get a Storage Provider by ID**

**Endpoint:** `GET /orgs/{organizationId}/storage-providers/{storageId}`

**Required Role:** `view-storage-providers`

**Description:** Fetches details of a specific storage resource.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **storageId** (UUID, required): Unique identifier of the storage resource.

**Response:**

- **200 OK** Returns the storage resource details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Primary Storage",
    "type": "S3",
    "config": {
      "accessKeyId": "ACCESS_KEY_ID",
      "secretAccessKey": "SECRET_ACCESS_KEY",
      "region": "us-east-1",
      "bucket": "BUCKET_NAME",
      "rootDirectory": "./test/"
    },
    "metadata": {
      "customValue": "value"
    },
    "createdAt": "2024-01-10T09:00:00Z",
    "updatedAt": "2024-01-15T10:00:00Z"
  }
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view storage
  providers or access to the organization.
- **404 Not Found** If the storage provider with the specified ID is not found.

---

### **4. Update a Storage Provider**

**Endpoint:** `PUT /orgs/{organizationId}/storage-providers/{storageId}`

**Required Role:** `modify-storage-providers`

**Description:** Updates details of an existing storage resource.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **storageId** (UUID, required): Unique identifier of the storage resource.

**Request Body:**

- **name** (string, optional): Updated name of the storage resource.
- **type** (string, optional): Updated type of the storage resource.
- **metadata** (JSON, optional): Updated metadata related to the storage
  configuration (e.g., new bucket name, region).

**Example Request:**

```json
{
  "name": "Updated Storage Name",
  "config": {
    "accessKeyId": "ACCESS_KEY_ID",
    "secretAccessKey": "SECRET_ACCESS_KEY",
    "region": "us-east-1",
    "bucket": "BUCKET_NAME",
    "rootDirectory": "./test/"
  },
  "metadata": {
    "bucketName": "new-audio-bucket",
    "region": "eu-central-1"
  }
}
```

**Response:**

- **200 OK** Returns the updated storage resource details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Primary Storage",
    "type": "S3",
    "config": {
      "accessKeyId": "ACCESS_KEY_ID",
      "secretAccessKey": "SECRET_ACCESS_KEY",
      "region": "us-east-1",
      "bucket": "BUCKET_NAME",
      "rootDirectory": "./test/"
    },
    "metadata": {
      "customValue": "value"
    },
    "createdAt": "2024-01-10T09:00:00Z",
    "updatedAt": "2024-01-15T10:00:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to modify storage
  providers or access to the organization.
- **404 Not Found** If the storage provider with the specified ID is not found.

---

### **5. Delete a Storage Provider**

**Endpoint:** `DELETE /orgs/{organizationId}/storage-providers/{storageId}`

**Required Role:** `remove-storage-providers`

**Description:** Deletes a storage resource from the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **storageId** (UUID, required): Unique identifier of the storage resource.

**Response:**

- **204 No Content** Storage resource successfully deleted. No response body.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to remove storage
  providers or access to the organization.
- **404 Not Found** If the storage provider with the specified ID is not found.

---
