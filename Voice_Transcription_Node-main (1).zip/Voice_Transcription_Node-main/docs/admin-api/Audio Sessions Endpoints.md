## **Audio Session Endpoints**

The Audio Session endpoints manage audio transcription sessions, including
session retrieval, updating, and deletion. Audio sessions facilitate real-time
transcription and are a core part of the system.

Creation of Audio Sessions is handled by Connection API endpoints and is not
covered in this document.

### **Base URL**

All endpoints for managing audio sessions are prefixed with
`/orgs/{organizationId}/audio-sessions`.

### **Required Roles**

- **modify-sessions**: Required to update an existing audio session.
- **view-sessions**: Required to retrieve audio session details.
- **remove-sessions**: Required to delete an audio session.

---

### **1. Get All Audio Sessions**

**Endpoint:** `GET /orgs/{organizationId}/audio-sessions`

**Required Role:** `view-sessions`

**Description:** Fetches a list of all audio sessions for the specified
organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Response:**

- **200 OK** Returns a list of audio sessions.

  ```json
  [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "organizationId": "123e4567-e89b-12d3-a456-426614174999",
      "status": "active",
      "statusDetails":"",
      "usedAsrProfile":"2c4906ca-706e-4d88-b67e-c76610623ba5",
      "storageProvider": "Session in progress",
      "metadata": {
        "language": "en-US"
      },
      "createdAt": "2024-01-10T09:00:00Z",
      "endedAt": null
    },
    ...
  ]
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view audio
  sessions or access to the organization.
- **404 Not Found** Audio session with the given ID not found.

---

### **2. Get an Audio Session by ID**

**Endpoint:** `GET /orgs/{organizationId}/audio-sessions/{audioSessionId}`

**Required Role:** `view-sessions`

**Description:** Fetches details of a specific audio session by its unique ID.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.

**Response:**

- **200 OK** Returns the audio session details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "status": "active",
    "statusDetails": "",
    "usedAsrProfile": "2c4906ca-706e-4d88-b67e-c76610623ba5",
    "storageProvider": "Session in progress",
    "metadata": {
      "language": "en-US"
    },
    "createdAt": "2024-01-10T09:00:00Z",
    "endedAt": null
  }
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view audio
  sessions or access to the organization.
- **404 Not Found** Audio session with the given ID not found.

---

### **3. Update an Audio Session**

**Endpoint:** `PUT /orgs/{organizationId}/audio-sessions/{audioSessionId}`

**Required Role:** `modify-sessions`

**Description:** Updates the details of an existing audio session.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.

**Request Body:**

- **status** (enum, optional): Updated status of the session (e.g., `active`,
  `closed`).
- **metadata** (JSON, optional): Updated metadata related to the session.
- **statusDetails** (string, optional): Updated information about the session's
  status.

**Example Request:**

```json
{
  "status": "closed",
  "metadata": {
    "language": "en-US",
    "notes": "Session completed"
  },
  "statusDetails": "Session closed by user"
}
```

**Response:**

- **200 OK** Returns the updated audio session details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "status": "closed",
    "statusDetails": "Session closed by user",
    "usedAsrProfile": "2c4906ca-706e-4d88-b67e-c76610623ba5",
    "storageProvider": "Session in progress",
    "metadata": {
      "language": "en-US",
      "notes": "Session completed"
    },
    "createdAt": "2024-01-10T09:00:00Z",
    "endedAt": null
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to modify audio
  sessions or access to the organization.
- **404 Not Found** Audio session with the given ID not found.
- **4xx/5xx** Error response with a relevant status code and message.

---

### **4. Delete an Audio Session**

**Endpoint:** `DELETE /orgs/{organizationId}/audio-sessions/{audioSessionId}`

**Required Role:** `remove-sessions`

**Description:** Deletes an audio session by its unique ID.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.

**Response:**

- **204 No Content** Audio session successfully deleted. No response body.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to remove audio
  sessions or access to the organization.
- **404 Not Found** Audio session with the given ID not found.
- **4xx/5xx** Error response with a relevant status code and message.

---

## **Audio Recordings Endpoints**

The Audio Recording endpoints manage audio recordings associated with specific
audio sessions. These endpoints facilitate basic operations for handling audio
files related to audio sessions.

For Stage 1 all audio recordings are automatically generated after an audio
session is completed and cannot be created by this API.

### **Base URL**

All endpoints for managing audio recordings are prefixed with
`/orgs/{organizationId}/audio-sessions/{audioSessionId}/recordings`.

### **Required Roles**

- **modify-recordings**: Required to update an existing audio recording.
- **view-recordings**: Required to retrieve audio recording details.
- **remove-recordings**: Required to delete an audio recording.

---

### **1. Get All Audio Recordings for a Session**

**Endpoint:**
`GET /orgs/{organizationId}/audio-sessions/{audioSessionId}/recordings`

**Required Role:** `view-recordings`

**Description:** Fetches a list of all audio recordings associated with a
specific audio session.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.

**Response:**

- **200 OK** Returns a list of audio recordings.

  ```json
  [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "organizationId": "123e4567-e89b-12d3-a456-426614174999",
      "audioSessionId": "123e4567-e89b-12d3-a456-426614174111",
      "fileName": "recording1.wav",
      "fileFormat": "WAV",
      "storageId": "123e4567-e89b-12d3-a456-426614174888",
      "storageUrl": "https://storage.example.com/recording1.wav",
      "metadata": {
        "duration": "5m30s"
      },
      "createdAt": "2024-01-15T12:00:00Z"
    },
    ...
  ]
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view audio
  recordings or access to the organization.
- **404 Not Found** Audio session with the given ID not found.

---

### **2. Get an Audio Recording by ID**

**Endpoint:**
`GET /orgs/{organizationId}/audio-sessions/{audioSessionId}/recordings/{audioRecordingId}`

**Required Role:** `view-recordings`

**Description:** Fetches details of a specific audio recording.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.
- **audioRecordingId** (UUID, required): Unique identifier of the audio
  recording.

**Response:**

- **200 OK** Returns the audio recording details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "audioSessionId": "123e4567-e89b-12d3-a456-426614174111",
    "fileName": "recording1.wav",
    "fileFormat": "WAV",
    "storageId": "123e4567-e89b-12d3-a456-426614174888",
    "storageUrl": "https://storage.example.com/recording1.wav",
    "metadata": {
      "duration": "5m30s"
    },
    "createdAt": "2024-01-15T12:00:00Z"
  }
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view audio
  recordings or access to the organization.
- **404 Not Found** Audio recording or audio session with the given ID not
  found.

---

### **3. Update an Audio Recording**

**Endpoint:**
`PUT /orgs/{organizationId}/audio-sessions/{audioSessionId}/recordings/{audioRecordingId}`

**Required Role:** `modify-recordings`

**Description:** Updates details of an existing audio recording.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.
- **audioRecordingId** (UUID, required): Unique identifier of the audio
  recording.

**Request Body:**

- **metadata** (JSON, optional): Updated metadata about the recording.

**Example Request:**

```json
{
  "metadata": {
    "notes": "Updated file information"
  }
}
```

**Response:**

- **200 OK** Returns the updated audio recording details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "audioSessionId": "123e4567-e89b-12d3-a456-426614174111",
    "fileName": "updated_recording.wav",
    "fileFormat": "WAV",
    "storageId": "123e4567-e89b-12d3-a456-426614174888",
    "storageUrl": "https://storage.example.com/updated_recording.wav",
    "metadata": {
      "notes": "Updated file information"
    },
    "createdAt": "2024-01-15T12:00:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to modify audio
  recordings or access to the organization.
- **404 Not Found** Audio recording or audio session with the given ID not
  found.

---

### **4. Delete an Audio Recording**

**Endpoint:**\
`DELETE /orgs/{organizationId}/audio-sessions/{audioSessionId}/recordings/{audioRecordingId}`

**Required Role:**\
`remove-recordings`

**Description:**\
Deletes an audio recording associated with the specified audio session.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.
- **audioRecordingId** (UUID, required): Unique identifier of the audio
  recording.

**Response:**

- **204 No Content** Audio recording successfully deleted. No response body.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to remove audio
  recordings or access to the organization.
- **404 Not Found** Audio recording or audio session with the given ID not
  found.

---

## **Voice Transcripts Endpoints**

The Voice Transcripts endpoints handle the text transcriptions associated with
specific audio sessions. These endpoints facilitate basic operations for the
transcriptions generated from audio recordings within the sessions.

For Stage 1 all transcripts are automatically generated and cannot be created by
this API.

### **Base URL**

All endpoints for managing voice transcripts are prefixed with
`/orgs/{organizationId}/audio-sessions/{audioSessionId}/transcripts`.

### **Required Roles**

- **modify-transcripts**: Required to update an existing transcript.
- **view-transcripts**: Required to retrieve transcript details.
- **remove-transcripts**: Required to delete a transcript.

---

### **1. Get All Transcripts for a Session**

**Endpoint:**
`GET /orgs/{organizationId}/audio-sessions/{audioSessionId}/transcripts`

**Required Role:** `view-transcripts`

**Description:** Fetches a list of all transcriptions associated with a specific
audio session.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.

**Response:**

- **200 OK** Returns a list of voice transcripts.

  ```json
  [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "organizationId": "123e4567-e89b-12d3-a456-426614174999",
      "audioSessionId": "123e4567-e89b-12d3-a456-426614174111",
      "type": "raw",
      "typeDetails": "Initial transcript",
      "text": "Hello, this is a transcription of the recording.",
      "metadata": {
        "confidence": "95%",
        "language": "en-US"
      },
      "createdAt": "2024-01-15T12:30:00Z"
    },
    ...
  ]
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view
  transcripts or access to the organization.
- **404 Not Found** Audio session with the given ID not found.

---

### **2. Get a Transcript by ID**

**Endpoint:**
`GET /orgs/{organizationId}/audio-sessions/{audioSessionId}/transcripts/{voiceTranscriptId}`

**Required Role:** `view-transcripts`

**Description:** Fetches details of a specific voice transcript.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.
- **voiceTranscriptId** (UUID, required): Unique identifier of the voice
  transcript.

**Response:**

- **200 OK** Returns the voice transcript details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "audioSessionId": "123e4567-e89b-12d3-a456-426614174111",
    "type": "raw",
    "typeDetails": "Initial transcription",
    "text": "This is the transcribed text from the audio session.",
    "metadata": {
      "confidence": "93%",
      "language": "en-US"
    },
    "createdAt": "2024-01-15T12:30:00Z"
  }
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view
  transcripts or access to the organization.
- **404 Not Found** Voice transcript or audio session with the given ID not
  found.

---

### **3. Update a Transcript**

**Endpoint:**
`PUT /orgs/{organizationId}/audio-sessions/{audioSessionId}/transcripts/{voiceTranscriptId}`

**Required Role:** `modify-transcripts`

**Description:** Updates details of an existing voice transcript.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.
- **voiceTranscriptId** (UUID, required): Unique identifier of the voice
  transcript.

**Request Body:**

- **metadata** (JSON, optional): Updated metadata related to the transcription.

**Example Request:**

```json
{
  "metadata": {
    "confidence": "95%"
  }
}
```

**Response:**

- **200 OK** Returns the updated voice transcript details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "audioSessionId": "123e4567-e89b-12d3-a456-426614174111",
    "type": "redacted",
    "typeDetails": "Redacted for PII",
    "text": "This is the redacted text from the audio session.",
    "metadata": {
      "confidence": "95%"
    },
    "createdAt": "2024-01-15T12:30:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to modify
  transcripts or access to the organization.
- **404 Not Found** Voice transcript or audio session with the given ID not
  found.

---

### **4. Delete a Transcript**

**Endpoint:**
`DELETE /orgs/{organizationId}/audio-sessions/{audioSessionId}/transcripts/{voiceTranscriptId}`

**Required Role:** `remove-transcripts`

**Description:** Deletes a voice transcript associated with the specified audio
session.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **audioSessionId** (UUID, required): Unique identifier of the audio session.
- **voiceTranscriptId** (UUID, required): Unique identifier of the voice
  transcript.

**Response:**

- **204 No Content** Voice transcript successfully deleted. No response body.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to remove
  transcripts or access to the organization.
- **404 Not Found** Voice transcript or audio session with the given ID not
  found.

---
