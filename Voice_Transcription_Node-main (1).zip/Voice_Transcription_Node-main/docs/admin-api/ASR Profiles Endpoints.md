## **ASR Profiles Endpoints**

The ASR Profiles endpoints handle configurations specific to ASR providers for a given organization. These configurations can include language settings, dictionaries containing industry-specific words, and other ASR provider-specific options.

### **Base URL**

All endpoints for managing ASR profiles are prefixed with `/orgs/{organizationId}/asr-profiles`.

### **Required Roles**

- **create-asr-profiles**: Required to create a new ASR profile.
- **modify-asr-profiles**: Required to update an existing ASR profile.
- **view-asr-profiles**: Required to retrieve ASR profile details.
- **remove-asr-profiles**: Required to delete an ASR profile.

---

### **1. Get All ASR Profiles**

**Endpoint:** `GET /orgs/{organizationId}/asr-profiles`

**Required Role:** `view-asr-profiles`

**Description:** Fetches a list of all ASR profiles associated with the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Response:**

- **200 OK** Returns a list of ASR profiles.

  ```json
  [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "organizationId": "123e4567-e89b-12d3-a456-426614174999",
      "name": "Default ASR Profile",
      "providerId": "123e4567-e89b-12d3-a456-426614174888",
      "metadata": {
        "languages": ["en-US"],
        "dictionaries": ["Telus", "Fuel iX"],
        "additionalOptions": {
          "noiseReduction": true
        }
      },
      "createdAt": "2024-01-10T09:00:00Z"
    },
    ...
  ]
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to view ASR profiles or access to the organization.

---

### **2. Create a New ASR Profile**

**Endpoint:** `POST /orgs/{organizationId}/asr-profiles`

**Required Role:** `create-asr-profiles`

**Description:** Creates a new ASR profile for the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Request Body:**

- **name** (string, required): Name of the ASR profile.
- **providerId** (UUID, required): Reference to the associated ASR provider.
- **metadata** (JSON, optional): Additional metadata for configuring the ASR provider (e.g., supported languages, dictionaries with industry-specific terms, and other options).

**Example Request:**

```json
{
  "name": "Custom ASR Profile",
  "providerId": "123e4567-e89b-12d3-a456-426614174888",
  "metadata": {
    "languages": ["en-US", "es-ES"],
    "dictionaries": ["Telus", "Fuel iX"],
    "additionalOptions": {
      "noiseReduction": true,
      "automaticPunctuation": false
    }
  }
}
```

**Response:**

- **201 Created** Returns the newly created ASR profile object.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174001",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Custom ASR Profile",
    "providerId": "123e4567-e89b-12d3-a456-426614174888",
    "metadata": {
      "languages": ["en-US", "es-ES"],
      "dictionaries": ["Telus", "Fuel iX"],
      "additionalOptions": {
        "noiseReduction": true,
        "automaticPunctuation": false
      }
    },
    "createdAt": "2024-01-15T10:00:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to create ASR profiles or access to the organization.

---

### **3. Get an ASR Profile by ID**

**Endpoint:** `GET /orgs/{organizationId}/asr-profiles/{asrProfileId}`

**Required Role:** `view-asr-profiles`

**Description:** Fetches details of a specific ASR profile.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **asrProfileId** (UUID, required): Unique identifier of the ASR profile.

**Response:**

- **200 OK** Returns the ASR profile details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Default ASR Profile",
    "providerId": "123e4567-e89b-12d3-a456-426614174888",
    "metadata": {
      "languages": ["en-US"],
      "dictionaries": ["Telus", "Fuel iX"],
      "additionalOptions": {
        "noiseReduction": true
      }
    },
    "createdAt": "2024-01-10T09:00:00Z"
  }
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to view ASR profiles or access to the organization.
- **404 Not Found** If the ASR profile with the specified ID is not found.

---

### **4. Update an ASR Profile**

**Endpoint:** `PUT /orgs/{organizationId}/asr-profiles/{asrProfileId}`

**Required Role:** `modify-asr-profiles`

**Description:** Updates details of an existing ASR profile.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **asrProfileId** (UUID, required): Unique identifier of the ASR profile.

**Request Body:**

- **name** (string, optional): Updated name of the ASR profile.
- **providerId** (UUID, optional): Updated reference to the associated ASR provider.
- **metadata** (JSON, optional): Updated metadata (e.g., languages, dictionaries, and other provider-specific options).

**Example Request:**

```json
{
  "name": "Updated ASR Profile Name",
  "metadata": {
    "languages": ["fr-FR"],
    "dictionaries": ["Telus", "Fuel iX"],
    "additionalOptions": {
      "noiseReduction": false
    }
  }
}
```

**Response:**

- **200 OK** Returns the updated ASR profile details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Updated ASR Profile Name",
    "providerId": "123e4567-e89b-12d3-a456-426614174888",
    "metadata": {
      "languages": ["fr-FR"],
      "dictionaries": ["Telus", "Fuel iX"],
      "additionalOptions": {
        "noiseReduction": false
      }
    },
    "createdAt": "2024-01-10T09:00:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to modify ASR profiles or access to the organization.
- **404 Not Found** If the ASR profile with the specified ID is not found.

---

### **5. Delete an ASR Profile**

**Endpoint:** `DELETE /orgs/{organizationId}/asr-profiles/{asrProfileId}`

**Required Role:** `remove-asr-profiles`

**Description:** Deletes an ASR profile from the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **asrProfileId** (UUID, required): Unique identifier of the ASR profile.

**Response:**

- **204 No Content** ASR profile successfully deleted. No response body.
- **401 Unauthorized** Request is missing a valid API key or authentication token.
- **403 Forbidden** Requester does not have the required role to remove ASR profiles or access to the organization.
- **404 Not Found** If the ASR profile with the specified ID is not found.

---
