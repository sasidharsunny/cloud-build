# Admin API Documentation

This folder contains the documentation for Admin API endpoints used in the system. Below is a list of available documentation for specific API endpoints.

## API Endpoints Documentation

- [API Keys Endpoints](./API%20Keys%20Endpoints.md)
- [ASR Profiles Endpoints](./ASR%20Profiles%20Endpoints.md)
- [ASR Providers Endpoints](./ASR%20Providers%20Endpoints.md)
- [Audio Sessions Endpoints](./Audio%20Sessions%20Endpoints.md)
- [Organizations Endpoints](./Organizations%20Endpoints.md)
- [Storage Providers Endpoints](./Storage%20Providers%20Endpoints.md)
- [Users Endpoints](./Users%20Endpoints.md)
