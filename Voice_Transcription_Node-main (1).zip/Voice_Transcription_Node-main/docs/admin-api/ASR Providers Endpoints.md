## **ASR Providers Endpoints**

The ASR (Automatic Speech Recognition) Providers endpoints manage configurations
for ASR providers used by the system. These endpoints allow baisc operations to
handle provider configurations and their associated settings. These endpoints
don't handle the actual ASR profiles which are used during the session
processing. For that, refer to the ASR Profiles Endpoints documentation.

### **Base URL**

All endpoints for managing ASR providers are prefixed with
`/orgs/{organizationId}/asr-providers`.

### **Required Roles**

- **create-asr-providers**: Required to create a new ASR provider.
- **modify-asr-providers**: Required to update an existing ASR provider.
- **view-asr-providers**: Required to retrieve ASR provider details.
- **remove-asr-providers**: Required to delete an ASR provider.

---

### **1. Get All ASR Providers**

**Endpoint:** `GET /orgs/{organizationId}/asr-providers`

**Required Role:** `view-asr-providers`

**Description:** Fetches a list of all ASR providers associated with the
specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Response:**

- **200 OK** Returns a list of ASR providers.

  ```json
  [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "organizationId": "123e4567-e89b-12d3-a456-426614174999",
      "name": "Azure Speech Service",
      "type": "azure-ai-speech",
      "metadata": {
        "languageSupport": ["en-US", "es-ES"]
      },
      "config": {
        "azureKey": "da39a3ee5e6b4b0d3255bfef95601890afd80709",
        "azureRegion": "eastus"
      },
      "createdAt": "2024-01-10T09:00:00Z"
    },
    ...
  ]
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view ASR
  providers or access to the organization.

---

### **2. Create a New ASR Provider**

**Endpoint:** `POST /orgs/{organizationId}/asr-providers`

**Required Role:** `create-asr-providers`

**Description:** Creates a new ASR provider configuration for the specified
organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.

**Request Body:**

- **name** (string, required): Name of the ASR provider (e.g.,
  `Azure Speech Service`).
- **type** (string, required): Type of ASR provider (e.g., `azure-ai-speech`).
- **metadata** (JSON, optional): Additional metadata for the ASR provider (e.g.
  supported languages).
- **config** (JSON, optional): Configuration that might be required by an ASR
  provider.

**Example Request:**

```json
{
  "name": "Azure Cloud Speech-to-Text",
  "type": "azure-ai-speech",
  "metadata": {
    "languageSupport": ["en-US", "fr-FR"]
  },
  "config": {
    "azureKey": "abc123ee5e6b4b0d3255bfef95601890afd80709",
    "azureRegion": "eastus2"
  }
}
```

**Response:**

- **201 Created** Returns the newly created ASR provider object.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Azure Speech Service",
    "type": "azure-ai-speech",
    "metadata": {
      "languageSupport": ["en-US", "es-ES"]
    },
    "config": {
      "azureKey": "da39a3ee5e6b4b0d3255bfef95601890afd80709",
      "azureRegion": "eastus"
    },
    "createdAt": "2024-01-10T09:00:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to create ASR
  providers or access to the organization.

---

### **3. Get an ASR Provider by ID**

**Endpoint:** `GET /orgs/{organizationId}/asr-providers/{asrProviderId}`

**Required Role:** `view-asr-providers`

**Description:** Fetches details of a specific ASR provider by its unique ID.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **asrProviderId** (UUID, required): Unique identifier of the ASR provider.

**Response:**

- **200 OK** Returns the ASR provider details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Azure Speech Service",
    "type": "azure-ai-speech",
    "metadata": {
      "languageSupport": ["en-US", "es-ES"]
    },
    "config": {
      "azureKey": "da39a3ee5e6b4b0d3255bfef95601890afd80709",
      "azureRegion": "eastus"
    },
    "createdAt": "2024-01-10T09:00:00Z"
  }
  ```

- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to view ASR
  providers or access to the organization.
- **404 Not Found** If the ASR provider with the specified ID is not found.

---

### **4. Update an ASR Provider**

**Endpoint:** `PUT /orgs/{organizationId}/asr-providers/{asrProviderId}`

**Required Role:** `modify-asr-providers`

**Description:** Updates details of an existing ASR provider.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **asrProviderId** (UUID, required): Unique identifier of the ASR provider.

**Request Body:**

- **name** (string, optional): Updated name of the ASR provider.
- **metadata** (JSON, optional): Updated metadata or configuration settings.

**Example Request:**

```json
{
  "name": "Updated ASR Provider Name",
  "metadata": {
    "region": "West Europe",
    "languageSupport": ["de-DE"]
  }
}
```

**Response:**

- **200 OK** Returns the updated ASR provider details.

  ```json
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "organizationId": "123e4567-e89b-12d3-a456-426614174999",
    "name": "Updated ASR Provider Name",
    "type": "cloud-based",
    "metadata": {
      "region": "West Europe",
      "languageSupport": ["de-DE"]
    },
    "createdAt": "2024-01-10T09:00:00Z"
  }
  ```

- **400 Bad Request** Invalid request body or missing required fields.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to modify ASR
  providers or access to the organization.
- **404 Not Found** If the ASR provider with the specified ID is not found.

---

### **5. Delete an ASR Provider**

**Endpoint:** `DELETE /orgs/{organizationId}/asr-providers/{asrProviderId}`

**Required Role:** `remove-asr-providers`

**Description:** Deletes an ASR provider from the specified organization.

**Path Parameters:**

- **organizationId** (UUID, required): Unique identifier of the organization.
- **asrProviderId** (UUID, required): Unique identifier of the ASR provider.

**Response:**

- **204 No Content** ASR provider successfully deleted. No response body.
- **401 Unauthorized** Request is missing a valid API key or authentication
  token.
- **403 Forbidden** Requester does not have the required role to remove ASR
  providers or access to the organization.
- **404 Not Found** If the ASR provider with the specified ID is not found.

---
